"""Scoring utilities backed by scikit-learn's scorer registry.

Instead of maintaining a custom metric registry, this module delegates
to scikit-learn's built-in scorer system.  Callers pass either a scorer
name string (looked up via ``sklearn.metrics.get_scorer``) or a
pre-built ``_Scorer`` object (from ``sklearn.metrics.make_scorer``).
"""

from __future__ import annotations

from typing import Any

import numpy as np
from sklearn.metrics import get_scorer as _get_scorer
from sklearn.metrics import make_scorer  # noqa: F401 – re-export


def resolve_scorer(metric: str | Any) -> Any:
    """Resolve a metric to a scikit-learn scorer.

    Args:
        metric: Either a scorer name string (e.g. ``"roc_auc"``,
            ``"neg_mean_squared_error"``) or a ``_Scorer`` object
            returned by :func:`sklearn.metrics.make_scorer`.

    Returns:
        A scikit-learn ``_Scorer`` with ``._score_func``, ``._sign``,
        and ``._kwargs`` attributes.

    Raises:
        ValueError: If *metric* is a string that is not registered in
            scikit-learn's scorer registry.
    """
    if isinstance(metric, str):
        return _get_scorer(metric)
    return metric


def scorer_direction(scorer: Any) -> bool:
    """Return ``True`` if higher scores are better for *scorer*."""
    return scorer._sign == 1


def scorer_name(scorer: Any, default: str = "") -> str:
    """Return a human-readable name for the scorer.

    If *default* is provided it is returned as-is.  Otherwise the
    name is derived from the underlying score function.
    """
    if default:
        return default
    fn = getattr(scorer, "_score_func", None)
    if fn is not None:
        return fn.__name__
    return "unknown"


def score_arrays(
    scorer: Any,
    y_true: np.ndarray,
    y_pred: np.ndarray,
) -> float:
    """Score predictions using a scorer's underlying function.

    Handles single-target auto-squeeze: if *y_true* and *y_pred* are
    2-D arrays with a single column they are flattened to 1-D before
    scoring, since most scikit-learn metrics expect 1-D inputs for
    single-target problems.
    """
    if y_true.ndim == 2 and y_true.shape[1] == 1:
        y_true = y_true.ravel()
    if y_pred.ndim == 2 and y_pred.shape[1] == 1:
        y_pred = y_pred.ravel()
    kwargs = getattr(scorer, "_kwargs", {}) or {}
    return float(scorer._score_func(y_true, y_pred, **kwargs))
