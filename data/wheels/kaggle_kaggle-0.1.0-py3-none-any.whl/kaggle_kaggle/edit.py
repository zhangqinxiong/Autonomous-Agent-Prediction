"""Core replacement engine for file_edit tool.

Implements tiered matching strategies (Exact -> Flexible -> Regex)
mirroring Gemini CLI's replacement logic.
"""

from __future__ import annotations

import dataclasses
import re
from typing import Literal


@dataclasses.dataclass
class EditResult:
    """Result of an edit replacement operation."""

    new_content: str
    occurrences: int
    strategy: Literal["exact", "flexible", "regex", "none"]
    error_message: str | None = None


def apply_indentation(lines: list[str], target_indent: str) -> list[str]:
    """Applies target indentation to a block of lines, preserving relative indents."""
    if not lines:
        return []

    ref_line = lines[0]
    ref_match = re.match(r"^([ \t]*)", ref_line)
    ref_indent = ref_match.group(1) if ref_match else ""

    result = []
    for line in lines:
        if not line.strip():
            result.append("")
        elif line.startswith(ref_indent):
            result.append(target_indent + line[len(ref_indent):])
        else:
            result.append(target_indent + line.lstrip())
    return result


def _apply_exact_match(
    current_content: str,
    old_string: str,
    new_string: str,
    allow_multiple: bool,
) -> EditResult | None:
    exact_count = current_content.count(old_string)
    if exact_count == 0:
        return None

    if not allow_multiple and exact_count > 1:
        return EditResult(
            new_content=current_content,
            occurrences=exact_count,
            strategy="exact",
            error_message=(
                f"Expected 1 occurrence but found {exact_count}. "
                "If you intended to replace multiple occurrences, set 'allow_multiple' to true."
            ),
        )

    new_content = current_content.replace(old_string, new_string)
    return EditResult(
        new_content=new_content,
        occurrences=exact_count,
        strategy="exact",
    )


def _apply_flexible_match(
    current_content: str,
    old_string: str,
    new_string: str,
    allow_multiple: bool,
) -> EditResult | None:
    """Applies flexible matching by comparing stripped lines within a sliding window.

    Note: This strategy requires an exact line-by-line match of non-whitespace characters.
    Vertical whitespace variations (e.g., differing numbers of empty lines) are not matched
    here but are handled by the subsequent regex fallback strategy.
    """
    current_lines = current_content.splitlines(keepends=True)
    old_lines = old_string.splitlines()
    new_lines = new_string.splitlines()

    if not old_lines:
        return None

    old_stripped = [line.strip() for line in old_lines]

    matches = []
    i = 0
    while i <= len(current_lines) - len(old_lines):
        window = current_lines[i : i + len(old_lines)]
        window_stripped = [line.strip() for line in window]

        if window_stripped == old_stripped:
            matches.append(i)
            i += len(old_lines)
        else:
            i += 1

    if not matches:
        return None

    if not allow_multiple and len(matches) > 1:
        return EditResult(
            new_content=current_content,
            occurrences=len(matches),
            strategy="flexible",
            error_message=(
                f"Expected 1 occurrence but found {len(matches)}. "
                "If you intended to replace multiple occurrences, set 'allow_multiple' to true."
            ),
        )

    # Apply replacements from bottom to top so line indices remain valid
    for match_idx in reversed(matches):
        first_line = current_lines[match_idx]
        indent_match = re.match(r"^([ \t]*)", first_line)
        indent = indent_match.group(1) if indent_match else ""

        indented_new = apply_indentation(new_lines, indent)
        replacement_text = "\n".join(indented_new)

        # Preserve trailing newline if the last line of the matched window had one
        last_window_line = current_lines[match_idx + len(old_lines) - 1]
        if last_window_line.endswith("\n") and not replacement_text.endswith("\n"):
            replacement_text += "\n"
        elif not last_window_line.endswith("\n") and replacement_text.endswith("\n"):
            replacement_text = replacement_text.rstrip("\n")

        replacement_lines = replacement_text.splitlines(keepends=True)
        current_lines[match_idx : match_idx + len(old_lines)] = replacement_lines

    new_content = "".join(current_lines)
    return EditResult(
        new_content=new_content,
        occurrences=len(matches),
        strategy="flexible",
    )


def _apply_regex_match(
    current_content: str,
    old_string: str,
    new_string: str,
    allow_multiple: bool,
) -> EditResult | None:
    delimiters = ["(", ")", ":", "[", "]", "{", "}", ">", "<", "="]
    processed = old_string
    for delim in delimiters:
        processed = processed.replace(delim, f" {delim} ")

    tokens = [t for t in processed.split() if t]
    if not tokens:
        return None

    escaped_tokens = [re.escape(t) for t in tokens]
    pattern_str = r"\s*".join(escaped_tokens)
    final_pattern = f"^([ \t]*){pattern_str}"

    # Count matches using re.M
    matches = list(re.finditer(final_pattern, current_content, flags=re.M))
    if not matches:
        return None

    if not allow_multiple and len(matches) > 1:
        return EditResult(
            new_content=current_content,
            occurrences=len(matches),
            strategy="regex",
            error_message=(
                f"Expected 1 occurrence but found {len(matches)}. "
                "If you intended to replace multiple occurrences, set 'allow_multiple' to true."
            ),
        )

    new_lines = new_string.splitlines()

    def repl(match: re.Match) -> str:
        indent = match.group(1) or ""
        indented = apply_indentation(new_lines, indent)
        return "\n".join(indented)

    # Replace using re.sub
    count = len(matches)
    new_content = re.sub(
        final_pattern,
        repl,
        current_content,
        count=0 if allow_multiple else 1,
        flags=re.M,
    )

    return EditResult(
        new_content=new_content,
        occurrences=count,
        strategy="regex",
    )


def apply_replacement(
    current_content: str,
    old_string: str,
    new_string: str,
    allow_multiple: bool = False,
) -> EditResult:
    """Executes tiered replacement strategies (Exact -> Flexible -> Regex)."""
    if not old_string:
        return EditResult(
            new_content=current_content,
            occurrences=0,
            strategy="none",
            error_message="old_string cannot be empty for existing files.",
        )

    if old_string == new_string:
        return EditResult(
            new_content=current_content,
            occurrences=1,
            strategy="exact",
            error_message="No changes to apply. old_string and new_string are identical.",
        )

    # 1. Exact Match Strategy
    exact_res = _apply_exact_match(current_content, old_string, new_string, allow_multiple)
    if exact_res:
        return exact_res

    # 2. Flexible Match Strategy
    flex_res = _apply_flexible_match(current_content, old_string, new_string, allow_multiple)
    if flex_res:
        return flex_res

    # 3. Regex Match Strategy
    regex_res = _apply_regex_match(current_content, old_string, new_string, allow_multiple)
    if regex_res:
        return regex_res

    return EditResult(
        new_content=current_content,
        occurrences=0,
        strategy="none",
        error_message=(
            "Failed to replace: old_string not found. "
            "Ensure you're not escaping content incorrectly and check whitespace, indentation, and context."
        ),
    )
