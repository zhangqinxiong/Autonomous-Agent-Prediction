# Copyright 2026 Kaggle Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Low-level Docker container management.

Provides a context-manager wrapper around the Docker SDK for running
commands and transferring files via tarball archives (required because
on-site Kaggle Docker doesn't support bind mounts).
"""

from __future__ import annotations

import io
import logging
import posixpath
import shlex
import tarfile
import time
from typing import Any

import docker
import docker.errors

logger = logging.getLogger(__name__)

_MAX_READ_BYTES = 50 * 1024 * 1024  # 50 MB
_MAX_RUN_READ_BYTES = 10 * 1024 * 1024  # 10 MB


class DockerContainer:
    """Manages a single Docker container lifecycle.

    Usage::

        with DockerContainer("gcr.io/kaggle-images/python") as c:
            exit_code, output = c.run_command("echo hello")
            c.write_file("/work/data.csv", "a,b\\n1,2")
            content = c.read_file("/work/data.csv")

    Attributes:
        image: The Docker image string.
        client: The Docker client from the environment.
        container: The underlying docker container object.
    """

    def __init__(self, image: str):
        """Initialize the DockerContainer.

        Args:
            image: The Docker image to run.
        """
        self.image = image
        self.client = docker.from_env()
        self.container = None

    def __enter__(self) -> DockerContainer:
        logger.debug("Checking for image %s...", self.image)
        try:
            self.client.images.get(self.image)
            logger.debug("Image %s found locally.", self.image)
        except docker.errors.ImageNotFound:
            logger.info(
                "Image %s not found locally. Pulling (this may take a while)...",
                self.image,
            )
            self.client.images.pull(self.image)
            logger.info("Image %s pulled successfully.", self.image)

        logger.debug("Creating container from %s...", self.image)
        self.container = self.client.containers.run(
            self.image,
            command="tail -f /dev/null",
            detach=True,
            tty=True,
            network_disabled=True,
        )
        logger.debug(
            "Container %s created, waiting for it to start...", self.container.short_id
        )

        start_time = time.time()
        while self.container.status != "running":
            self.container.reload()
            if time.time() - start_time > 10:
                try:
                    self.container.stop()
                except Exception:
                    pass
                try:
                    self.container.remove()
                except Exception:
                    pass
                raise TimeoutError("Container failed to start within 10 seconds")
            time.sleep(0.1)

        logger.debug("Container %s is running.", self.container.short_id)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        if self.container:
            try:
                self.container.stop(timeout=1)
            except docker.errors.APIError:
                pass
            try:
                self.container.remove(force=True)
            except docker.errors.APIError:
                pass

    def run_command(self, command: str, workdir: str | None = None) -> tuple[int, str, str]:
        """Run a command and return (exit_code, stdout, stderr).

        Args:
            command: Shell command to execute.
            workdir: Working directory inside the container.

        Returns:
            Tuple of (exit_code, decoded_stdout, decoded_stderr).

        Raises:
            RuntimeError: If the container is not started.
        """
        if not self.container:
            raise RuntimeError("Container not started")

        exec_id = None
        if hasattr(self.client, "api"):
            original_exec_create = self.client.api.exec_create

            def hook(*args, **kwargs):
                nonlocal exec_id
                res = original_exec_create(*args, **kwargs)
                exec_id = res.get("Id")
                return res

            self.client.api.exec_create = hook
            try:
                res: Any = self.container.exec_run(
                    ["sh", "-c", command], workdir=workdir, stream=True, demux=True
                )
                exit_code, output = res
            finally:
                self.client.api.exec_create = original_exec_create
        else:
            res: Any = self.container.exec_run(
                ["sh", "-c", command], workdir=workdir, stream=True, demux=True
            )
            exit_code, output = res

        stdout_bytes = io.BytesIO()
        stderr_bytes = io.BytesIO()
        total_bytes = 0
        limit_exceeded = False

        for out_chunk, err_chunk in output:
            if out_chunk:
                if total_bytes + len(out_chunk) > _MAX_RUN_READ_BYTES:
                    allowed = _MAX_RUN_READ_BYTES - total_bytes
                    if allowed > 0:
                        stdout_bytes.write(out_chunk[:allowed])
                        total_bytes += allowed
                    limit_exceeded = True
                    break
                stdout_bytes.write(out_chunk)
                total_bytes += len(out_chunk)
            if err_chunk:
                if total_bytes + len(err_chunk) > _MAX_RUN_READ_BYTES:
                    allowed = _MAX_RUN_READ_BYTES - total_bytes
                    if allowed > 0:
                        stderr_bytes.write(err_chunk[:allowed])
                        total_bytes += allowed
                    limit_exceeded = True
                    break
                stderr_bytes.write(err_chunk)
                total_bytes += len(err_chunk)

        if limit_exceeded:
            logger.warning(
                f"Command output exceeded maximum read size of {_MAX_RUN_READ_BYTES} bytes. Truncating."
            )

        if exit_code is None and exec_id is not None:
            for _ in range(10):
                inspect_data = self.client.api.exec_inspect(exec_id)
                if inspect_data.get("Running") is False:
                    exit_code = inspect_data.get("ExitCode")
                    break
                time.sleep(0.1)
            if exit_code is None:
                exit_code = -1

        if exit_code is None:
            exit_code = 0

        stdout_str = stdout_bytes.getvalue().decode("utf-8", errors="replace").strip()
        stderr_str = stderr_bytes.getvalue().decode("utf-8", errors="replace").strip()

        return exit_code, stdout_str, stderr_str

    def write_file(self, path: str, content: str | bytes) -> None:
        """Write content to a file inside the container.

        Uses tarball transfer since bind mounts are not available.

        Args:
            path: Absolute path inside the container.
            content: File content as string (UTF-8 encoded) or bytes.

        Raises:
            RuntimeError: If the container is not started.
        """
        if not self.container:
            raise RuntimeError("Container not started")

        dir_name = posixpath.dirname(path)
        file_name = posixpath.basename(path)

        if not dir_name:
            dir_name = "/"

        exit_code, output = self.container.exec_run(f"mkdir -p {shlex.quote(dir_name)}")
        if exit_code != 0:
            err_msg = output.decode("utf-8", errors="replace") if isinstance(output, bytes) else str(output)
            raise RuntimeError(f"Failed to create directory {dir_name}: {err_msg}")

        if isinstance(content, str):
            data = content.encode("utf-8")
        else:
            data = content

        tar_stream = io.BytesIO()
        with tarfile.open(fileobj=tar_stream, mode="w") as tar:
            tarinfo = tarfile.TarInfo(name=file_name)
            tarinfo.size = len(data)
            tarinfo.mtime = time.time()
            tar.addfile(tarinfo, io.BytesIO(data))

        tar_stream.seek(0)
        self.container.put_archive(dir_name, tar_stream)

    def read_file(self, path: str) -> str:
        """Read a file from the container and return it as a string.

        Args:
            path: Absolute path inside the container.

        Returns:
            File content as a UTF-8 string.

        Raises:
            FileNotFoundError: If the file does not exist.
            RuntimeError: On other read errors, or if the container is not started.
        """
        if not self.container:
            raise RuntimeError("Container not started")

        try:
            stream, _ = self.container.get_archive(path)

            file_obj = io.BytesIO()
            total_read = 0
            for chunk in stream:
                total_read += len(chunk)
                if total_read > _MAX_READ_BYTES:
                    raise RuntimeError(
                        f"File {path} exceeds maximum read size of "
                        f"{_MAX_READ_BYTES // (1024 * 1024)} MB"
                    )
                file_obj.write(chunk)
            file_obj.seek(0)

            with tarfile.open(fileobj=file_obj, mode="r") as tar:
                members = tar.getmembers()
                if not members:
                    raise RuntimeError(f"File {path} is empty or invalid tar.")

                member = members[0]
                if member.isdir():
                    raise IsADirectoryError(f"{path} is a directory")
                f = tar.extractfile(member)
                if f is None:
                    raise RuntimeError(f"Could not extract file {path}.")

                return f.read().decode("utf-8", errors="replace")

        except docker.errors.NotFound:
            raise FileNotFoundError(f"File not found: {path}")
        except (FileNotFoundError, IsADirectoryError, RuntimeError):
            raise
        except Exception as e:
            raise RuntimeError(f"Error reading file {path}: {e}")
