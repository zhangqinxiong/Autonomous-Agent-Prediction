"""Token budget tracking and model pricing for Kaggle-in-Kaggle.

Provides:
- ``ModelPricing`` / ``PricingTable``: per-token cost lookup from YAML config.
- ``TokenBudget``: accumulates token usage, computes running cost in USD,
  and provides budget enforcement (exceeded detection) and status reporting.
"""

from __future__ import annotations

import functools
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

logger = logging.getLogger(__name__)

_DEFAULT_CONFIG_PATH = Path(__file__).parent / "models.yaml"


@dataclass(frozen=True)
class ModelPricing:
    """Per-token pricing for a model (USD per 1M tokens)."""

    model_id: str
    path: str
    display_name: str
    input_price_per_million: float  # $/1M input tokens
    cached_input_price_per_million: float  # $/1M cached input tokens
    output_price_per_million: float  # $/1M output tokens

    def cost(self, input_tokens: int, output_tokens: int, cached_input_tokens: int = 0) -> float:
        """Compute cost in USD for a given number of tokens."""
        if input_tokens < 0 or output_tokens < 0 or cached_input_tokens < 0:
            raise ValueError("Token counts cannot be negative")
        non_cached_input = max(0, input_tokens - cached_input_tokens)
        input_cost = (non_cached_input / 1_000_000) * self.input_price_per_million
        cached_cost = (cached_input_tokens / 1_000_000) * self.cached_input_price_per_million
        output_cost = (output_tokens / 1_000_000) * self.output_price_per_million
        return input_cost + cached_cost + output_cost


class PricingTable:
    """Registry of model pricing loaded from a YAML config file.

    Usage::

        table = PricingTable.from_yaml("models.yaml")
        pricing = table.get("openai/google/gemini-3-flash-preview")
        cost = pricing.cost(input_tokens=5000, output_tokens=1200)
    """

    def __init__(self, models: dict[str, ModelPricing]) -> None:
        self._models = models
        self._by_path = {m.path: m for m in models.values() if m.path}

    @classmethod
    @functools.lru_cache
    def from_yaml(cls, path: str | Path = _DEFAULT_CONFIG_PATH) -> PricingTable:
        """Load pricing from a YAML config file.

        Expected format::

            models:
              gemini-3-flash-preview:
                path: "openai/google/gemini-3-flash-preview"
                display_name: "Gemini 3 Flash Preview"
                input_price_per_million_tokens: 0.15
                output_price_per_million_tokens: 0.60
        """
        path = Path(path)
        if not path.exists():
            logger.warning("Pricing config not found at %s — using empty table", path)
            return cls({})

        with open(path) as f:
            data: dict[str, Any] = yaml.safe_load(f) or {}

        models_data = data.get("models", {})
        if not isinstance(models_data, dict):
            models_data = {}
        models: dict[str, ModelPricing] = {}
        for model_id, info in models_data.items():
            if not isinstance(info, dict):
                logger.warning("Skipping malformed model entry: %s", model_id)
                continue
            try:
                input_price = float(info.get("input_price_per_million_tokens", 0))
                cached_input_price = float(info.get("cached_input_price_per_million_tokens", 0))
                output_price = float(info.get("output_price_per_million_tokens", 0))
            except (TypeError, ValueError):
                logger.warning("Non-numeric price for model %s — skipping", model_id)
                continue
            if input_price < 0 or cached_input_price < 0 or output_price < 0:
                logger.warning("Negative price for model %s — skipping", model_id)
                continue
            models[model_id] = ModelPricing(
                model_id=model_id,
                path=info.get("path", ""),
                display_name=info.get("display_name", model_id),
                input_price_per_million=input_price,
                cached_input_price_per_million=cached_input_price,
                output_price_per_million=output_price,
            )
        logger.info("Loaded pricing for %d models from %s", len(models), path)
        return cls(models)

    def get(self, model_id: str) -> ModelPricing | None:
        """Look up pricing for a model ID.

        Tries exact match first, then strips common prefixes.
        """
        if model_id in self._models:
            return self._models[model_id]

        if model_id in self._by_path:
            return self._by_path[model_id]

        # Try without 'openai/' prefix
        stripped = model_id.removeprefix("openai/")
        if stripped in self._models:
            return self._models[stripped]
        if stripped in self._by_path:
            return self._by_path[stripped]

        # Try adding 'openai/' prefix
        prefixed = f"openai/{model_id}"
        if prefixed in self._models:
            return self._models[prefixed]
        if prefixed in self._by_path:
            return self._by_path[prefixed]

        # Try stripping version suffix (e.g., @latest, @20250101).
        # Recursion is bounded to depth 2: base_id has no '@', so the
        # guard `base_id != model_id` prevents further recursion.
        base_id = model_id.split("@")[0]
        if base_id != model_id:
            result = self.get(base_id)
            if result is not None:
                return result

        return None

    @property
    def model_ids(self) -> list[str]:
        """Return all known model IDs."""
        return list(self._models.keys())

    def __len__(self) -> int:
        return len(self._models)

    def __contains__(self, model_id: str) -> bool:
        return self.get(model_id) is not None


@dataclass
class TokenBudget:
    """Tracks cumulative token usage and cost for an agent session.

    Pricing is resolved per-call using the model ID from each LLM event,
    so sessions that use multiple models are priced correctly.

    Usage::

        table = PricingTable.from_yaml()
        budget = TokenBudget(max_budget_usd=5.0, pricing_table=table)

        # After each LLM call (model_id comes from the event):
        cost = budget.record_usage(
            model_id="gemini-3-flash-preview",
            input_tokens=1200,
            output_tokens=350,
        )
        if budget.is_exceeded:
            ...  # stop the agent
    """

    max_budget_usd: float = 5.0
    pricing_table: PricingTable | None = None
    max_llm_calls: int | None = None

    total_input_tokens: int = field(default=0, init=False)
    last_input_tokens: int = field(default=0, init=False)
    total_cached_input_tokens: int = field(default=0, init=False)
    total_output_tokens: int = field(default=0, init=False)
    total_cost_usd: float = field(default=0.0, init=False)
    llm_calls: int = field(default=0, init=False)
    _warned_models: set[str] = field(default_factory=set, init=False, repr=False)

    def __post_init__(self) -> None:
        if self.pricing_table is None:
            self.pricing_table = PricingTable.from_yaml()

    @property
    def remaining_usd(self) -> float:
        """Remaining budget in USD."""
        return max(0.0, self.max_budget_usd - self.total_cost_usd)

    @property
    def is_exceeded(self) -> bool:
        """Whether the budget has been exceeded."""
        if self.total_cost_usd >= self.max_budget_usd:
            return True
        if self.max_llm_calls is not None and self.llm_calls >= self.max_llm_calls:
            return True
        return False

    def record_usage(
        self,
        model_id: str,
        input_tokens: int,
        output_tokens: int,
        cached_input_tokens: int = 0,
    ) -> float:
        """Record token usage from an LLM call and return the cost.

        Args:
            model_id: The model that served this call (from the event).
            input_tokens: Number of prompt/input tokens.
            output_tokens: Number of completion/output tokens.
            cached_input_tokens: Number of prompt tokens served from cache.

        Returns:
            Cost of this call in USD (0.0 if pricing is unknown).
        """
        input_tokens = max(0, input_tokens)
        output_tokens = max(0, output_tokens)
        cached_input_tokens = max(0, cached_input_tokens)
        self.total_input_tokens += input_tokens
        self.last_input_tokens = input_tokens
        self.total_cached_input_tokens += cached_input_tokens
        self.total_output_tokens += output_tokens
        self.llm_calls += 1

        call_cost = 0.0
        if self.pricing_table is not None and model_id:
            pricing = self.pricing_table.get(model_id)
            if pricing is not None:
                call_cost = pricing.cost(input_tokens, output_tokens, cached_input_tokens)
            elif model_id not in self._warned_models:
                self._warned_models.add(model_id)
                logger.warning(
                    "No pricing found for model %r — cost will not be tracked",
                    model_id,
                )

        self.total_cost_usd += call_cost

        logger.debug(
            "LLM call #%d [%s]: +%d in / +%d out tokens, cost=$%.6f "
            "(total=$%.4f / $%.2f)",
            self.llm_calls,
            model_id or "unknown",
            input_tokens,
            output_tokens,
            call_cost,
            self.total_cost_usd,
            self.max_budget_usd,
        )

        return call_cost

    def to_status_dict(self) -> dict[str, Any]:
        """Return budget status for reporting to the agent."""
        return {
            "total_cost_usd": round(self.total_cost_usd, 6),
            "remaining_usd": round(self.remaining_usd, 6),
            "max_budget_usd": self.max_budget_usd,
            "total_input_tokens": self.total_input_tokens,
            "last_input_tokens": self.last_input_tokens,
            "total_cached_input_tokens": self.total_cached_input_tokens,
            "total_output_tokens": self.total_output_tokens,
            "total_tokens": self.total_input_tokens + self.total_output_tokens,
            "llm_calls": self.llm_calls,
        }


def compute_cost(
    model_id: str,
    input_tokens: int,
    output_tokens: int,
    cached_input_tokens: int = 0,
    pricing_table: PricingTable | None = None,
) -> float:
    """Compute cost in USD for a single LLM call.

    Args:
        model_id: The model identifier.
        input_tokens: Number of input (prompt) tokens.
        output_tokens: Number of output (completion) tokens.
        cached_input_tokens: Number of prompt tokens served from cache.
        pricing_table: Pricing table to use. If None, loads from default config.

    Returns:
        Cost in USD. Returns 0.0 if model pricing is unknown.
    """
    if input_tokens < 0 or output_tokens < 0 or cached_input_tokens < 0:
        raise ValueError("Token counts cannot be negative")

    if pricing_table is None:
        pricing_table = PricingTable.from_yaml()

    pricing = pricing_table.get(model_id)
    if pricing is None:
        logger.warning("No pricing found for model %r — cost will be 0", model_id)
        return 0.0

    return pricing.cost(input_tokens, output_tokens, cached_input_tokens)
