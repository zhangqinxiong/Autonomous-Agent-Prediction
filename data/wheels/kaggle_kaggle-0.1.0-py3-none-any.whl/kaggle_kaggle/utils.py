"""Shared utilities for Kaggle-in-Kaggle.

Small helpers used by multiple modules (trace, display, etc.).
"""

from __future__ import annotations

import json
from typing import Any


def unwrap_tool_response(fr: Any) -> dict | None:
    """Extract a parsed dict from an ADK FunctionResponse.

    ADK wraps string tool returns as ``{"result": "<json_string>"}``.
    This unwraps that envelope so callers always get a plain ``dict``.
    """
    resp = getattr(fr, "response", None)
    if resp is None:
        return None

    if isinstance(resp, dict):
        inner = resp.get("result", resp)
        if isinstance(inner, str):
            try:
                parsed = json.loads(inner)
                return parsed if isinstance(parsed, dict) else {"result": parsed}
            except (json.JSONDecodeError, TypeError):
                return {"raw": inner}
        return inner if isinstance(inner, dict) else resp

    if isinstance(resp, str):
        try:
            parsed = json.loads(resp)
            return parsed if isinstance(parsed, dict) else {"result": parsed}
        except (json.JSONDecodeError, TypeError):
            return {"raw": resp}

    return None
