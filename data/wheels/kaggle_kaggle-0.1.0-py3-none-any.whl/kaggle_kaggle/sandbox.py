"""Code sandbox for Kaggle-in-Kaggle evaluations.

Provides an isolated execution environment via Docker containers
for running arbitrary shell commands and managing files.
"""

from __future__ import annotations

import json
import logging
import posixpath
import shlex
import time
from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
from typing import Any, Literal

from google.adk.code_executors.base_code_executor import BaseCodeExecutor
from google.adk.code_executors.code_execution_utils import CodeExecutionInput, CodeExecutionResult
from kaggle_kaggle.containers import DockerContainer
from pydantic import ConfigDict
from typing_extensions import override

logger = logging.getLogger(__name__)

DEFAULT_IMAGE = "gcr.io/kaggle-images/python"


@dataclass
class ExecutionResult:
    """Result of a command execution in the sandbox."""

    status: Literal["ok", "error", "timeout"]
    stdout: str = ""
    stderr: str = ""
    exit_code: int | None = None
    duration_seconds: float = 0.0

    def to_json(self, max_stdout_chars: int = 5000) -> str:
        """Serialize to JSON string for the agent."""
        data = asdict(self)

        if data["stdout"] and len(data["stdout"]) > max_stdout_chars:
            data["stdout"] = data["stdout"][:max_stdout_chars] + "... [truncated]"

        if data["stderr"] and len(data["stderr"]) > max_stdout_chars:
            data["stderr"] = data["stderr"][:max_stdout_chars] + "... [truncated]"

        filtered = {k: v for k, v in data.items() if v is not None and v != ""}
        return json.dumps(filtered)


class CodeSandbox(ABC):
    """Abstract interface for sandboxed code execution."""

    @abstractmethod
    def initialize(self, files: dict[str, str | bytes]) -> None:
        """Write initial files into the sandbox working directory.

        Args:
            files: Mapping of {relative_path: content}. String content is
                written as UTF-8 text; bytes content is written as-is.
        """
        ...

    @abstractmethod
    def run_command(self, command: str, timeout: int = 300) -> ExecutionResult:
        """Execute a shell command in the sandbox.

        Args:
            command: Shell command string (e.g., "python3 script.py").
            timeout: Max execution time in seconds.

        Returns:
            ExecutionResult with stdout, stderr, and exit code.
        """
        ...

    @abstractmethod
    def write_file(self, path: str, content: str | bytes) -> None:
        """Write a file into the sandbox working directory.

        Args:
            path: Relative path within the working directory.
            content: File content as string or bytes.
        """
        ...

    @abstractmethod
    def read_file(self, path: str) -> str:
        """Read a file from the sandbox working directory.

        Args:
            path: Relative path within the working directory.

        Returns:
            File content as a string.
        """
        ...

    @abstractmethod
    def reset(self) -> None:
        """Reset the sandbox working directory to its initial state."""
        ...

    @abstractmethod
    def close(self) -> None:
        """Close the sandbox and release underlying resources."""
        ...

    @property
    @abstractmethod
    def work_dir(self) -> str:
        """Return the sandbox's working directory path (inside container)."""
        ...


class DockerSandbox(CodeSandbox):
    """Docker-based sandbox for isolated code execution.

    Runs agent code inside a Docker container (e.g., the official Kaggle
    Python image), providing full OS-level isolation. Files are transferred
    via tarball archives since on-site Kaggle Docker doesn't support
    bind mounts.

    Usage::

        sandbox = DockerSandbox()
        sandbox.initialize({
            "train.csv": train_df.to_csv(index=False),
            "test.csv": test_df.to_csv(index=False),
        })
        result = sandbox.run_command("python3 -c 'import pandas; print(pandas.read_csv(\"train.csv\").shape)'")
        sandbox.close()
    """

    def __init__(
        self,
        *,
        image: str = DEFAULT_IMAGE,
        work_dir: str = "/work",
    ) -> None:
        """Create a new DockerSandbox.

        Args:
            image: Docker image to use.
            work_dir: Working directory inside the container.
        """
        self._image = image
        self._work_dir = work_dir
        self._container: DockerContainer | None = None
        self._initial_files: dict[str, str | bytes] = {}

    @property
    def work_dir(self) -> str:
        return self._work_dir

    def initialize(self, files: dict[str, str | bytes]) -> None:
        """Start the container and write initial files.

        Args:
            files: Mapping of {relative_path: content} to write into the
                working directory. For example:
                {"train.csv": "a,b\\n1,2", "test.csv": "a\\n3"}
        """
        logger.debug("Starting DockerSandbox (image=%s)...", self._image)
        self._container = DockerContainer(self._image)
        self._container.__enter__()

        logger.debug("Creating working directory %s...", self._work_dir)
        self._container.run_command(f"mkdir -p {shlex.quote(self._work_dir)}")

        self._initial_files = dict(files)

        logger.debug("Writing %d file(s) to sandbox...", len(files))
        self._write_files(files)

        logger.info(
            "DockerSandbox initialized: image=%s, work_dir=%s, files=%s",
            self._image,
            self._work_dir,
            list(files.keys()),
        )

    def run_command(self, command: str, timeout: int = 300) -> ExecutionResult:
        """Execute a shell command in the container.

        The command runs in the sandbox working directory.

        Args:
            command: Shell command string.
            timeout: Max execution time in seconds (currently advisory;
                Docker exec_run doesn't natively support timeout).

        Returns:
            ExecutionResult with stdout/stderr and exit code.
        """
        if not self._container:
            return ExecutionResult(
                status="error",
                stderr="Sandbox is not running",
                exit_code=-1,
            )

        start_time = time.perf_counter()

        try:
            wrapped_command = f"timeout -k 10s {timeout}s sh -c {shlex.quote(command)}"
            exit_code, stdout_str, stderr_str = self._container.run_command(
                wrapped_command, workdir=self._work_dir
            )
            duration = time.perf_counter() - start_time

            if exit_code == 124 or exit_code == 137:
                return ExecutionResult(
                    status="timeout",
                    stdout=stdout_str,
                    stderr=stderr_str,
                    exit_code=exit_code,
                    duration_seconds=round(duration, 3),
                )
            elif exit_code == 0:
                return ExecutionResult(
                    status="ok",
                    stdout=stdout_str,
                    stderr=stderr_str,
                    exit_code=exit_code,
                    duration_seconds=round(duration, 3),
                )
            else:
                return ExecutionResult(
                    status="error",
                    stdout=stdout_str,
                    stderr=stderr_str,
                    exit_code=exit_code,
                    duration_seconds=round(duration, 3),
                )

        except Exception as e:
            duration = time.perf_counter() - start_time
            return ExecutionResult(
                status="error",
                stderr=str(e),
                exit_code=-1,
                duration_seconds=round(duration, 3),
            )

    def write_file(self, path: str, content: str | bytes) -> None:
        """Write a file into the sandbox working directory.

        Args:
            path: Relative path within the working directory.
            content: File content as string or bytes.
        """
        if not self._container:
            raise RuntimeError("Sandbox is not running")

        full_path = self._safe_path(path)
        self._container.write_file(full_path, content)

    def read_file(self, path: str) -> str:
        """Read a file from the sandbox working directory.

        Args:
            path: Relative path within the working directory.

        Returns:
            File content as a string.

        Raises:
            FileNotFoundError: If the file doesn't exist.
            RuntimeError: On other read errors or if sandbox is not running.
        """
        if not self._container:
            raise RuntimeError("Sandbox is not running")

        full_path = self._safe_path(path)
        return self._container.read_file(full_path)

    def reset(self) -> None:
        """Reset the working directory to its initial state."""
        if not self._container:
            return

        work_dir_quoted = shlex.quote(self._work_dir)
        self._container.run_command(
            f"rm -rf {work_dir_quoted} && mkdir -p {work_dir_quoted}"
        )

        self._write_files(self._initial_files)

    def close(self) -> None:
        """Stop and remove the Docker container."""
        if self._container:
            self._container.__exit__(None, None, None)
            self._container = None

    def __del__(self) -> None:
        self.close()

    def _write_files(self, files: dict[str, str | bytes]) -> None:
        """Write a batch of files into the working directory."""
        if not self._container:
            raise RuntimeError("Sandbox is not running")
        for path, content in files.items():
            full_path = self._safe_path(path)
            self._container.write_file(full_path, content)

    def _safe_path(self, path: str) -> str:
        """Join and normalize path, ensuring it stays within the sandbox."""
        safe_path = posixpath.normpath(posixpath.join(self._work_dir, path))
        if not (
            safe_path.startswith(self._work_dir + "/") or safe_path == self._work_dir
        ):
            raise ValueError(f"Path escapes sandbox: {path!r}")
        return safe_path


class KaggleSandboxCodeExecutor(BaseCodeExecutor):
    """Executes ADK code blocks and skill scripts inside kaggle-kaggle's persistent Docker sandbox."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    sandbox: CodeSandbox
    start_time: float | None = None
    max_time_minutes: int | None = None

    @override
    def execute_code(
        self, invocation_context: Any, code_execution_input: CodeExecutionInput
    ) -> CodeExecutionResult:
        temp_filename = ".adk_exec.py"
        target_path = posixpath.join(self.sandbox.work_dir, temp_filename)
        self.sandbox.write_file(temp_filename, code_execution_input.code)

        wrapped_cmd = f"python3 {shlex.quote(target_path)}"
        
        fallback_timeout = self.timeout_seconds if self.timeout_seconds is not None else 300
        if self.start_time is not None and self.max_time_minutes is not None:
            elapsed = time.perf_counter() - self.start_time
            remaining = max(0.0, (self.max_time_minutes * 60) - elapsed)
            timeout = max(1, int(min(fallback_timeout, remaining)))
        else:
            timeout = fallback_timeout

        try:
            res = self.sandbox.run_command(wrapped_cmd, timeout=timeout)
        finally:
            self.sandbox.run_command(f"rm -f {shlex.quote(target_path)}")

        return CodeExecutionResult(
            stdout=res.stdout,
            stderr=res.stderr if res.status != "ok" else "",
            output_files=[],
        )
