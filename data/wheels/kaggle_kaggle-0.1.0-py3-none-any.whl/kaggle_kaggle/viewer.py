"""Post-session trace viewer for Kaggle-in-Kaggle evaluations.

Renders a self-contained HTML document (embedded CSS + vanilla JS) inside a
Jupyter notebook cell.  No widget dependencies — works in JupyterLab, Colab,
VS Code notebooks, and nbviewer.

Usage::

    from kaggle_kaggle.viewer import TraceViewer

    # From a live ProblemResult
    viewer = TraceViewer(result)
    viewer.show()

    # From a saved trace JSON
    viewer = TraceViewer.from_json("trace_toy_binary.json")
    viewer.show()

    # Jupyter auto-display (just put viewer on the last line of a cell)
    viewer = TraceViewer(result)
    viewer  # renders automatically via _repr_html_
"""

from __future__ import annotations

import json
import math
import time
from pathlib import Path
from typing import Any, TYPE_CHECKING

from kaggle_kaggle.trace import SessionTrace, TraceEntry

if TYPE_CHECKING:
    from kaggle_kaggle.evaluation import ProblemResult


# ---------------------------------------------------------------------------
# HTML/CSS/JS constants
# ---------------------------------------------------------------------------

_CSS = """
:root {
  --bg: #1e1e2e;
  --surface: #252535;
  --surface2: #2e2e42;
  --border: #3a3a52;
  --text: #cdd6f4;
  --text-dim: #6c7086;
  --text-muted: #45475a;
  --accent: #89b4fa;
  --green: #a6e3a1;
  --yellow: #f9e2af;
  --red: #f38ba8;
  --purple: #cba6f7;
  --teal: #94e2d5;
  --orange: #fab387;
  --pink: #f5c2e7;
  --mono: "JetBrains Mono", "Fira Code", "Cascadia Code", monospace;
}

.kk-viewer {
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
  font-size: 13px;
  background: var(--bg);
  color: var(--text);
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid var(--border);
  max-width: 100%;
}

/* ── Summary card ────────────────────────────────────────────────── */

.kk-summary {
  padding: 16px 20px;
  background: var(--surface);
  border-bottom: 1px solid var(--border);
}

.kk-summary-header {
  display: flex;
  align-items: baseline;
  gap: 12px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.kk-problem-id {
  font-size: 16px;
  font-weight: 700;
  color: var(--accent);
}

.kk-metric {
  color: var(--text-dim);
  font-size: 12px;
}

.kk-status-badge {
  font-size: 11px;
  font-weight: 600;
  padding: 2px 8px;
  border-radius: 10px;
  margin-left: auto;
}

.kk-status-completed  { background: #1a3a1a; color: var(--green); }
.kk-status-interrupted { background: #3a2a10; color: var(--yellow); }
.kk-status-budget_exceeded { background: #3a1a1a; color: var(--red); }
.kk-status-agent_error { background: #3a1a1a; color: var(--red); }
.kk-status-no_submissions { background: #2a2a3a; color: var(--text-dim); }
.kk-status-unknown { background: #2a2a3a; color: var(--text-dim); }

.kk-stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(160px, 1fr));
  gap: 8px 20px;
  margin-bottom: 12px;
}

.kk-stat {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.kk-stat-label {
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-dim);
}

.kk-stat-value {
  font-size: 13px;
  font-weight: 600;
  color: var(--text);
}

.kk-stat-value.highlight { color: var(--green); font-size: 15px; }
.kk-stat-value.warn      { color: var(--yellow); }
.kk-stat-value.error     { color: var(--red); }

.kk-scores-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
  margin-top: 8px;
}

.kk-scores-table th {
  text-align: left;
  color: var(--text-dim);
  font-weight: 500;
  padding: 3px 8px;
  border-bottom: 1px solid var(--border);
}

.kk-scores-table td {
  padding: 3px 8px;
  font-family: var(--mono);
  font-size: 12px;
}

.kk-scores-table .sub-id   { color: var(--text-dim); }
.kk-scores-table .selected { color: var(--green); }
.kk-scores-table .auto-sel { color: var(--yellow); }
.kk-scores-table .best     { font-weight: 700; }

.kk-tool-breakdown {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 8px;
}

.kk-tool-chip {
  font-size: 11px;
  font-family: var(--mono);
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 4px;
  padding: 2px 8px;
  color: var(--teal);
}

/* ── Timeline ────────────────────────────────────────────────────── */

.kk-timeline-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 20px;
  background: var(--surface2);
  border-bottom: 1px solid var(--border);
  flex-wrap: wrap;
}

.kk-timeline-title {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-dim);
  text-transform: uppercase;
  letter-spacing: 0.06em;
  margin-right: 8px;
}

.kk-filter-btn {
  font-size: 11px;
  font-family: var(--mono);
  padding: 2px 8px;
  border-radius: 10px;
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-dim);
  cursor: pointer;
  transition: all 0.12s;
  white-space: nowrap;
}

.kk-filter-btn:hover  { border-color: var(--accent); color: var(--accent); }
.kk-filter-btn.active { background: var(--surface2); color: var(--text); border-color: var(--text-dim); }

.kk-expand-all-btn {
  margin-left: auto;
  font-size: 11px;
  padding: 2px 10px;
  border-radius: 4px;
  border: 1px solid var(--border);
  background: var(--surface);
  color: var(--text-dim);
  cursor: pointer;
}

.kk-expand-all-btn:hover { color: var(--accent); border-color: var(--accent); }

.kk-timeline-body {
  max-height: 640px;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: var(--border) transparent;
}

/* ── Timeline rows ───────────────────────────────────────────────── */

.kk-entry {
  border-bottom: 1px solid var(--border);
  transition: background 0.1s;
}

.kk-entry:last-child { border-bottom: none; }
.kk-entry:hover > .kk-entry-row { background: var(--surface2); }

.kk-entry.hidden { display: none; }

.kk-entry-row {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  padding: 6px 16px 6px 12px;
  cursor: pointer;
  user-select: none;
}

.kk-entry.sub-agent > .kk-entry-row {
  padding-left: 32px;
}

.kk-ts {
  font-family: var(--mono);
  font-size: 11px;
  color: var(--text-muted);
  min-width: 54px;
  padding-top: 1px;
  flex-shrink: 0;
}

.kk-badge {
  font-size: 10px;
  font-weight: 700;
  padding: 1px 6px;
  border-radius: 3px;
  min-width: 80px;
  text-align: center;
  flex-shrink: 0;
  align-self: center;
}

.badge-thinking   { background: #2a1a4a; color: var(--purple); border: 1px solid #4a2a6a; }
.badge-tool_call  { background: #1a2a4a; color: var(--accent); border: 1px solid #2a3a6a; }
.badge-tool_response { background: #1a3a2a; color: var(--green); border: 1px solid #2a5a3a; }
.badge-text       { background: #3a3010; color: var(--yellow); border: 1px solid #5a4a18; }
.badge-final      { background: #1a3a1a; color: var(--green); border: 1px solid #2a5a2a; }
.badge-error      { background: #3a1a1a; color: var(--red);   border: 1px solid #5a2a2a; }
.badge-usage      { background: #2a2a3a; color: var(--text-dim); border: 1px solid #3a3a4a; }
.badge-system_instruction { background: #1a2a3a; color: var(--teal); border: 1px solid #2a3a4a; }
.badge-task_prompt { background: #2a1a3a; color: var(--pink); border: 1px solid #3a2a4a; }
.badge-problem_start { background: #2a2a3a; color: var(--text-dim); border: 1px solid #3a3a4a; }
.badge-budget_exceeded { background: #3a1a1a; color: var(--red); border: 1px solid #5a2a2a; }
.badge-interrupted { background: #3a2a10; color: var(--yellow); border: 1px solid #5a4018; }
.badge-custom     { background: #2a2a2a; color: var(--text-dim); border: 1px solid #3a3a3a; }

.kk-author {
  font-size: 10px;
  color: var(--text-muted);
  font-family: var(--mono);
  flex-shrink: 0;
  padding-top: 2px;
  min-width: 70px;
}

.kk-summary-line {
  flex: 1;
  font-size: 12px;
  color: var(--text);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  min-width: 0;
}

.kk-token-badge {
  font-size: 10px;
  font-family: var(--mono);
  color: var(--text-muted);
  background: var(--surface2);
  padding: 1px 5px;
  border-radius: 3px;
  flex-shrink: 0;
  white-space: nowrap;
}

.kk-toggle {
  font-size: 11px;
  color: var(--text-muted);
  flex-shrink: 0;
  width: 14px;
  text-align: center;
}

/* ── Expanded detail ─────────────────────────────────────────────── */

.kk-detail {
  display: none;
  padding: 8px 16px 12px 60px;
  background: var(--surface);
  border-top: 1px solid var(--border);
}

.kk-entry.expanded > .kk-detail { display: block; }

.kk-detail-section {
  margin-top: 6px;
}

.kk-detail-label {
  font-size: 10px;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-dim);
  margin-bottom: 4px;
  font-weight: 600;
}

.kk-detail-content {
  font-family: var(--mono);
  font-size: 12px;
  background: var(--surface2);
  border: 1px solid var(--border);
  border-radius: 4px;
  padding: 8px 10px;
  white-space: pre-wrap;
  word-break: break-word;
  color: var(--text);
  max-height: 400px;
  overflow-y: auto;
  scrollbar-width: thin;
  scrollbar-color: var(--border) transparent;
  line-height: 1.5;
}

/* ── Tool call pairing connector ─────────────────────────────────── */

.kk-entry.tool-call-paired > .kk-entry-row {
  border-left: 2px solid var(--accent);
  padding-left: 10px;
}

.kk-entry.tool-response-paired > .kk-entry-row {
  border-left: 2px solid var(--green);
  padding-left: 10px;
}
"""

_JS = """
(function() {
  var viewer = document.getElementById('__VIEWER_ID__');
  if (!viewer) return;

  // ── Expand/collapse toggle ────────────────────────────────────────
  viewer.querySelectorAll('.kk-entry-row').forEach(function(row) {
    row.addEventListener('click', function() {
      var entry = row.parentElement;
      var wasExpanded = entry.classList.contains('expanded');
      entry.classList.toggle('expanded', !wasExpanded);
      var toggle = row.querySelector('.kk-toggle');
      if (toggle) toggle.textContent = wasExpanded ? '▶' : '▼';
    });
  });

  // ── Filter buttons ────────────────────────────────────────────────
  viewer.querySelectorAll('.kk-filter-btn[data-type]').forEach(function(btn) {
    btn.addEventListener('click', function() {
      btn.classList.toggle('active');
      var type = btn.getAttribute('data-type');
      var hidden = btn.classList.contains('active');
      viewer.querySelectorAll('.kk-entry[data-type="' + type + '"]').forEach(function(e) {
        e.classList.toggle('hidden', hidden);
      });
    });
  });

  // ── Expand all / Collapse all ─────────────────────────────────────
  var expandBtn = viewer.querySelector('.kk-expand-all-btn');
  if (expandBtn) {
    var allExpanded = false;
    expandBtn.addEventListener('click', function() {
      allExpanded = !allExpanded;
      expandBtn.textContent = allExpanded ? 'Collapse all' : 'Expand all';
      viewer.querySelectorAll('.kk-entry').forEach(function(entry) {
        if (!entry.classList.contains('hidden')) {
          entry.classList.toggle('expanded', allExpanded);
          var toggle = entry.querySelector('.kk-toggle');
          if (toggle) toggle.textContent = allExpanded ? '▼' : '▶';
        }
      });
    });
  }
})();
"""


# ---------------------------------------------------------------------------
# Helper functions for rendering
# ---------------------------------------------------------------------------


def _esc(text: str) -> str:
    """Escape text for safe HTML embedding."""
    return (
        text.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def _badge(event_type: str) -> str:
    """Render an event type badge."""
    known = {
        "thinking": "thinking",
        "tool_call": "tool_call",
        "tool_response": "tool_response",
        "text": "text",
        "final": "final",
        "error": "error",
        "usage": "usage",
        "system_instruction": "system_instruction",
        "task_prompt": "task_prompt",
        "problem_start": "problem_start",
        "budget_exceeded": "budget_exceeded",
        "interrupted": "interrupted",
    }
    cls = known.get(event_type, "custom")
    label = event_type.replace("_", " ")
    return f'<span class="kk-badge badge-{cls}">{_esc(label)}</span>'


def _format_elapsed(elapsed: float) -> str:
    """Format elapsed seconds as a compact timestamp string."""
    if elapsed < 60:
        return f"{elapsed:5.1f}s"
    m, s = divmod(int(elapsed), 60)
    return f"{m}m{s:02d}s"


def _summary_line(entry: TraceEntry) -> str:
    """Produce a one-line summary of a trace entry for the timeline row."""
    t = entry.event_type

    if t == "thinking":
        n = len(entry.content)
        preview = entry.content[:120].replace("\n", " ")
        if len(entry.content) > 120:
            preview += "…"
        return f"<em>({n} chars)</em> {_esc(preview)}"

    if t == "tool_call":
        args_preview = ""
        if entry.tool_args:
            flat = json.dumps(entry.tool_args, default=str)
            args_preview = flat[:100] + "…" if len(flat) > 100 else flat
        icon = "🤖"
        if entry.tool_name == "run_command":
            icon = "🔧"
        elif entry.tool_name == "write_file":
            icon = "📝"
        elif entry.tool_name == "submit_predictions":
            icon = "📊"
        elif entry.tool_name == "select_submission":
            icon = "✅"
        elif entry.tool_name == "get_status":
            icon = "📋"
        return f"{icon} <strong>{_esc(entry.tool_name)}</strong> {_esc(args_preview)}"

    if t == "tool_response":
        preview = entry.tool_result
        if entry.tool_name == "submit_predictions":
            try:
                p = json.loads(entry.tool_result)
                if p.get("status") == "ok":
                    preview = f"score={p.get('score', '?')} (best={p.get('best_score', '?')}, {p.get('remaining_submissions', '?')} left)"
                else:
                    preview = f"error: {p.get('error_message', 'error')}"
            except Exception:
                pass
        elif entry.tool_name == "run_command":
            try:
                p = json.loads(entry.tool_result)
                if p.get("status") == "error":
                    preview = f"error (exit {p.get('exit_code', '?')}): {p.get('stderr', '')[:120]}"
                elif p.get("status") == "ok":
                    preview = p.get("stdout", "")[:120]
            except Exception:
                pass
        elif entry.tool_name == "select_submission":
            try:
                p = json.loads(entry.tool_result)
                if p.get("status") == "ok":
                    preview = f"selected: {p.get('selected', [])}"
                else:
                    preview = f"select error: {p.get('error_message', 'error')}"
            except Exception:
                pass
        if len(preview) > 120:
            preview = preview[:120] + "…"
        return f"→ <strong>{_esc(entry.tool_name)}</strong>: {_esc(preview)}"

    if t in ("text", "final"):
        preview = entry.content[:160].replace("\n", " ")
        if len(entry.content) > 160:
            preview += "…"
        return _esc(preview)

    if t == "system_instruction":
        lines = entry.content.splitlines()
        preview = lines[0][:120] if lines else ""
        return _esc(preview)

    if t == "task_prompt":
        lines = entry.content.splitlines()
        preview = lines[0][:120] if lines else ""
        return _esc(preview)

    if t == "usage":
        if entry.usage:
            total = entry.usage.get("total_tokens", 0)
            prompt = entry.usage.get("prompt_tokens", 0)
            comp = entry.usage.get("completion_tokens", 0)
            cached = entry.usage.get("cached_tokens", 0)
            if cached > 0:
                return f"in:{prompt:,} [{cached:,} cached] + out:{comp:,} = {total:,} tokens"
            return f"in:{prompt:,} + out:{comp:,} = {total:,} tokens"
        return ""

    if t == "problem_start":
        return _esc(entry.content)

    # Generic fallback
    preview = entry.content[:160].replace("\n", " ") if entry.content else ""
    if len(entry.content) > 160:
        preview += "…"
    return _esc(preview)


def _detail_sections(entry: TraceEntry) -> list[tuple[str, str]]:
    """Return (label, preformatted content) pairs for the expanded detail view."""
    t = entry.event_type
    sections: list[tuple[str, str]] = []

    if t == "thinking":
        sections.append(("Thought", entry.content))

    elif t == "tool_call":
        if entry.tool_args is not None:
            sections.append(("Args", json.dumps(entry.tool_args, indent=2, default=str)))

    elif t == "tool_response":
        if entry.tool_result:
            try:
                parsed = json.loads(entry.tool_result)
                sections.append(("Response", json.dumps(parsed, indent=2, default=str)))
            except (json.JSONDecodeError, ValueError):
                sections.append(("Response", entry.tool_result))

    elif t in ("text", "final"):
        sections.append(("Message", entry.content))

    elif t == "system_instruction":
        sections.append(("System Instruction", entry.content))

    elif t == "task_prompt":
        sections.append(("Task Prompt", entry.content))

    elif t == "problem_start":
        if entry.metadata:
            sections.append(("Metadata", json.dumps(entry.metadata, indent=2, default=str)))

    elif entry.content:
        sections.append(("Content", entry.content))

    if entry.metadata and t not in ("problem_start",):
        sections.append(("Metadata", json.dumps(entry.metadata, indent=2, default=str)))

    if entry.usage:
        sections.append(("Token Usage", json.dumps(entry.usage, indent=2, default=str)))

    if entry.model_version:
        sections.append(("Model", entry.model_version))

    return sections


def _token_badge(entry: TraceEntry) -> str:
    """Render a small token count badge if this entry has usage data."""
    if not entry.usage:
        return ""
    total = entry.usage.get("total_tokens", 0)
    if not total:
        return ""
    cached = entry.usage.get("cached_tokens", 0)
    if cached > 0:
        label = f"{total:,} tok ({cached:,} cached)"
    else:
        label = f"{total:,} tok"
    return f'<span class="kk-token-badge">{_esc(label)}</span>'


# ---------------------------------------------------------------------------
# Result metadata container (decoupled from ProblemResult for JSON loading)
# ---------------------------------------------------------------------------


class _ResultMeta:
    """Lightweight container for result-level metadata used by the viewer."""

    def __init__(self) -> None:
        self.problem_id: str = ""
        self.metric: str = ""
        self.end_status: str = "unknown"
        self.wall_time_seconds: float = 0.0
        self.tool_calls_used: int = 0
        self.submissions_used: int = 0
        self.total_cost_usd: float = 0.0
        self.max_budget_usd: float = 0.0
        self.max_tool_calls: int = 0
        self.max_submissions: int = 0
        self.max_time_minutes: float = 0.0
        self.total_input_tokens: int = 0
        self.total_cached_input_tokens: int = 0
        self.last_input_tokens: int = 0
        self.total_output_tokens: int = 0
        self.llm_calls: int = 0
        self.public_scores: dict[str, float] = {}
        self.private_scores: dict[str, float] = {}
        self.best_public_score: float = float("nan")
        self.best_private_score: float = float("nan")
        self.final_score: float = float("nan")
        self.selected_ids: list[str] = []
        self.auto_selected_ids: list[str] = []
        self.higher_is_better: bool = True


# ---------------------------------------------------------------------------
# TraceViewer
# ---------------------------------------------------------------------------


class TraceViewer:
    """Post-session trace viewer that renders as self-contained HTML.

    Displays a summary card and an interactive, collapsible timeline of all
    trace entries including the system instruction, task prompt, and all
    model events.  Designed for use in Jupyter notebooks.

    Usage::

        # From a live ProblemResult
        viewer = TraceViewer(result)
        viewer.show()

        # From a saved trace JSON file
        viewer = TraceViewer.from_json("trace_toy_binary.json")
        viewer.show()

        # Jupyter auto-display
        viewer  # triggers _repr_html_

    Args:
        result: A completed :class:`~kaggle_kaggle.evaluation.ProblemResult`.
            Either ``result`` or ``trace`` must be provided.
        trace: A bare :class:`~kaggle_kaggle.trace.SessionTrace`.  Use this
            when you have a trace but no ``ProblemResult`` (e.g. after loading
            from JSON via :meth:`from_json`).
        meta: Internal result-level metadata.  Populated automatically from
            ``result`` or from the JSON envelope when loading from file.
    """

    def __init__(
        self,
        result: "ProblemResult | None" = None,
        *,
        trace: SessionTrace | None = None,
        _meta: _ResultMeta | None = None,
    ) -> None:
        if result is not None:
            self._trace = result.trace or SessionTrace()
            self._meta = _ResultMeta()
            m = self._meta
            m.problem_id = result.problem_id
            m.metric = result.metric
            m.end_status = result.end_status
            m.wall_time_seconds = result.wall_time_seconds
            m.tool_calls_used = result.tool_calls_used if isinstance(result.tool_calls_used, int) else 0
            m.submissions_used = result.submissions_used if isinstance(result.submissions_used, int) else 0
            m.total_cost_usd = result.total_cost_usd if isinstance(result.total_cost_usd, (int, float)) else 0.0
            m.max_budget_usd = result.max_budget_usd if isinstance(result.max_budget_usd, (int, float)) else 0.0
            m.max_tool_calls = getattr(result, "max_tool_calls", 0) if isinstance(getattr(result, "max_tool_calls", 0), int) else 0
            m.max_submissions = getattr(result, "max_submissions", 0) if isinstance(getattr(result, "max_submissions", 0), int) else 0
            m.max_time_minutes = getattr(result, "max_time_minutes", 0.0) if isinstance(getattr(result, "max_time_minutes", 0.0), (int, float)) else 0.0
            m.total_input_tokens = result.total_input_tokens if isinstance(result.total_input_tokens, int) else 0
            m.total_cached_input_tokens = getattr(result, "total_cached_input_tokens", 0) if isinstance(getattr(result, "total_cached_input_tokens", 0), int) else 0
            m.total_output_tokens = result.total_output_tokens if isinstance(result.total_output_tokens, int) else 0
            m.llm_calls = result.llm_calls if isinstance(result.llm_calls, int) else 0
            if result.trace and result.trace.entries:
                for e in reversed(result.trace.entries):
                    if e.usage and "prompt_tokens" in e.usage:
                        m.last_input_tokens = e.usage["prompt_tokens"]
                        break
            m.public_scores = result.public_scores
            m.private_scores = result.private_scores
            m.best_public_score = result.best_public_score
            m.best_private_score = result.best_private_score
            m.final_score = result.final_score
            m.selected_ids = result.selected_ids
            m.auto_selected_ids = result.auto_selected_ids
            # higher_is_better isn't stored on ProblemResult directly, so
            # we infer it from the trace summary if available.
            m.higher_is_better = True
        elif trace is not None:
            self._trace = trace
            self._meta = _meta or _ResultMeta()
        else:
            raise ValueError("Provide either result or trace.")

    @classmethod
    def from_json(cls, path: str | Path) -> "TraceViewer":
        """Load a viewer from a saved trace JSON file.

        The JSON file must be in the format produced by
        :meth:`~kaggle_kaggle.trace.SessionTrace.save`.

        Args:
            path: Path to the trace JSON file.

        Returns:
            A :class:`TraceViewer` ready to render.
        """
        path = Path(path)
        with open(path) as f:
            data: dict[str, Any] = json.load(f)

        trace = SessionTrace()
        trace.start()

        # Reconstruct TraceEntry objects from the serialised entries list.
        # The JSON format uses shorter key names than the dataclass fields.
        for e in data.get("entries", []):
            trace._add(
                TraceEntry(
                    timestamp=e.get("timestamp") if e.get("timestamp") is not None else 0.0,
                    elapsed=e.get("elapsed_s") if e.get("elapsed_s") is not None else 0.0,
                    event_type=e.get("type") if e.get("type") is not None else "custom",
                    author=e.get("author") if e.get("author") is not None else "",
                    content=e.get("content") if e.get("content") is not None else "",
                    tool_name=e.get("tool") if e.get("tool") is not None else "",
                    tool_args=e.get("args"),
                    tool_result=e.get("result") if e.get("result") is not None else "",
                    usage=e.get("usage"),
                    model_version=e.get("model") if e.get("model") is not None else "",
                    metadata=e.get("metadata"),
                )
            )

        # Build metadata from the JSON envelope summary block.
        meta = _ResultMeta()
        summary = data.get("summary", {})
        meta.problem_id = path.stem.removeprefix("trace_")
        meta.wall_time_seconds = data.get("duration_s", 0.0)
        meta.total_input_tokens = summary.get("total_prompt_tokens", 0)
        meta.total_cached_input_tokens = summary.get("total_cached_prompt_tokens", 0)
        meta.total_output_tokens = summary.get("total_completion_tokens", 0)
        meta.llm_calls = summary.get("llm_calls", 0)
        meta.max_tool_calls = summary.get("max_tool_calls", 0)
        meta.max_submissions = summary.get("max_submissions", 0)
        meta.max_time_minutes = summary.get("max_time_minutes", 0.0)

        # Derive status from custom entries if present.
        for e in trace.entries:
            if e.event_type in ("interrupted", "budget_exceeded", "error"):
                meta.end_status = e.event_type
                break
        else:
            meta.end_status = "completed"

        # Recover problem metadata from problem_start entry.
        for e in trace.entries:
            if e.event_type == "problem_start" and e.metadata:
                meta.metric = e.metadata.get("metric", "")
                break

        return cls(trace=trace, _meta=meta)

    # ── Rendering ────────────────────────────────────────────────────

    def _repr_html_(self) -> str:
        """Return the full viewer HTML for Jupyter auto-display."""
        return self._render_html()

    def show(self) -> None:
        """Display the full viewer (summary + timeline) in a Jupyter cell."""
        try:
            from IPython.display import HTML, display  # type: ignore
            display(HTML(self._render_html()))
        except ImportError:
            print(self._trace.to_markdown())

    def summary(self) -> None:
        """Display the summary card only."""
        try:
            from IPython.display import HTML, display  # type: ignore
            html = (
                f'<div class="kk-viewer" style="font-family: sans-serif;">'
                f"<style>{_CSS}</style>"
                f"{self._render_summary()}"
                f"</div>"
            )
            display(HTML(html))
        except ImportError:
            m = self._meta
            print(f"Problem: {m.problem_id}  Metric: {m.metric}  Status: {m.end_status}")

    def timeline(self) -> None:
        """Display the timeline only (no summary card)."""
        try:
            from IPython.display import HTML, display  # type: ignore
            viewer_id = f"kk-viewer-{int(time.time() * 1000)}"
            html = (
                f'<div class="kk-viewer" id="{viewer_id}" style="font-family: sans-serif;">'
                f"<style>{_CSS}</style>"
                f"{self._render_timeline()}"
                f"<script>{_JS.replace('__VIEWER_ID__', viewer_id)}</script>"
                f"</div>"
            )
            display(HTML(html))
        except ImportError:
            print(self._trace.to_markdown())

    def _render_html(self) -> str:
        """Render the complete viewer HTML string."""
        viewer_id = f"kk-viewer-{int(time.time() * 1000)}"
        return (
            f'<div class="kk-viewer" id="{viewer_id}">'
            f"<style>{_CSS}</style>"
            f"{self._render_summary()}"
            f"{self._render_timeline()}"
            f"<script>{_JS.replace('__VIEWER_ID__', viewer_id)}</script>"
            f"</div>"
        )

    # ── Summary card ─────────────────────────────────────────────────

    def _render_summary(self) -> str:
        m = self._meta
        trace = self._trace
        summary = trace.summarize()

        # Status badge
        status_cls = f"kk-status-{m.end_status.replace(' ', '_')}"
        status_icon = {
            "completed": "✓",
            "interrupted": "⚠",
            "budget_exceeded": "💸",
            "agent_error": "✗",
            "no_submissions": "—",
        }.get(m.end_status, "?")
        status_badge = (
            f'<span class="kk-status-badge {_esc(status_cls)}">'
            f"{status_icon} {_esc(m.end_status.replace('_', ' '))}"
            f"</span>"
        )

        # Direction arrow
        direction = "↑ higher" if m.higher_is_better else "↓ lower"

        header = (
            f'<div class="kk-summary-header">'
            f'<span class="kk-problem-id">{_esc(m.problem_id or "Trace")}</span>'
            + (
                f'<span class="kk-metric">{_esc(m.metric)} ({direction})</span>'
                if m.metric
                else ""
            )
            + status_badge
            + "</div>"
        )

        # Stats grid
        total_tokens = m.total_input_tokens + m.total_output_tokens
        wall_time = f"{m.wall_time_seconds:.1f}s" if m.wall_time_seconds else f"{trace.duration:.1f}s"

        def _stat(label: str, value: str, cls: str = "") -> str:
            cls_attr = f' class="kk-stat-value {cls}"' if cls else ' class="kk-stat-value"'
            return (
                f'<div class="kk-stat">'
                f'<span class="kk-stat-label">{_esc(label)}</span>'
                f"<span{cls_attr}>{value}</span>"
                f"</div>"
            )

        final_score_str = (
            f"{m.final_score:.6f}" if not math.isnan(m.final_score) else "—"
        )
        best_public_str = (
            f"{m.best_public_score:.6f}" if not math.isnan(m.best_public_score) else "—"
        )

        stats = (
            f'<div class="kk-stats-grid">'
            + _stat("Final Score", final_score_str, "highlight" if not math.isnan(m.final_score) else "")
            + _stat("Best Public", best_public_str)
            + _stat(
                "Wall Time",
                f"{wall_time} / {m.max_time_minutes}m" if m.max_time_minutes > 0 else wall_time,
                "warn" if m.max_time_minutes > 0 and m.wall_time_seconds / (m.max_time_minutes * 60) > 0.8 else "",
            )
            + _stat(
                "Tool Calls",
                f"{m.tool_calls_used} / {m.max_tool_calls}" if m.max_tool_calls > 0 else f"{m.tool_calls_used}",
                "warn" if m.max_tool_calls > 0 and m.tool_calls_used / m.max_tool_calls > 0.8 else "",
            )
            + _stat(
                "Submissions",
                f"{m.submissions_used} / {m.max_submissions}" if m.max_submissions > 0 else f"{m.submissions_used}",
                "warn" if m.max_submissions > 0 and m.submissions_used / m.max_submissions > 0.8 else "",
            )
            + _stat("LLM Calls", f"{summary.get('llm_calls', m.llm_calls) or m.llm_calls}")
            + _stat("Total Tokens", f"{total_tokens:,}" if total_tokens else f"{summary['total_tokens']:,}")
            + _stat(
                "Input Tokens",
                f"{m.total_input_tokens:,}" + (f" ({m.total_cached_input_tokens:,} cached)" if m.total_cached_input_tokens > 0 else ""),
            )
            + _stat("Output Tokens", f"{m.total_output_tokens:,}")
            + (
                _stat(
                    "Cost",
                    f"${m.total_cost_usd:.4f} / ${m.max_budget_usd:.2f}",
                    "warn" if m.max_budget_usd > 0 and m.total_cost_usd / m.max_budget_usd > 0.8 else "",
                )
                if m.max_budget_usd > 0
                else ""
            )
            + "</div>"
        )

        # Score table
        score_table = ""
        if m.public_scores:
            selected_set = set(m.selected_ids)
            auto_set = set(m.auto_selected_ids)

            best_pub = m.best_public_score
            best_priv = m.best_private_score

            rows = ""
            for sub_id in m.public_scores:
                pub = m.public_scores.get(sub_id, float("nan"))
                priv = m.private_scores.get(sub_id, float("nan"))

                if sub_id in selected_set:
                    sel_html = '<span class="selected">← selected</span>'
                elif sub_id in auto_set:
                    sel_html = '<span class="auto-sel">← auto</span>'
                else:
                    sel_html = ""

                pub_cls = "best" if not math.isnan(pub) and not math.isnan(best_pub) and math.isclose(pub, best_pub) else ""
                priv_cls = "best" if not math.isnan(priv) and not math.isnan(best_priv) and math.isclose(priv, best_priv) else ""

                rows += (
                    f"<tr>"
                    f'<td class="sub-id">{_esc(sub_id)}</td>'
                    f'<td class="{pub_cls}">{pub:.6f}</td>'
                    f'<td class="{priv_cls}">{priv:.6f}</td>'
                    f"<td>{sel_html}</td>"
                    f"</tr>"
                )

            score_table = (
                f'<table class="kk-scores-table">'
                f"<thead><tr>"
                f"<th>ID</th><th>Public</th><th>Private</th><th></th>"
                f"</tr></thead>"
                f"<tbody>{rows}</tbody>"
                f"</table>"
            )

        # Tool breakdown
        breakdown = summary.get("tool_call_breakdown", {})
        breakdown_html = ""
        if breakdown:
            chips = "".join(
                f'<span class="kk-tool-chip">{_esc(name)}: {count}</span>'
                for name, count in sorted(breakdown.items())
            )
            breakdown_html = f'<div class="kk-tool-breakdown">{chips}</div>'

        return (
            f'<div class="kk-summary">'
            + header
            + stats
            + score_table
            + breakdown_html
            + "</div>"
        )

    # ── Timeline ──────────────────────────────────────────────────────

    def _render_timeline(self) -> str:
        entries = self._trace.entries
        if not entries:
            return '<div class="kk-timeline-body" style="padding:16px;color:#6c7086;">No trace entries.</div>'

        # Determine the root author from the first agent event (not harness).
        root_author: str | None = None
        for e in entries:
            if e.author and e.author != "harness":
                root_author = e.author
                break

        # Collect event types present in the trace for filter buttons.
        present_types: list[str] = []
        seen: set[str] = set()
        for e in entries:
            if e.event_type not in seen:
                seen.add(e.event_type)
                present_types.append(e.event_type)

        # Filter button strip.
        filter_buttons = "".join(
            f'<button class="kk-filter-btn" data-type="{_esc(t)}">{_esc(t.replace("_", " "))}</button>'
            for t in present_types
        )

        header = (
            f'<div class="kk-timeline-header">'
            f'<span class="kk-timeline-title">Timeline</span>'
            + filter_buttons
            + '<button class="kk-expand-all-btn">Expand all</button>'
            + "</div>"
        )

        # Identify paired tool_call / tool_response entries (by tool name, in order).
        paired_calls: set[int] = set()
        paired_responses: set[int] = set()
        last_call_idx: dict[str, int] = {}
        for i, e in enumerate(entries):
            if e.event_type == "tool_call":
                last_call_idx[e.tool_name] = i
            elif e.event_type == "tool_response" and e.tool_name in last_call_idx:
                call_i = last_call_idx.pop(e.tool_name)
                paired_calls.add(call_i)
                paired_responses.add(i)

        # Render each entry row.
        rows = ""
        for i, entry in enumerate(entries):
            is_sub = bool(
                entry.author
                and root_author
                and entry.author != "harness"
                and entry.author != root_author
            )

            entry_classes = ["kk-entry"]
            if is_sub:
                entry_classes.append("sub-agent")
            if i in paired_calls:
                entry_classes.append("tool-call-paired")
            if i in paired_responses:
                entry_classes.append("tool-response-paired")

            # Author tag (only for non-harness, non-root events)
            author_html = ""
            if entry.author and entry.author != "harness":
                author_html = f'<span class="kk-author">{_esc(entry.author)}</span>'

            # Detail sections
            sections = _detail_sections(entry)
            detail_html = ""
            if sections:
                detail_html = '<div class="kk-detail">'
                for label, content in sections:
                    detail_html += (
                        f'<div class="kk-detail-section">'
                        f'<div class="kk-detail-label">{_esc(label)}</div>'
                        f'<div class="kk-detail-content">{_esc(content)}</div>'
                        f"</div>"
                    )
                detail_html += "</div>"

            toggle = '<span class="kk-toggle">▶</span>' if sections else '<span class="kk-toggle"> </span>'

            rows += (
                f'<div class="{" ".join(entry_classes)}" data-type="{_esc(entry.event_type)}">'
                f'<div class="kk-entry-row">'
                f'<span class="kk-ts">{_esc(_format_elapsed(entry.elapsed))}</span>'
                + _badge(entry.event_type)
                + author_html
                + f'<span class="kk-summary-line">{_summary_line(entry)}</span>'
                + _token_badge(entry)
                + toggle
                + "</div>"
                + detail_html
                + "</div>"
            )

        body = f'<div class="kk-timeline-body">{rows}</div>'
        return header + body
