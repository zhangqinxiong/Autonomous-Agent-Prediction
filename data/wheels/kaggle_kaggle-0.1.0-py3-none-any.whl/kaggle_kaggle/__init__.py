"""Public API for the kaggle-kaggle evaluation framework.

This package provides the core components for running and evaluating
autonomous machine learning agents in a Kaggle-like competitive environment.
"""

from kaggle_kaggle.budget import ModelPricing, PricingTable, TokenBudget, compute_cost
from kaggle_kaggle.config import BudgetConfig, EvaluationConfig, ProblemConfig
from kaggle_kaggle.context import KaggleKaggleContext, Submission
from kaggle_kaggle.display import EventDisplay, StatusPanel, print_results
from kaggle_kaggle.display_plugin import EventDisplayPlugin
from kaggle_kaggle.evaluation import (
    Evaluation,
    ProblemResult,
    evaluate,
    evaluate_sync,
    save_trace,
)
from kaggle_kaggle.sandbox import CodeSandbox, DockerSandbox, ExecutionResult
from kaggle_kaggle.scoring import (
    make_scorer,
    resolve_scorer,
    score_arrays,
    scorer_direction,
    scorer_name,
)
from kaggle_kaggle.trace import SessionTrace, TraceEntry
from kaggle_kaggle.viewer import TraceViewer

__all__ = [
    # Budget & Pricing
    "TokenBudget",
    "ModelPricing",
    "PricingTable",
    "compute_cost",
    # Config
    "BudgetConfig",
    "EvaluationConfig",
    "ProblemConfig",
    # Context
    "KaggleKaggleContext",
    "Submission",
    # Display
    "EventDisplay",
    "EventDisplayPlugin",
    "StatusPanel",
    "print_results",
    # Evaluation
    "Evaluation",
    "ProblemResult",
    "evaluate",
    "evaluate_sync",
    "save_trace",
    # Sandbox
    "CodeSandbox",
    "DockerSandbox",
    "ExecutionResult",
    # Scoring
    "make_scorer",
    "resolve_scorer",
    "score_arrays",
    "scorer_direction",
    "scorer_name",
    # Trace
    "SessionTrace",
    "TraceEntry",
    # Viewer
    "TraceViewer",
]
