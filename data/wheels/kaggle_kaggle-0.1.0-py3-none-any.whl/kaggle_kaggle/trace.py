"""Session trace recorder for Kaggle-in-Kaggle evaluations.

Captures every ADK event during an agent run and provides
structured output for debugging and analysis.
"""

from __future__ import annotations

import json
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Callable

from kaggle_kaggle.utils import unwrap_tool_response


def _truncate(text: str, limit: int = 200) -> str:
    """Truncate text to *limit* characters, appending '...' if needed."""
    return text[:limit] + "..." if len(text) > limit else text


def _format_content(
    text: str, limit: int | None, multiline_mode: str, label: str = ""
) -> str:
    """Format text with optional truncation and multiline handling."""
    if limit is not None and len(text) > limit:
        text = text[:limit] + "..."
    if "\n" in text:
        if multiline_mode == "collapse":
            return f"\n<details><summary>{label}</summary>\n\n```\n{text}\n```\n\n</details>"
        elif multiline_mode == "code":
            return f"\n```\n{text}\n```"
        elif multiline_mode == "quote":
            quoted = "\n".join(f"> {line}" for line in text.splitlines())
            return f"\n{quoted}"
    return text


@dataclass
class TraceEntry:
    """A single recorded event in the session trace.

    Attributes:
        timestamp: Absolute wall-clock time of the event (seconds since epoch).
        elapsed: Seconds elapsed since the trace started.
        event_type: Category of event (e.g., "tool_call", "tool_response",
            "thinking", "text", "final", "usage", or custom types).
        author: The agent or component that produced this event.
        content: Text content (for thinking, text, and final events).
        tool_name: Name of the tool (for tool_call and tool_response events).
        tool_args: Arguments passed to the tool (for tool_call events).
        tool_result: Serialized tool response (for tool_response events).
        usage: Token usage metadata (prompt, completion, total counts).
        model_version: Model identifier that produced this event.
        metadata: Arbitrary metadata for custom events.
    """

    timestamp: float
    elapsed: float  # seconds since trace start
    event_type: (
        str  # "thinking", "tool_call", "tool_response", "text", "final", "error"
    )
    author: str = ""
    content: str = ""
    tool_name: str = ""
    tool_args: dict[str, Any] | None = None
    tool_result: str = ""
    usage: dict[str, Any] | None = None  # token counts
    model_version: str = ""
    metadata: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert the trace entry to a dictionary."""
        d = {
            "timestamp": self.timestamp,
            "elapsed_s": round(self.elapsed, 3),
            "type": self.event_type,
        }
        if self.author:
            d["author"] = self.author
        if self.content:
            d["content"] = self.content
        if self.tool_name:
            d["tool"] = self.tool_name
        if self.tool_args is not None:
            d["args"] = self.tool_args
        if self.tool_result:
            d["result"] = self.tool_result
        if self.usage:
            d["usage"] = self.usage
        if self.model_version:
            d["model"] = self.model_version
        if self.metadata:
            d["metadata"] = self.metadata
        return d


class SessionTrace:
    """Records and exports a complete session trace.

    Usage:
        trace = SessionTrace()
        trace.start()
        # ... during agent run, call trace.record_event(event) for each ADK event
        trace.save("trace.json")
    """

    def __init__(self) -> None:
        self._entries: list[TraceEntry] = []
        self._start_time: float | None = None
        self._on_entry: Callable[[TraceEntry], None] | None = None

    def start(self) -> None:
        """Mark the start of the trace."""
        self._start_time = time.time()
        self._entries.clear()

    @property
    def entries(self) -> list[TraceEntry]:
        """Return a copy of the recorded trace entries."""
        return list(self._entries)

    @property
    def duration(self) -> float:
        """Return the total elapsed duration of the trace in seconds."""
        if not self._entries:
            return 0.0
        return self._entries[-1].elapsed

    def set_callback(self, callback: Callable[[TraceEntry], None]) -> None:
        """Set a callback fired for each new entry (for live display)."""
        self._on_entry = callback

    def _add(self, entry: TraceEntry) -> None:
        """Append a trace entry and fire the callback if set."""
        self._entries.append(entry)
        if self._on_entry:
            self._on_entry(entry)

    def record_event(self, event: Any) -> None:
        """Record an ADK Event into the trace."""
        now = time.time()
        elapsed = now - self._start_time if self._start_time is not None else 0.0
        author = getattr(event, "author", "")
        model = getattr(event, "model_version", "") or ""

        # Extract usage metadata
        usage = None
        if hasattr(event, "usage_metadata") and event.usage_metadata:
            um = event.usage_metadata
            usage = {}
            if hasattr(um, "prompt_token_count") and um.prompt_token_count is not None:
                usage["prompt_tokens"] = um.prompt_token_count
            if hasattr(um, "candidates_token_count") and um.candidates_token_count is not None:
                usage["completion_tokens"] = um.candidates_token_count
            if hasattr(um, "cached_content_token_count") and um.cached_content_token_count is not None:
                usage["cached_tokens"] = um.cached_content_token_count
            if hasattr(um, "total_token_count") and um.total_token_count is not None:
                usage["total_tokens"] = um.total_token_count
            if not any(usage.values()):
                usage = None

        def _consume_usage() -> dict[str, Any] | None:
            """Return usage and clear it so it's only attached once."""
            nonlocal usage
            result, usage = usage, None
            return result

        # Check for compaction event (bypassing MagicMock artifacts)
        if hasattr(event, "actions") and event.actions and type(event.actions).__name__ != "MagicMock" and hasattr(event.actions, "compaction") and event.actions.compaction:
            comp = event.actions.compaction
            meta = {
                "start_timestamp": comp.start_timestamp,
                "end_timestamp": comp.end_timestamp,
            }
            summary_text = ""
            if hasattr(comp, "compacted_content") and comp.compacted_content and hasattr(comp.compacted_content, "parts"):
                for part in comp.compacted_content.parts:
                    if hasattr(part, "text") and part.text:
                        summary_text += part.text
            self._add(
                TraceEntry(
                    timestamp=now,
                    elapsed=elapsed,
                    event_type="compaction",
                    author=author or "compactor",
                    content=summary_text.strip(),
                    usage=_consume_usage(),
                    model_version=model,
                    metadata=meta,
                )
            )
            return

        # Extract content parts
        content = getattr(event, "content", None)
        if not content or not hasattr(content, "parts") or not content.parts:
            # Still record for usage/metadata
            if usage:
                self._add(
                    TraceEntry(
                        timestamp=now,
                        elapsed=elapsed,
                        event_type="usage",
                        author=author,
                        usage=_consume_usage(),
                        model_version=model,
                    )
                )
            return

        for part in content.parts:
            # Tool call
            if hasattr(part, "function_call") and part.function_call:
                fc = part.function_call
                args = dict(fc.args) if fc.args else {}
                self._add(
                    TraceEntry(
                        timestamp=now,
                        elapsed=elapsed,
                        event_type="tool_call",
                        author=author,
                        tool_name=fc.name,
                        tool_args=args,
                        usage=_consume_usage(),
                        model_version=model,
                    )
                )

            # Tool response
            elif hasattr(part, "function_response") and part.function_response:
                fr = part.function_response
                parsed = unwrap_tool_response(fr)
                resp_text = json.dumps(parsed, default=str) if parsed else ""
                self._add(
                    TraceEntry(
                        timestamp=now,
                        elapsed=elapsed,
                        event_type="tool_response",
                        author=author,
                        tool_name=getattr(fr, "name", "") or "",
                        tool_result=resp_text,
                        usage=_consume_usage(),
                        model_version=model,
                    )
                )

            # Thinking / text
            elif hasattr(part, "thought") and part.thought:
                self._add(
                    TraceEntry(
                        timestamp=now,
                        elapsed=elapsed,
                        event_type="thinking",
                        author=author,
                        content=part.text.strip() if part.text else "",
                        usage=_consume_usage(),
                        model_version=model,
                    )
                )

            elif hasattr(part, "text") and part.text and part.text.strip():
                is_final = (
                    hasattr(event, "is_final_response") and event.is_final_response()
                )
                self._add(
                    TraceEntry(
                        timestamp=now,
                        elapsed=elapsed,
                        event_type="final" if is_final else "text",
                        author=author,
                        content=part.text.strip(),
                        usage=_consume_usage(),
                        model_version=model,
                    )
                )

        # Catch usage from events with only unrecognized part types.
        if usage:
            self._add(
                TraceEntry(
                    timestamp=now,
                    elapsed=elapsed,
                    event_type="usage",
                    author=author,
                    usage=_consume_usage(),
                    model_version=model,
                )
            )

    def record_custom(
        self,
        event_type: str,
        content: str = "",
        metadata: dict[str, Any] | None = None,
        author: str = "harness",
    ) -> None:
        """Record a custom trace entry (e.g., harness-level events)."""
        now = time.time()
        elapsed = now - self._start_time if self._start_time is not None else 0.0
        self._add(
            TraceEntry(
                timestamp=now,
                elapsed=elapsed,
                event_type=event_type,
                author=author,
                content=content,
                metadata=metadata,
            )
        )

    def to_dict(self) -> dict[str, Any]:
        """Export the full trace as a dict."""
        return {
            "trace_version": "1.0",
            "duration_s": round(self.duration, 3),
            "num_entries": len(self._entries),
            "entries": [e.to_dict() for e in self._entries],
            "summary": self.summarize(),
        }

    @property
    def tool_call_breakdown(self) -> dict[str, int]:
        """Return a mapping of tool name → call count."""
        counts: dict[str, int] = {}
        for e in self._entries:
            if e.event_type == "tool_call":
                counts[e.tool_name] = counts.get(e.tool_name, 0) + 1
        return counts

    def summarize(self) -> dict[str, Any]:
        """Generate summary statistics."""
        breakdown = self.tool_call_breakdown

        total_prompt = sum(
            e.usage.get("prompt_tokens", 0) for e in self._entries if e.usage
        )
        total_cached = sum(
            e.usage.get("cached_tokens", 0) for e in self._entries if e.usage
        )
        total_completion = sum(
            e.usage.get("completion_tokens", 0) for e in self._entries if e.usage
        )
        total_tokens = total_prompt + total_completion

        return {
            "total_events": len(self._entries),
            "tool_calls": sum(breakdown.values()),
            "tool_call_breakdown": breakdown,
            "thinking_entries": sum(
                1 for e in self._entries if e.event_type == "thinking"
            ),
            "compaction_entries": sum(
                1 for e in self._entries if e.event_type == "compaction"
            ),
            "text_entries": sum(1 for e in self._entries if e.event_type == "text"),
            "total_prompt_tokens": total_prompt,
            "total_cached_prompt_tokens": total_cached,
            "total_completion_tokens": total_completion,
            "total_tokens": total_tokens,
        }

    def save(self, path: str | Path) -> None:
        """Save the trace to a JSON file."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2, default=str)

    def to_markdown(
        self,
        max_thought_len: int | None = 200,
        max_tool_args_len: int | None = 200,
        max_tool_result_len: int | None = 200,
        max_text_len: int | None = 200,
        max_final_len: int | None = 300,
        max_compaction_len: int | None = 300,
        include_events: set[str] | None = None,
        exclude_events: set[str] | None = None,
        show_usage: bool = True,
        show_summary_section: bool = True,
        show_tool_breakdown: bool = True,
        timestamp_mode: str = "elapsed",  # "elapsed", "absolute", "none"
        multiline_mode: str = "collapse",  # "collapse", "code", "quote"
        use_emojis: bool = True,
        show_author: bool = True,
    ) -> str:
        """Export the trace as a readable markdown document."""
        lines = []
        if show_summary_section:
            lines.append("# Session Trace\n")
            summary = self.summarize()
            lines.append(f"**Duration**: {self.duration:.1f}s")
            lines.append(f"**Events**: {summary['total_events']}")
            lines.append(f"**Tool calls**: {summary['tool_calls']}")
            lines.append(f"**Tokens**: {summary['total_tokens']:,}")
            lines.append("")

        if show_tool_breakdown:
            summary = self.summarize()
            if summary["tool_call_breakdown"]:
                lines.append("## Tool Call Breakdown\n")
                for name, count in sorted(summary["tool_call_breakdown"].items()):
                    lines.append(f"- `{name}`: {count}")
                lines.append("")

        lines.append("## Timeline\n")
        for entry in self._entries:
            if include_events is not None and entry.event_type not in include_events:
                continue
            if exclude_events is not None and entry.event_type in exclude_events:
                continue
            if entry.event_type == "usage" and not show_usage:
                continue

            if timestamp_mode == "elapsed":
                ts = f"[{entry.elapsed:7.2f}s]"
            elif timestamp_mode == "absolute":
                ts = f"[{datetime.fromtimestamp(entry.timestamp).isoformat()}]"
            else:
                ts = ""
            author_str = f" ({entry.author})" if (entry.author and show_author) else ""
            prefix = f"{ts}{author_str}".lstrip()
            prefix_str = f"{prefix} " if prefix else ""

            if entry.event_type == "thinking":
                emoji = "💭 " if use_emojis else ""
                formatted = _format_content(entry.content, max_thought_len, multiline_mode, "Thinking")
                if "\n" in formatted:
                    line = f"{prefix_str}{emoji}**Thinking**:{formatted}"
                else:
                    line = f"{prefix_str}{emoji}**Thinking**: {formatted}"

            elif entry.event_type == "compaction":
                emoji = "🗜️ " if use_emojis else ""
                meta_info = f" (range: {entry.metadata.get('start_timestamp', '?')} - {entry.metadata.get('end_timestamp', '?')})" if entry.metadata else ""
                formatted = _format_content(entry.content, max_compaction_len, multiline_mode, "Compaction")
                if "\n" in formatted:
                    line = f"{prefix_str}{emoji}**Compaction**{meta_info}:{formatted}"
                else:
                    line = f"{prefix_str}{emoji}**Compaction**{meta_info}: {formatted}"

            elif entry.event_type == "tool_call":
                emoji = "🔧 " if use_emojis else ""
                args_str = json.dumps(entry.tool_args, default=str)
                formatted = _format_content(args_str, max_tool_args_len, multiline_mode, f"{entry.tool_name} args")
                line = f"{prefix_str}{emoji}**{entry.tool_name}**({formatted})"

            elif entry.event_type == "tool_response":
                emoji = "📤 " if use_emojis else ""
                formatted = _format_content(entry.tool_result, max_tool_result_len, multiline_mode, f"{entry.tool_name} result")
                if "\n" in formatted:
                    line = f"{prefix_str}{emoji}**→ {entry.tool_name}**:{formatted}"
                else:
                    line = f"{prefix_str}{emoji}**→ {entry.tool_name}**: `{formatted}`"

            elif entry.event_type == "text":
                emoji = "💬 " if use_emojis else ""
                formatted = _format_content(entry.content, max_text_len, multiline_mode, "Message")
                if "\n" in formatted:
                    line = f"{prefix_str}{emoji}Message:{formatted}"
                else:
                    line = f"{prefix_str}{emoji}{formatted}"

            elif entry.event_type == "final":
                emoji = "✅ " if use_emojis else ""
                formatted = _format_content(entry.content, max_final_len, multiline_mode, "Final Response")
                if "\n" in formatted:
                    line = f"{prefix_str}{emoji}**Final**:{formatted}"
                else:
                    line = f"{prefix_str}{emoji}**Final**: {formatted}"

            elif entry.event_type == "usage":
                if entry.usage and show_usage:
                    emoji = "📊 " if use_emojis else ""
                    line = f"{prefix_str}{emoji}Tokens: {entry.usage}"
                else:
                    continue

            else:
                emoji = "📌 " if use_emojis else ""
                meta_str = f" | {entry.metadata}" if entry.metadata else ""
                formatted = _format_content(entry.content, max_text_len, multiline_mode, entry.event_type.capitalize())
                if "\n" in formatted:
                    line = f"{prefix_str}{emoji}**{entry.event_type}**:{formatted}{meta_str}"
                else:
                    line = f"{prefix_str}{emoji}**{entry.event_type}**: {formatted}{meta_str}"

            if entry.event_type != "usage" and entry.usage and show_usage:
                emoji = "📊 " if use_emojis else ""
                line += f" [{emoji}Tokens: {entry.usage}]"

            lines.append(line)

        lines.append("")
        return "\n".join(lines)
