"""Pydantic configuration models for Kaggle-in-Kaggle evaluations.

Defines the data classes that parameterize an evaluation run:
problem definition, resource budget, and top-level config.
"""

from pydantic import BaseModel, ConfigDict, Field
from google.adk.agents.context_cache_config import ContextCacheConfig
from google.adk.apps._configs import EventsCompactionConfig


class BudgetConfig(BaseModel):
    """Resource budget for an evaluation run.

    Attributes:
        max_tool_calls: Global limit on all tool invocations.
        max_submissions: Maximum number of submit_predictions calls allowed.
        max_selections: Maximum number of submissions the agent can select for final scoring.
        max_exec_seconds: Per-call timeout for run_command tool execution.
        max_stdout_chars: Maximum characters to capture from stdout/stderr per command.
        max_budget_usd: Maximum dollar spend allowed on LLM tokens.
        max_llm_calls: Hard limit on LLM invocations passed to ADK RunConfig.
        max_time_minutes: Maximum session runtime allowed in minutes.
    """

    max_tool_calls: int = Field(gt=0)
    max_submissions: int = Field(gt=0)
    max_selections: int = Field(gt=0)
    max_exec_seconds: int = Field(gt=0)
    max_stdout_chars: int = Field(gt=0)
    max_budget_usd: float = Field(gt=0)
    max_llm_calls: int = Field(gt=0)
    max_time_minutes: int = Field(gt=0)
    num_retries: int = Field(default=100, ge=0)



class ProblemConfig(BaseModel):
    """Defines the ML problem the agent will solve using Kaggle-standard data format.

    Attributes:
        problem_id: Unique problem identifier.
        description: Human-readable task description shown to the agent.
        id_column: Join column between submission and solution.
        train_path: Path to train.csv (features + target + id).
        test_path: Path to test.csv (features + id, no target).
        sample_submission_path: Path to sample_submission.csv (id + target columns with dummy values).
        solution_path: Path to solution.csv (id + target columns + Usage column).
    """

    problem_id: str = Field(min_length=1)
    description: str = Field(min_length=1)
    id_column: str = "id"
    train_path: str = Field(min_length=1)
    test_path: str = Field(min_length=1)
    sample_submission_path: str = Field(min_length=1)
    solution_path: str = Field(min_length=1)


class EvaluationConfig(BaseModel):
    """Top-level config for a Kaggle-in-Kaggle evaluation.

    Attributes:
        problem: Configuration defining the ML problem.
        budget: Configuration defining resource constraints.
        docker_image: The Docker image used for the sandbox environment.
        models_yaml_path: Optional path to a custom models.yaml pricing file.
        context_cache_config: Optional context cache configuration.
        events_compaction_config: Optional events compaction configuration.
    """

    model_config = ConfigDict(arbitrary_types_allowed=True)

    problem: ProblemConfig
    budget: BudgetConfig
    docker_image: str = "gcr.io/kaggle-images/python"
    models_yaml_path: str | None = None
    context_cache_config: ContextCacheConfig | None = None
    events_compaction_config: EventsCompactionConfig | None = None

