"""Evaluation framework for Kaggle-in-Kaggle.

This module provides the `Evaluation` async context manager which orchestrates
a complete Kaggle evaluation session: standing up the sandbox, loading data,
initializing the context, running the agent loop, and tearing down resources.
"""

from __future__ import annotations

import asyncio
import logging
import math
import signal
import time
from contextlib import aclosing
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Sequence

import pandas as pd
from google.adk.agents.base_agent import BaseAgent
from google.adk.agents.run_config import RunConfig
from google.adk.apps.app import App
from google.adk.plugins.base_plugin import BasePlugin
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types as genai_types

from kaggle_kaggle.budget import PricingTable
from kaggle_kaggle.config import BudgetConfig, EvaluationConfig, ProblemConfig
from kaggle_kaggle.context import KaggleKaggleContext
from kaggle_kaggle.display_plugin import EventDisplayPlugin
from kaggle_kaggle.sandbox import CodeSandbox, DockerSandbox, KaggleSandboxCodeExecutor
from kaggle_kaggle.scoring import resolve_scorer, scorer_direction, scorer_name
from kaggle_kaggle.trace import SessionTrace

logger = logging.getLogger(__name__)


@dataclass
class ProblemResult:
    """Results from evaluating an agent on a single ML problem.

    Attributes:
        problem_id: The unique identifier for the evaluated problem.
        metric: The name of the evaluation metric used.
        public_scores: Dictionary mapping submission IDs to their public leaderboard scores.
        best_public_score: The highest public score achieved across all submissions.
        private_scores: Dictionary mapping submission IDs to their private leaderboard scores.
        best_private_score: The highest private score achieved across all submissions.
        selected_ids: List of submission IDs explicitly selected by the agent for final scoring.
        auto_selected_ids: List of submission IDs automatically selected by the harness.
        final_score: The best private score among the finalized submissions.
        tool_calls_used: Total number of tool executions performed by the agent.
        submissions_used: Total number of prediction submissions made by the agent.
        wall_time_seconds: Total execution time of the evaluation loop in seconds.
        total_cost_usd: Total estimated cost of LLM usage during the session in USD.
        max_budget_usd: The maximum allowed USD budget for the session.
        total_input_tokens: Total number of prompt tokens processed.
        total_cached_input_tokens: Total number of prompt tokens served from cache.
        total_output_tokens: Total number of generation tokens produced.
        llm_calls: Total number of discrete LLM API calls made.
        end_status: The final termination reason ("completed", "agent_error", "timeout", "no_submissions", "budget_exceeded").
        trace: The detailed session trace capturing all events and metadata.
    """

    problem_id: str
    metric: str
    public_scores: dict[str, float] = field(default_factory=dict)
    best_public_score: float = float("nan")
    private_scores: dict[str, float] = field(default_factory=dict)
    best_private_score: float = float("nan")
    selected_ids: list[str] = field(default_factory=list)
    auto_selected_ids: list[str] = field(default_factory=list)
    final_score: float = float("nan")
    tool_calls_used: int = 0
    submissions_used: int = 0
    wall_time_seconds: float = 0.0
    total_cost_usd: float = 0.0
    max_budget_usd: float = 0.0
    max_tool_calls: int = 0
    max_submissions: int = 0
    max_time_minutes: float = 0.0
    total_input_tokens: int = 0
    total_cached_input_tokens: int = 0
    total_output_tokens: int = 0
    llm_calls: int = 0
    end_status: str = "unknown"
    trace: SessionTrace | None = None


def build_task_prompt_text(
    problem: ProblemConfig,
    budget: BudgetConfig,
    metric_name: str,
    higher_is_better: bool,
) -> str:
    """Build the task prompt text sent to the agent as the initial user message.

    Returns the raw string so callers can both record it in the trace and
    wrap it in a :class:`genai_types.Content` as needed.

    Args:
        problem: The problem configuration defining the task and evaluation.
        budget: The budget configuration defining limits on tools and tokens.
        metric_name: Human-readable name of the evaluation metric.
        higher_is_better: Whether a higher metric score is better.

    Returns:
        The composed task prompt as a plain string.
    """
    budget_lines = f"""- Tool calls: {budget.max_tool_calls} (total across all tools)
- Submissions: {budget.max_submissions} (each scored on a public set)
- Selections: {budget.max_selections} (choose your best for final scoring)
- Per-command timeout: {budget.max_exec_seconds}s
- Max command output: {budget.max_stdout_chars} characters (per command)
- Token budget: ${budget.max_budget_usd:.2f} USD (covers all LLM inference cost)
- Max LLM calls: {budget.max_llm_calls} (total interactions with the model)
- Time limit: {budget.max_time_minutes} minutes (total session runtime)"""

    return f"""You are competing in a Kaggle-style machine learning competition.

## Task
{problem.description}

## Data
The working directory contains:
- `train.csv`: Training data
- `test.csv`: Test data (features only)
- `sample_submission.csv`: Example submission file

Your goal is to generate predictions for `test.csv` that match the format of `sample_submission.csv`.

## Evaluation Metric
**{metric_name}** ({"higher is better" if higher_is_better else "lower is better"})

## Environment
You have a Docker container with a full Linux environment and pre-installed
data science packages (pandas, numpy, scikit-learn, xgboost, lightgbm,
catboost, pytorch, transformers). The sandbox is strictly isolated with no internet
access, so you cannot install other packages. Use the `run_command` tool to execute
Python scripts or shell pipelines in the container. Use `write_file` to create new
files, `edit_file` for targeted modifications to existing files, and `get_status` to
check your remaining budget and leaderboard standing at any time.

## Budget
{budget_lines}

## Submission Workflow
1. Write a script to train a model on `train.csv`.
2. Generate predictions on `test.csv`.
3. Save predictions to a CSV matching the format of `sample_submission.csv`.
4. Call `submit_predictions("your_submission.csv")`. You will receive a score
   calculated on a public subset of the test data.
5. Iterate! Improve your model and submit again.
6. Once satisfied (or nearing the tool/token limit), call
   `select_submission(["sub_1", "sub_2"])` to choose your best models for
   final scoring on the private test set.
7. As your final action, return a text-only response reporting on the work you did
   during the session. Note that returning a text-only response (without tool calls)
   will terminate the session immediately.

If you hit any budget limit (tool calls, time limit, or USD budget), your tool call will
return a BudgetExceeded error and your session will terminate immediately. Watch the outputs
of your tool calls and use `get_status` to monitor your budget and leaderboard score!
"""


def compose_task_prompt(
    problem: ProblemConfig,
    budget: BudgetConfig,
    metric_name: str,
    higher_is_better: bool,
) -> genai_types.Content:
    """Wrap the task prompt text in a :class:`genai_types.Content` message.

    This is a thin wrapper around :func:`build_task_prompt_text` for callers
    that need the ADK Content object directly.

    Args:
        problem: The problem configuration defining the task and evaluation.
        budget: The budget configuration defining limits on tools and tokens.
        metric_name: Human-readable name of the evaluation metric.
        higher_is_better: Whether a higher metric score is better.

    Returns:
        The composed initial task prompt formatted as a Content message.
    """
    text = build_task_prompt_text(problem, budget, metric_name, higher_is_better)
    return genai_types.Content(
        role="user",
        parts=[genai_types.Part.from_text(text=text)],
    )


class Evaluation:
    """Async context manager for a complete evaluation session.

    Usage::

        async with Evaluation(config, metric="roc_auc") as ev:
            agent = compile_submission(
                "submission/",
                ev.tools,
                models,
                code_executor=ev.code_executor,
                script_timeout=config.budget.max_exec_seconds,
            )
            display = EventDisplay(ev)
            with display:
                result = await ev.run(agent)
    """

    def __init__(
        self,
        config: EvaluationConfig,
        metric: str | Any,
        *,
        metric_name: str = "",
        sandbox: CodeSandbox | None = None,
    ) -> None:
        self._config = config
        self._scorer = resolve_scorer(metric)
        self._metric_name = scorer_name(self._scorer, default=metric_name)
        self._higher_is_better = scorer_direction(self._scorer)
        self._sandbox_arg = sandbox
        self._owns_sandbox = False

        self._sandbox: CodeSandbox | None = None
        self._code_executor: KaggleSandboxCodeExecutor | None = None
        self._ctx: KaggleKaggleContext | None = None
        self._tools: dict[str, Callable] | None = None

        self._trace = SessionTrace()
        self._observers: list[Callable] = []
        self._dispatched_event_ids: set[int] = set()

    @property
    def config(self) -> EvaluationConfig:
        return self._config

    @property
    def metric_name(self) -> str:
        return self._metric_name

    @property
    def higher_is_better(self) -> bool:
        return self._higher_is_better

    @property
    def trace(self) -> SessionTrace:
        return self._trace

    @property
    def ctx(self) -> KaggleKaggleContext:
        if self._ctx is None:
            raise RuntimeError("Evaluation context not entered.")
        return self._ctx

    @property
    def sandbox(self) -> CodeSandbox:
        if self._sandbox is None:
            raise RuntimeError("Evaluation context not entered.")
        return self._sandbox

    @property
    def tools(self) -> dict[str, Callable]:
        if self._tools is None:
            raise RuntimeError("Evaluation context not entered.")
        return self._tools

    @property
    def code_executor(self) -> KaggleSandboxCodeExecutor:
        if self._code_executor is None:
            raise RuntimeError("Evaluation context not entered.")
        return self._code_executor

    def add_observer(self, callback: Callable) -> None:
        """Register a callback to receive all ADK events."""
        self._observers.append(callback)

    def _dispatch_event(self, event: Any) -> None:
        """Process event for budget/trace and fan out to registered observers."""
        self._dispatched_event_ids.add(id(event))
        if hasattr(event, "usage_metadata") and event.usage_metadata:
            um = event.usage_metadata
            input_tokens = getattr(um, "prompt_token_count", 0) or 0
            output_tokens = getattr(um, "candidates_token_count", 0) or 0
            cached_tokens = getattr(um, "cached_content_token_count", 0) or 0
            if input_tokens or output_tokens:
                model_id = getattr(event, "model_version", "") or ""
                if self._ctx and self._ctx.token_budget:
                    self._ctx.token_budget.record_usage(model_id, input_tokens, output_tokens, cached_tokens)

        self.trace.record_event(event)

        for observer in self._observers:
            try:
                observer(event)
            except Exception as e:
                logger.error("Observer error: %s", e)

    async def __aenter__(self) -> "Evaluation":
        logger.info("Initializing Evaluation for %s", self._config.problem.problem_id)

        # Load data
        train_df = pd.read_csv(self._config.problem.train_path)
        test_df = pd.read_csv(self._config.problem.test_path)
        sample_submission_df = pd.read_csv(self._config.problem.sample_submission_path)
        solution_df = pd.read_csv(self._config.problem.solution_path)

        if self._sandbox_arg is None:
            self._owns_sandbox = True
            sandbox = DockerSandbox(image=self._config.docker_image)
            try:
                sandbox.initialize({
                    "train.csv": train_df.to_csv(index=False),
                    "test.csv": test_df.to_csv(index=False),
                    "sample_submission.csv": sample_submission_df.to_csv(index=False),
                })
                self._sandbox = sandbox
            except Exception:
                sandbox.close()
                raise
        else:
            self._sandbox = self._sandbox_arg

        try:
            pricing_table = None
            if self._config.models_yaml_path:
                if not Path(self._config.models_yaml_path).exists():
                    raise FileNotFoundError(f"Models YAML file not found: {self._config.models_yaml_path}")
                pricing_table = PricingTable.from_yaml(self._config.models_yaml_path)
            else:
                pricing_table = PricingTable.from_yaml()

            self._ctx = KaggleKaggleContext(
                sandbox=self._sandbox,
                solution_df=solution_df,
                sample_submission_df=sample_submission_df,
                id_column=self._config.problem.id_column,
                scorer=self._scorer,
                metric_name=self._metric_name,
                budget=self._config.budget,
                pricing_table=pricing_table,
            )
            self._code_executor = KaggleSandboxCodeExecutor(
                sandbox=self._sandbox,
                timeout_seconds=self._config.budget.max_exec_seconds,
            )
            self._tools = self._ctx.create_tools()
            return self
        except Exception:
            if self._owns_sandbox and self._sandbox is not None:
                self._sandbox.close()
            raise

    async def __aexit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> None:
        if self._owns_sandbox and self._sandbox is not None:
            self._sandbox.close()

    async def run(self, agent: BaseAgent) -> ProblemResult:
        """Run the evaluation loop for the given agent."""
        logger.info("Running evaluation for problem %s", self.config.problem.problem_id)
        start_time = time.perf_counter()
        self.ctx.start_timer(start_time)
        if self._code_executor is not None:
            self._code_executor.start_time = start_time
            self._code_executor.max_time_minutes = self.config.budget.max_time_minutes

        task_prompt_text = build_task_prompt_text(
            self.config.problem,
            self.config.budget,
            self.metric_name,
            self.higher_is_better,
        )

        session_service = InMemorySessionService()
        session = await session_service.create_session(
            app_name="kaggle_kaggle",
            user_id="eval",
            state={
                "problem_description": self.config.problem.description,
                "metric_name": self.metric_name,
                "metric_direction": "higher is better" if self.higher_is_better else "lower is better",
                "max_tool_calls": self.config.budget.max_tool_calls,
                "max_submissions": self.config.budget.max_submissions,
                "max_selections": self.config.budget.max_selections,
                "max_exec_seconds": self.config.budget.max_exec_seconds,
                "max_stdout_chars": self.config.budget.max_stdout_chars,
                "max_budget_usd": self.config.budget.max_budget_usd,
                "max_llm_calls": self.config.budget.max_llm_calls,
                "max_time_minutes": self.config.budget.max_time_minutes,
                "task_prompt": task_prompt_text,
            },
        )

        plugins: list[BasePlugin] = [EventDisplayPlugin(self._dispatch_event)]  # type: ignore
        app = App(
            name="kaggle_kaggle",
            root_agent=agent,
            plugins=plugins,
            context_cache_config=self.config.context_cache_config,
            events_compaction_config=self.config.events_compaction_config,
        )
        runner = Runner(
            app=app,
            session_service=session_service,
        )

        run_config = RunConfig(max_llm_calls=self.config.budget.max_llm_calls + 5)

        task_message = genai_types.Content(
            role="user",
            parts=[genai_types.Part.from_text(text="Begin the competition task.")],
        )

        self.trace.start()
        self.trace.record_custom(
            "problem_start",
            f"Starting {self.config.problem.problem_id}",
            {
                "metric": self.metric_name,
                "budget": {
                    "max_tool_calls": self.config.budget.max_tool_calls,
                    "max_submissions": self.config.budget.max_submissions,
                    "max_time_minutes": self.config.budget.max_time_minutes,
                },
            },
        )

        # Record the agent's system instruction and the task prompt in the
        # order the model sees them: system instruction is injected first
        # (before every LLM call), followed by the user task message.
        system_instruction = getattr(agent, "instruction", "") or ""
        if system_instruction:
            self.trace.record_custom(
                "system_instruction",
                system_instruction,
                author="harness",
            )
        self.trace.record_custom(
            "task_prompt",
            task_prompt_text,
            author="harness",
        )

        result = ProblemResult(
            problem_id=self.config.problem.problem_id,
            metric=self.metric_name,
            trace=self.trace,
        )

        # Install a SIGINT handler so Ctrl-C cancels the task and raises
        # KeyboardInterrupt immediately, even if the event loop is blocked
        # in a synchronous tool call (like Docker exec_run).
        interrupt_count = 0
        running_task = asyncio.current_task()

        def _sigint_handler(signum: int, frame: Any) -> None:
            nonlocal interrupt_count
            interrupt_count += 1
            if interrupt_count == 1 and running_task is not None:
                running_task.cancel()
                raise KeyboardInterrupt
            else:
                # Second Ctrl-C: force-exit immediately.
                import sys
                sys.exit(130)

        old_sigint_handler = signal.getsignal(signal.SIGINT)
        try:
            signal.signal(signal.SIGINT, _sigint_handler)
        except (ValueError, NotImplementedError):
            logger.debug("Signal handlers not supported on this thread/OS.")

        try:
            try:
                async with asyncio.timeout(self.config.budget.max_time_minutes * 60), aclosing(
                    runner.run_async(
                        user_id="eval",
                        session_id=session.id,
                        new_message=task_message,
                        run_config=run_config,
                    )
                ) as agen:
                    async for event in agen:
                        # Check session.events for any background compaction events appended directly by ADK's compactor
                        for se in session.events:
                            if id(se) not in self._dispatched_event_ids:
                                self._dispatched_event_ids.add(id(se))
                                if hasattr(se, "actions") and se.actions and hasattr(se.actions, "compaction") and se.actions.compaction:
                                    self._dispatch_event(se)

                        # Check budget after recording (recording happens via EventDisplayPlugin in _dispatch_event)
                        if (time.perf_counter() - start_time) > (self.config.budget.max_time_minutes * 60):
                            logger.warning(
                                "Session time limit reached: %s minutes",
                                self.config.budget.max_time_minutes,
                            )
                            self.trace.record_custom(
                                "timeout",
                                f"Session time limit reached ({self.config.budget.max_time_minutes} minutes)",
                                {},
                            )
                            result.end_status = "timeout"
                            break

                        if self.ctx.token_budget.is_exceeded:
                            logger.warning(
                                "Token budget exceeded: $%.4f / $%.2f",
                                self.ctx.token_budget.total_cost_usd,
                                self.ctx.token_budget.max_budget_usd,
                            )
                            self.trace.record_custom(
                                "budget_exceeded",
                                f"Token budget exceeded: ${self.ctx.token_budget.total_cost_usd:.4f}"
                                f" / ${self.ctx.token_budget.max_budget_usd:.2f}",
                                self.ctx.token_budget.to_status_dict(),
                            )
                            result.end_status = "budget_exceeded"
                            break

                        if hasattr(event, "is_final_response") and event.is_final_response():
                            # ADK's is_final_response() can fire prematurely for
                            # sub-agent events and skip_summarization deliveries.
                            # Only break on the root agent's genuine text response.
                            event_author = getattr(event, "author", None)
                            content = getattr(event, "content", None)
                            parts = getattr(content, "parts", []) if content else []
                            has_text = any(
                                getattr(p, "text", None) and not getattr(p, "thought", False)
                                for p in parts
                            )
                            has_function_response = any(
                                getattr(p, "function_response", None) for p in parts
                            )
                            has_function_call = any(
                                getattr(p, "function_call", None) for p in parts
                            )
                            logger.debug(
                                "is_final_response event: author=%r agent.name=%r "
                                "num_parts=%d has_text=%r has_function_response=%r has_function_call=%r",
                                event_author,
                                agent.name,
                                len(parts),
                                has_text,
                                has_function_response,
                                has_function_call,
                            )
                            if (
                                (event_author is None or event_author == agent.name)
                                and has_text
                                and not has_function_response
                                and not has_function_call
                            ):
                                break

                # Final check for any trailing compaction events appended after the generator completes
                for se in session.events:
                    if id(se) not in self._dispatched_event_ids:
                        self._dispatched_event_ids.add(id(se))
                        if hasattr(se, "actions") and se.actions and hasattr(se.actions, "compaction") and se.actions.compaction:
                            self._dispatch_event(se)

                if result.end_status == "unknown":
                    result.end_status = "completed"
            except TimeoutError:
                logger.warning(
                    "Evaluation timed out after %s minutes.",
                    self.config.budget.max_time_minutes,
                )
                self.trace.record_custom(
                    "timeout",
                    f"Session timed out after {self.config.budget.max_time_minutes} minutes",
                    {},
                )
                result.end_status = "timeout"
            except asyncio.CancelledError:
                logger.info("Evaluation interrupted by user.")
                self.trace.record_custom("interrupted", "Interrupted by user (Ctrl-C)", {})
                result.end_status = "interrupted"
                raise
            except KeyboardInterrupt:
                logger.info("Evaluation interrupted by user.")
                self.trace.record_custom("interrupted", "Interrupted by user (Ctrl-C)", {})
                result.end_status = "interrupted"
                raise
            except Exception as e:
                logger.error("Agent error: %s", e)
                self.trace.record_custom("error", str(e), {"type": type(e).__name__})
                result.end_status = "agent_error"

            return result
        finally:
            # Restore default SIGINT handling so the caller's handler is
            # not clobbered.
            try:
                if old_sigint_handler is not None:
                    signal.signal(signal.SIGINT, old_sigint_handler)
            except (ValueError, NotImplementedError):
                pass

            # Populate result with whatever we gathered (runs on success,
            # error, interrupt, and cancellation).
            result.tool_calls_used = self.ctx.tool_calls
            result.submissions_used = len(self.ctx.submissions)
            result.wall_time_seconds = time.perf_counter() - start_time
            result.total_cost_usd = self.ctx.token_budget.total_cost_usd
            result.max_budget_usd = self.ctx.token_budget.max_budget_usd
            result.max_tool_calls = self.ctx.max_tool_calls
            result.max_submissions = self.ctx.max_submissions
            result.max_time_minutes = self.ctx.max_time_minutes
            result.total_input_tokens = self.ctx.token_budget.total_input_tokens
            result.total_cached_input_tokens = self.ctx.token_budget.total_cached_input_tokens
            result.total_output_tokens = self.ctx.token_budget.total_output_tokens
            result.llm_calls = self.ctx.token_budget.llm_calls

            for sub in self.ctx.submissions.values():
                result.public_scores[sub.id] = sub.public_score
                result.private_scores[sub.id] = sub.private_score

            if result.public_scores:
                best_fn = max if self.higher_is_better else min
                pub_scores = [s for s in result.public_scores.values() if not math.isnan(s)]
                result.best_public_score = best_fn(pub_scores) if pub_scores else float("nan")
                priv_scores = [s for s in result.private_scores.values() if not math.isnan(s)]
                result.best_private_score = best_fn(priv_scores) if priv_scores else float("nan")
            elif result.end_status not in ("interrupted", "agent_error", "budget_exceeded", "timeout"):
                result.end_status = "no_submissions"
                logger.warning(
                    "Agent made no submissions for problem %s", self.config.problem.problem_id
                )

            # Resolve final submissions
            final_subs = self.ctx.get_final_submissions()
            agent_selected = set(self.ctx.selected_ids)
            result.selected_ids = [s.id for s in final_subs if s.id in agent_selected]
            result.auto_selected_ids = [
                s.id for s in final_subs if s.id not in agent_selected
            ]

            for sub in final_subs:
                how = "selected" if sub.id in agent_selected else "auto-selected"
                logger.info(
                    "Final submission %s (%s): public=%s=%.6f private=%s=%.6f",
                    sub.id,
                    how,
                    self.metric_name,
                    sub.public_score,
                    self.metric_name,
                    sub.private_score,
                )

            if final_subs:
                best_fn = max if self.higher_is_better else min
                priv_scores = [s.private_score for s in final_subs if not math.isnan(s.private_score)]
                result.final_score = best_fn(priv_scores) if priv_scores else float("nan")


def save_trace(
    result: ProblemResult,
    output_dir: str | Path = ".",
    fmt: str = "both",
) -> list[Path]:
    """Save the session trace from a ProblemResult.

    Args:
        result: The ProblemResult (must have a trace attached).
        output_dir: Directory to save trace files.
        fmt: 'json', 'markdown', or 'both'.

    Returns:
        List of paths to saved files.
    """
    if result.trace is None:
        logger.warning("No trace to save.")
        return []

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    saved = []

    base = f"trace_{result.problem_id}"

    if fmt in ("json", "both"):
        p = output_dir / f"{base}.json"
        result.trace.save(p)
        saved.append(p)
        logger.info("Trace saved: %s", p)

    if fmt in ("markdown", "both"):
        p = output_dir / f"{base}.md"
        p.write_text(result.trace.to_markdown())
        saved.append(p)
        logger.info("Trace saved: %s", p)

    return saved


async def evaluate(
    config: EvaluationConfig,
    metric: str | Any,
    agent: BaseAgent,
    **kwargs: Any,
) -> ProblemResult:
    """One-shot: setup → run → cleanup."""
    async with Evaluation(config, metric=metric, **kwargs) as ev:
        return await ev.run(agent)


def evaluate_sync(
    config: EvaluationConfig,
    metric: str | Any,
    agent: BaseAgent,
    **kwargs: Any,
) -> ProblemResult:
    """Run `evaluate` synchronously via `asyncio.run`."""
    return asyncio.run(evaluate(config, metric, agent, **kwargs))
