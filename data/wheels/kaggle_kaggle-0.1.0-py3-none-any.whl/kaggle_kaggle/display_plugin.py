"""ADK plugin that forwards events to the display layer.

This plugin bridges the gap between ADK's internal event system and
the :class:`~kaggle_kaggle.display.EventDisplay`.  When registered on
the :class:`~google.adk.runners.Runner`, it intercepts every event —
including events generated inside sub-agent ``AgentTool`` runners — and
forwards them to a callback.

Because ADK automatically propagates plugins to sub-agent runners
(via ``include_plugins=True``), this provides full visibility into
sub-agent activity without any modifications to ``AgentTool``.
"""

from __future__ import annotations

from typing import Any, Callable, Optional, TYPE_CHECKING

from google.adk.events.event import Event
from google.adk.plugins.base_plugin import BasePlugin

if TYPE_CHECKING:
    from google.adk.agents.invocation_context import InvocationContext


class EventDisplayPlugin(BasePlugin):
    """Plugin that forwards all ADK events to a display callback.

    This is the sole delivery mechanism for event display updates.
    Root-agent events and sub-agent events (from ``AgentTool``) all
    flow through this plugin, giving the display a unified, ordered
    stream of everything that happens during a session.

    Args:
        on_event: Synchronous callback accepting an ADK ``Event``.
            Typically ``EventDisplay.on_event``.
    """

    def __init__(self, on_event: Callable[[Any], None]) -> None:
        super().__init__(name="kaggle_display")
        self._on_event = on_event

    async def on_event_callback(
        self,
        *,
        invocation_context: InvocationContext,
        event: Event,
    ) -> Optional[Event]:
        """Forward every event to the display callback."""
        self._on_event(event)
        return event  # Propagate, don't drop
