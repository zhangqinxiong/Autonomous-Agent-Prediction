"""Tool context for Kaggle-in-Kaggle evaluations.

``KaggleKaggleContext`` holds the sandbox, scoring data, and budget
state needed by the agent's tools.  Construct one with all required
data, then call ``create_tools()`` to get the tool dict.
"""

from __future__ import annotations

import io
import json
import logging
import math
import time
from dataclasses import dataclass
from typing import Any, Callable

import pandas as pd

from kaggle_kaggle.budget import PricingTable, TokenBudget
from kaggle_kaggle.scoring import score_arrays, scorer_direction, scorer_name
from kaggle_kaggle.config import BudgetConfig
from kaggle_kaggle.sandbox import CodeSandbox

logger = logging.getLogger(__name__)


@dataclass
class Submission:
    """A single scored submission."""

    id: str
    number: int
    public_score: float  # Score on Public split of solution_df (shown to agent)
    private_score: float  # Score on Private split of solution_df (hidden)
    predictions: list[Any]

    @property
    def score(self) -> float:
        """Return the public score (the score visible to the agent)."""
        return self.public_score


class KaggleKaggleContext:
    """Tool context for a Kaggle-in-Kaggle evaluation session.

    Holds the sandbox, solution_df, sample_submission_df, scoring function,
    and budget state.  All parameters are required at construction — there
    is no deferred binding.

    Args:
        sandbox: Initialized ``CodeSandbox`` with data loaded.
        solution_df: Full test-set labels with Usage column (agent never sees this).
        sample_submission_df: Example submission with correct id and target columns.
        id_column: Name of the ID column in the dataset.
        scorer: A scikit-learn ``_Scorer`` object (from ``resolve_scorer``).
        metric_name: Human-readable metric name. Falls back to scorer func name.
        budget: Budget configuration. Individual limit kwargs
            (``max_submissions``, etc.) can be used to override specific
            fields from the budget.
    """

    def __init__(
        self,
        *,
        sandbox: CodeSandbox,
        solution_df: pd.DataFrame,
        sample_submission_df: pd.DataFrame,
        id_column: str,
        scorer: Any,
        metric_name: str = "",
        budget: BudgetConfig,
        pricing_table: PricingTable | None = None,
        max_submissions: int | None = None,
        max_selections: int | None = None,
        max_tool_calls: int | None = None,
        max_stdout_chars: int | None = None,
        max_exec_seconds: int | None = None,
    ) -> None:

        self._sandbox = sandbox
        self._solution_df = solution_df
        self._sample_submission_df = sample_submission_df
        self._id_column = id_column
        self._scorer = scorer
        self._target_columns = [c for c in sample_submission_df.columns if c != id_column]
        self._metric_name = scorer_name(scorer, default=metric_name)
        self._higher_is_better = scorer_direction(scorer)
        self._token_budget = TokenBudget(
            max_budget_usd=budget.max_budget_usd,
            pricing_table=pricing_table if pricing_table is not None else PricingTable.from_yaml(),
            max_llm_calls=budget.max_llm_calls,
        )

        self._max_submissions = (
            max_submissions if max_submissions is not None else budget.max_submissions
        )
        self._max_selections = (
            max_selections if max_selections is not None else budget.max_selections
        )
        self._max_tool_calls = (
            max_tool_calls if max_tool_calls is not None else budget.max_tool_calls
        )
        self._max_stdout_chars = (
            max_stdout_chars
            if max_stdout_chars is not None
            else budget.max_stdout_chars
        )
        self._max_exec_seconds = (
            max_exec_seconds
            if max_exec_seconds is not None
            else budget.max_exec_seconds
        )

        self._max_time_minutes = budget.max_time_minutes
        self._start_time = time.perf_counter()

        self._submissions: dict[str, Submission] = {}
        self._submission_counter: int = 0
        self._selected_ids: list[str] = []
        self._tool_calls: int = 0

    def start_timer(self, start_time: float) -> None:
        """Synchronize the session start time."""
        self._start_time = start_time

    def _check_budget(self, tool_name: str) -> str | None:
        """Check tool call budget and increment counter. Return error JSON if over budget."""
        if (time.perf_counter() - self._start_time) > (self._max_time_minutes * 60):
            return json.dumps(
                {
                    "status": "error",
                    "error_type": "TimeoutExceeded",
                    "error_message": f"Session time limit reached ({self._max_time_minutes} minutes)",
                    "details": {},
                }
            )
        if self._tool_calls >= self._max_tool_calls:
            return json.dumps(
                {
                    "status": "error",
                    "error_type": "BudgetExceeded",
                    "error_message": f"Tool call limit reached ({self._max_tool_calls} calls)",
                    "details": {"tool_calls": self._tool_calls, "max_tool_calls": self._max_tool_calls},
                }
            )
        if self._token_budget.is_exceeded:
            return json.dumps(
                {
                    "status": "error",
                    "error_type": "BudgetExceeded",
                    "error_message": (
                        f"Token budget exceeded "
                        f"(${self._token_budget.total_cost_usd:.4f}"
                        f" / ${self._token_budget.max_budget_usd:.2f})"
                    ),
                    "details": self._token_budget.to_status_dict(),
                }
            )
        self._tool_calls += 1
        return None

    @property
    def token_budget(self) -> TokenBudget:
        """The token budget tracker."""
        return self._token_budget

    @property
    def tool_calls(self) -> int:
        """Number of tool calls made so far."""
        return self._tool_calls

    @property
    def submissions(self) -> dict[str, "Submission"]:
        """All submissions made, keyed by submission ID."""
        return dict(self._submissions)

    @property
    def selected_ids(self) -> list[str]:
        """Submission IDs explicitly selected by the agent."""
        return list(self._selected_ids)

    @property
    def max_time_minutes(self) -> int:
        """Maximum session runtime allowed in minutes."""
        return self._max_time_minutes

    @property
    def max_tool_calls(self) -> int:
        """Maximum number of tool calls allowed."""
        return self._max_tool_calls

    @property
    def max_submissions(self) -> int:
        """Maximum number of submissions allowed."""
        return self._max_submissions

    @property
    def max_selections(self) -> int:
        """Maximum number of final selections allowed."""
        return self._max_selections

    @property
    def metric_name(self) -> str:
        """Name of the evaluation metric."""
        return self._metric_name

    @property
    def higher_is_better(self) -> bool:
        """Whether higher metric values are better."""
        return self._higher_is_better

    @property
    def solution_df(self) -> pd.DataFrame:
        """Full test-set labels with Usage column."""
        return self._solution_df

    @property
    def sample_submission_df(self) -> pd.DataFrame:
        """Example submission with correct id and target columns."""
        return self._sample_submission_df

    @property
    def id_column(self) -> str:
        """Name of the ID column."""
        return self._id_column

    @property
    def target_columns(self) -> list[str]:
        """Names of the target columns."""
        return self._target_columns

    def create_tools(self) -> dict[str, Callable]:
        """Create tool functions bound to this context.

        Returns a plain ``dict[str, Callable]`` mapping tool names to
        callables.  This dict can be passed directly to
        :func:`adk_submission.compile_submission` as the ``tool_registry``
        argument.
        """

        def run_command(command: str) -> str:
            """Execute a shell command in the sandbox environment.

            The sandbox is a Docker container with a full Linux environment
            and common data science packages pre-installed (pandas, numpy,
            scikit-learn, xgboost, lightgbm, etc.).

            The working directory contains:
            - train.csv: Training data with features, target, and id columns.
            - test.csv: Test data with features and id columns (no target).
            - sample_submission.csv: Example submission with the correct format.
            You can run any shell command — Python scripts, shell pipelines, etc.
            The command runs in the working directory. Note that the sandbox is strictly
            isolated with no internet access, so you cannot install new packages.

            Args:
                command: Shell command to execute (e.g., "python3 script.py",
                    "ls -la", "cat train.csv | head -5").

            Examples:
                # Explore the data
                run_command("python3 -c \"import pandas as pd; df = pd.read_csv('train.csv'); print(df.describe())\"")

                # Write and run a Python script
                run_command("cat > train_model.py << 'EOF'\nimport pandas as pd\nfrom sklearn.ensemble import RandomForestClassifier\ntrain = pd.read_csv('train.csv')\nsample = pd.read_csv('sample_submission.csv')\nid_col = sample.columns[0]\ntarget = sample.columns[1]\nX = train.drop(columns=[target, id_col])\ny = train[target]\nmodel = RandomForestClassifier()\nmodel.fit(X, y)\ntest = pd.read_csv('test.csv')\npreds = model.predict_proba(test.drop(columns=[id_col]))[:, 1]\nsample[target] = preds\nsample.to_csv('submission.csv', index=False)\nprint(f'Saved {len(preds)} predictions')\nEOF\npython3 train_model.py")
            """

            budget_error = self._check_budget("run_command")
            if budget_error:
                return budget_error

            elapsed = time.perf_counter() - self._start_time
            remaining = max(0.0, (self._max_time_minutes * 60) - elapsed)
            effective_timeout = max(1, int(min(self._max_exec_seconds, remaining)))

            result = self._sandbox.run_command(command, timeout=effective_timeout)
            if result.status != "ok":
                error_type = "TimeoutExceeded" if result.status == "timeout" else "CommandError"
                stdout_str = result.stdout[:self._max_stdout_chars] + ("... [truncated]" if len(result.stdout) > self._max_stdout_chars else "")
                stderr_str = result.stderr[:self._max_stdout_chars] + ("... [truncated]" if len(result.stderr) > self._max_stdout_chars else "")
                err_msg = stderr_str if stderr_str else (stdout_str if stdout_str else f"Command failed with exit code {result.exit_code}")
                if result.status == "timeout":
                    err_msg = f"Command timed out after {effective_timeout} seconds"
                return json.dumps({
                    "status": "error",
                    "error_type": error_type,
                    "error_message": err_msg,
                    "details": {
                        "stdout": stdout_str,
                        "stderr": stderr_str,
                        "exit_code": result.exit_code,
                        "duration_seconds": result.duration_seconds,
                    },
                })
            return result.to_json(max_stdout_chars=self._max_stdout_chars)

        def submit_predictions(filepath: str) -> str:
            """Submit a CSV file of predictions for public leaderboard scoring.

            The CSV file must match the format of sample_submission.csv
            (same columns, same id values). Write the file using run_command,
            then pass the relative filepath here.

            Args:
                filepath: Relative path to a CSV file (e.g., "submission.csv").

            Returns:
                JSON with submission_id, public score, and submission history.
            """

            budget_error = self._check_budget("submit_predictions")
            if budget_error:
                return budget_error

            if len(self._submissions) >= self._max_submissions:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": "SubmissionLimitExceeded",
                        "error_message": f"Submission limit reached ({self._max_submissions})",
                        "details": {"max_submissions": self._max_submissions},
                    }
                )

            try:
                import pandas as _pd

                file_content = self._sandbox.read_file(filepath)
                if len(file_content) > 50 * 1024 * 1024:
                    return json.dumps({
                        "status": "error",
                        "error_type": "FileSizeExceeded",
                        "error_message": "Prediction file exceeds maximum allowed size of 50MB.",
                        "details": {"size_bytes": len(file_content), "max_bytes": 50 * 1024 * 1024},
                    })
                sub_df = _pd.read_csv(io.StringIO(file_content))

                # Validate columns match sample_submission
                expected_cols = set(self._sample_submission_df.columns)
                actual_cols = set(sub_df.columns)
                if actual_cols != expected_cols:
                    return json.dumps({
                        "status": "error",
                        "error_type": "ValueError",
                        "error_message": (
                            f"Column mismatch. Expected {sorted(expected_cols)}, "
                            f"got {sorted(actual_cols)}"
                        ),
                        "details": {
                            "expected_columns": sorted(expected_cols),
                            "actual_columns": sorted(actual_cols),
                        },
                    })

                # Validate length matches sample_submission
                if len(sub_df) != len(self._sample_submission_df):
                    return json.dumps({
                        "status": "error",
                        "error_type": "ValueError",
                        "error_message": (
                            f"Row count mismatch. Expected {len(self._sample_submission_df)} rows, "
                            f"got {len(sub_df)} rows."
                        ),
                        "details": {
                            "expected_rows": len(self._sample_submission_df),
                            "actual_rows": len(sub_df),
                        },
                    })

                # Validate id_column is unique
                if not sub_df[self._id_column].is_unique:
                    return json.dumps({
                        "status": "error",
                        "error_type": "ValueError",
                        "error_message": f"Duplicate IDs found in column {self._id_column!r}.",
                        "details": {},
                    })

                # Validate ids match
                expected_ids = set(self._sample_submission_df[self._id_column])
                actual_ids = set(sub_df[self._id_column])
                if actual_ids != expected_ids:
                    missing = len(expected_ids - actual_ids)
                    extra = len(actual_ids - expected_ids)
                    return json.dumps({
                        "status": "error",
                        "error_type": "ValueError",
                        "error_message": (
                            f"Id mismatch: {missing} missing, {extra} extra. "
                            f"Expected {len(expected_ids)} ids matching test.csv."
                        ),
                        "details": {
                            "missing_count": missing,
                            "extra_count": extra,
                            "expected_count": len(expected_ids),
                        },
                    })

                # Explicitly align sub_df to match sample_submission[id_column] order
                sub_df = sub_df.set_index(self._id_column).loc[self._sample_submission_df[self._id_column]].reset_index()

                # Join with solution on id_column
                target_cols = self._target_columns
                merged = self._solution_df.merge(
                    sub_df, on=self._id_column, suffixes=("_true", "_pred")
                )

                # Score each split using Usage column
                def _score_split(usage: str) -> float:
                    split = merged[merged["Usage"] == usage]
                    if len(split) == 0:
                        return float("nan")
                    true_cols = [f"{c}_true" for c in target_cols]
                    pred_cols = [f"{c}_pred" for c in target_cols]
                    y_true = split[true_cols].to_numpy()  # type: ignore
                    y_pred = split[pred_cols].to_numpy()  # type: ignore
                    return score_arrays(self._scorer, y_true, y_pred)

                public_score = _score_split("Public")
                private_score = _score_split("Private")

                self._submission_counter += 1
                sub_id = f"sub_{self._submission_counter}"

                self._submissions[sub_id] = Submission(
                    id=sub_id,
                    number=self._submission_counter,
                    public_score=public_score,
                    private_score=private_score,
                    predictions=sub_df[target_cols].values.tolist(),
                )

                logger.info(
                    "Submission %s (%s): %s public=%.6f private=%.6f",
                    sub_id,
                    filepath,
                    self._metric_name,
                    public_score,
                    private_score,
                )

                best_fn = max if self._higher_is_better else min
                pub_scores = [s.public_score for s in self._submissions.values() if not math.isnan(s.public_score)]
                best_public = best_fn(pub_scores) if pub_scores else float("nan")

                return json.dumps(
                    {
                        "status": "ok",
                        "submission_id": sub_id,
                        "filepath": filepath,
                        "score": round(public_score, 6),
                        "metric": self._metric_name,
                        "submission_number": self._submission_counter,
                        "remaining_submissions": self._max_submissions
                        - len(self._submissions),
                        "best_score": round(best_public, 6),
                        "all_submissions": [
                            {"id": s.id, "score": round(s.public_score, 6)}
                            for s in self._submissions.values()
                        ],
                    }
                )
            except FileNotFoundError:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": "FileNotFoundError",
                        "error_message": (
                            f"File not found: {filepath!r}. "
                            "Write the file using run_command first."
                        ),
                        "details": {"filepath": filepath},
                    }
                )
            except Exception as e:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "details": {},
                    }
                )

        def select_submission(submission_ids: list[str]) -> str:
            """Select submissions for final (test-set) scoring.

            Mimics Kaggle's 'select submissions for the private leaderboard'
            feature. If never called, the best public-set submission
            is used by default.

            Args:
                submission_ids: List of submission IDs (e.g., ["sub_1", "sub_3"]).
                    The maximum number allowed is determined by the configuration.

            Returns:
                JSON confirming the selection.
            """

            budget_error = self._check_budget("select_submission")
            if budget_error:
                return budget_error

            if not submission_ids:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": "ValueError",
                        "error_message": "Must provide at least one submission ID.",
                        "details": {},
                    }
                )

            if len(submission_ids) > self._max_selections:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": "SelectionLimitExceeded",
                        "error_message": (
                            f"Can select at most {self._max_selections} submissions, "
                            f"got {len(submission_ids)}."
                        ),
                        "details": {
                            "max_selections": self._max_selections,
                            "actual_selections": len(submission_ids),
                        },
                    }
                )

            unknown = [sid for sid in submission_ids if sid not in self._submissions]
            if unknown:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": "ValueError",
                        "error_message": f"Unknown submission IDs: {unknown}",
                        "details": {
                            "unknown_ids": unknown,
                            "available_ids": list(self._submissions.keys()),
                        },
                    }
                )

            self._selected_ids = list(dict.fromkeys(submission_ids))

            selected_info = [
                {"id": sid, "public_score": round(self._submissions[sid].score, 6)}
                for sid in self._selected_ids
            ]

            return json.dumps(
                {
                    "status": "ok",
                    "selected": selected_info,
                    "message": (
                        f"{len(self._selected_ids)} submission(s) selected for final scoring. "
                        "The best score on the test set will be your final score."
                    ),
                }
            )

        def get_status() -> str:
            """Get current evaluation status.

            Returns submission history, remaining budget, and selection status.

            Returns:
                JSON with complete status information.
            """

            budget_error = self._check_budget("get_status")
            if budget_error:
                return budget_error

            all_subs = [
                {"id": s.id, "score": round(s.public_score, 6)}
                for s in self._submissions.values()
            ]

            best_fn = max if self._higher_is_better else min
            pub_scores = [s.public_score for s in self._submissions.values() if not math.isnan(s.public_score)]
            best_public = best_fn(pub_scores, default=0) if pub_scores else 0

            elapsed_minutes = (time.perf_counter() - self._start_time) / 60.0
            status = {
                "tool_calls_used": self._tool_calls,
                "tool_calls_remaining": self._max_tool_calls - self._tool_calls,
                "submissions_used": len(self._submissions),
                "submissions_remaining": self._max_submissions - len(self._submissions),
                "time_minutes_used": round(elapsed_minutes, 2),
                "time_minutes_remaining": round(max(0.0, self._max_time_minutes - elapsed_minutes), 2),
                "all_submissions": all_subs,
                "best_score": round(best_public, 6),
                "metric": self._metric_name,
                "selected_submission_ids": (
                    self._selected_ids
                    if self._selected_ids
                    else "(none — best score will be used)"
                ),
            }

            status["token_budget"] = self._token_budget.to_status_dict()

            return json.dumps(status)

        def write_file(filepath: str, content: str) -> str:
            """Write a file to the sandbox working directory.

            Creates or overwrites a file at the given path. Use this to write
            Python scripts, configuration files, or any other text files.
            Parent directories are created automatically.

            This is more reliable than writing files via shell heredocs in
            run_command, especially for files with complex quoting.

            Args:
                filepath: Relative path within the working directory
                    (e.g., "train_model.py", "configs/params.json").
                content: The full file content as a string.

            Examples:
                # Write a Python training script
                write_file("train_model.py", '''
                import pandas as pd
                from sklearn.ensemble import RandomForestClassifier

                train = pd.read_csv("train.csv")
                sample = pd.read_csv("sample_submission.csv")
                id_col = sample.columns[0]
                target = sample.columns[1]
                
                X = train.drop(columns=[target, id_col])
                y = train[target]

                model = RandomForestClassifier(n_estimators=200)
                model.fit(X, y)

                test = pd.read_csv("test.csv")
                preds = model.predict_proba(test.drop(columns=[id_col]))[:, 1]
                sample[target] = preds
                sample.to_csv("submission.csv", index=False)
                print(f"Saved {len(preds)} predictions")
                ''')
            """

            budget_error = self._check_budget("write_file")
            if budget_error:
                return budget_error

            try:
                self._sandbox.write_file(filepath, content)
                return json.dumps(
                    {
                        "status": "ok",
                        "filepath": filepath,
                        "size": len(content),
                    }
                )
            except Exception as e:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "details": {},
                    }
                )

        def edit_file(
            filepath: str,
            old_string: str,
            new_string: str,
            allow_multiple: bool = False,
        ) -> str:
            """Replaces a specific block of text within a file in the sandbox working directory.

            Preferred over write_file for modifying existing files as it minimizes
            token usage and avoids accidental overwrites. The old_string must match
            the target file content exactly (or match with flexible indentation).

            Args:
                filepath: Relative path within the working directory (e.g., "train_model.py").
                old_string: The exact literal text to replace.
                new_string: The replacement text.
                allow_multiple: If True, replaces all occurrences of old_string.
                    If False (default), fails if more than one occurrence is found.

            Examples:
                # Update n_estimators in a training script
                edit_file(
                    "train_model.py",
                    old_string="model = RandomForestClassifier(n_estimators=100)",
                    new_string="model = RandomForestClassifier(n_estimators=200)",
                )
            """
            budget_error = self._check_budget("edit_file")
            if budget_error:
                return budget_error

            try:
                current_content = self._sandbox.read_file(filepath)
            except FileNotFoundError:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": "FileNotFoundError",
                        "error_message": (
                            f"File not found: {filepath!r}. "
                            "Use write_file to create new files."
                        ),
                        "details": {"filepath": filepath},
                    }
                )
            except Exception as e:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "details": {},
                    }
                )

            from kaggle_kaggle.edit import apply_replacement
            result = apply_replacement(current_content, old_string, new_string, allow_multiple)

            if result.error_message:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": "ReplaceError",
                        "error_message": result.error_message,
                        "details": {},
                    }
                )

            try:
                self._sandbox.write_file(filepath, result.new_content)

                import difflib
                diff_lines = list(
                    difflib.unified_diff(
                        current_content.splitlines(),
                        result.new_content.splitlines(),
                        fromfile="Current",
                        tofile="Proposed",
                        n=3,
                    )
                )
                diff = "\n".join(diff_lines)

                return json.dumps(
                    {
                        "status": "ok",
                        "filepath": filepath,
                        "occurrences": result.occurrences,
                        "strategy": result.strategy,
                        "diff_snippet": diff,
                    }
                )
            except Exception as e:
                return json.dumps(
                    {
                        "status": "error",
                        "error_type": type(e).__name__,
                        "error_message": str(e),
                        "details": {},
                    }
                )

        def read_file(filepath: str, start_line: int | None = None, end_line: int | None = None) -> str:
            """Read the contents of a file from the sandbox working directory.

            Supports reading specific line ranges using start_line and end_line (1-indexed).
            To avoid overwhelming the context window, large files are automatically truncated
            to a maximum number of lines (e.g., 500 lines).

            Args:
                filepath: Relative path within the working directory (e.g., "train.csv", "model_1.py").
                start_line: Optional starting line number (1-indexed, inclusive).
                end_line: Optional ending line number (1-indexed, inclusive).

            Returns:
                JSON string containing file content, line range, and truncation status.
            """
            budget_error = self._check_budget("read_file")
            if budget_error:
                return budget_error

            try:
                content = self._sandbox.read_file(filepath)
                lines = content.splitlines()
                total_lines = len(lines)

                start = start_line if start_line is not None else 1
                end = end_line if end_line is not None else total_lines

                if start < 1:
                    start = 1
                if end > total_lines:
                    end = total_lines

                if start > end:
                    return json.dumps({
                        "status": "error",
                        "error_type": "ValueError",
                        "error_message": f"start_line ({start}) cannot be greater than end_line ({end})",
                        "details": {},
                    })

                max_lines = 500
                is_truncated = False
                if (end - start + 1) > max_lines:
                    end = start + max_lines - 1
                    is_truncated = True

                selected_lines = lines[start - 1:end]
                snippet = "\n".join(selected_lines)

                if is_truncated:
                    header = (
                        f"IMPORTANT: The file content has been truncated.\n"
                        f"Status: Showing lines {start}-{end} of {total_lines} total lines.\n"
                        f"Action: To read more of the file, you can use the 'start_line' and 'end_line' "
                        f"parameters in a subsequent 'read_file' call. For example, to read the next section, "
                        f"use start_line: {end + 1}.\n\n"
                        f"--- FILE CONTENT (truncated) ---\n"
                    )
                    llm_content = header + snippet
                else:
                    llm_content = snippet

                return json.dumps({
                    "status": "ok",
                    "filepath": filepath,
                    "content": llm_content,
                    "start_line": start,
                    "end_line": end,
                    "total_lines": total_lines,
                    "is_truncated": is_truncated,
                })
            except Exception as e:
                return json.dumps({
                    "status": "error",
                    "error_type": type(e).__name__,
                    "error_message": str(e),
                    "details": {},
                })

        return {
            "run_command": run_command,
            "read_file": read_file,
            "write_file": write_file,
            "edit_file": edit_file,
            "submit_predictions": submit_predictions,
            "select_submission": select_submission,
            "get_status": get_status,
        }

    def get_final_submissions(self) -> list[Submission]:
        """Return the submissions to score on the test set.

        Always returns up to ``max_selections`` submissions:
        1. Start with the agent's explicit selections (via select_submission).
        2. Fill remaining slots with the best public-scoring submissions
           not already selected (matching real Kaggle behavior where
           auto-selection is based on the public leaderboard).
        """
        if not self._submissions:
            return []

        # Start with explicitly selected submissions
        final: list[Submission] = [
            self._submissions[sid]
            for sid in self._selected_ids
            if sid in self._submissions
        ]
        selected_ids = {s.id for s in final}

        # Fill remaining slots, ranked by public score
        remaining_slots = self._max_selections - len(final)
        if remaining_slots > 0:
            unselected = [
                s for s in self._submissions.values() if s.id not in selected_ids
            ]
            def safe_score(s: Submission) -> float:
                if math.isnan(s.public_score):
                    return float("-inf") if self._higher_is_better else float("inf")
                return s.public_score

            unselected.sort(key=safe_score, reverse=self._higher_is_better)
            final.extend(unselected[:remaining_slots])

        return final
