"""Display utilities for Kaggle-in-Kaggle evaluations.

Provides:
- ``EventDisplay``: live terminal display with a persistent status HUD
  and scrolling event log, powered by ``rich``.
- ``StatusPanel``: renders the HUD as a ``rich`` Panel with budget gauges,
  score history, and elapsed time.
- ``print_results``: formatted three-leaderboard results summary.
"""

from __future__ import annotations

import asyncio
import json
import math
import time
import threading
from dataclasses import dataclass, field
from typing import Any, TYPE_CHECKING

from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.progress_bar import ProgressBar
from rich.table import Table
from rich.text import Text
from rich.markup import escape

if TYPE_CHECKING:
    from kaggle_kaggle.context import KaggleKaggleContext
    from kaggle_kaggle.evaluation import Evaluation


# Re-export for backward compatibility; canonical import is from utils.
from kaggle_kaggle.utils import unwrap_tool_response as _unwrap_tool_response


# ---------------------------------------------------------------------------
# Status HUD
# ---------------------------------------------------------------------------


def _gauge_color(fraction: float) -> str:
    """Return a ``rich`` style name based on budget usage fraction.

    Green below 50%, yellow from 50–80%, red above 80%.
    """
    if fraction < 0.5:
        return "green"
    if fraction < 0.8:
        return "yellow"
    return "red"


_DETAIL_MAX_LINES = 12


@dataclass
class _EventContext:
    """Per-event display context computed once in on_event."""

    ts: str
    indent: str
    author_tag: str
    is_sub: bool
    author: str


@dataclass
class _DetailEntry:
    """Stores full content for the auto-expanding detail panel."""

    icon: str
    title: str
    sections: list[tuple[str, str]] = field(default_factory=list)


class StatusPanel:
    """Renders the persistent status HUD as a ``rich`` Panel.

    Reads live state from a :class:`KaggleKaggleContext` reference to
    display budget gauges, score history, and elapsed time.

    Args:
        ctx: The live context reference (may be ``None`` for a minimal HUD).
        problem_id: Problem identifier shown in the header.
        metric: Metric name shown in the header.
        higher_is_better: Whether higher metric values are better.
    """

    def __init__(
        self,
        *,
        evaluation: "Evaluation | None" = None,
        ctx: "KaggleKaggleContext | None" = None,
        problem_id: str = "",
        metric: str = "",
        higher_is_better: bool = True,
    ) -> None:
        if evaluation is not None:
            self._eval = evaluation
            self._ctx = evaluation.ctx
        elif ctx is not None:
            self._eval = None
            self._ctx = ctx
        else:
            self._eval = None
            self._ctx = None

        self._problem_id = problem_id
        self._metric = metric
        self._higher_is_better = higher_is_better
        self._start_time: float = time.time()

    def reset(self) -> None:
        """Reset the elapsed timer."""
        self._start_time = time.time()

    # -- internal helpers ---------------------------------------------------

    def _format_elapsed(self) -> str:
        """Return human-readable elapsed time."""
        elapsed = time.time() - self._start_time
        m, s = divmod(int(elapsed), 60)
        return f"{m}m {s:02d}s"

    def _best_score(self) -> float | None:
        """Return the best public score so far, or ``None``."""
        if not self._ctx:
            return None
        subs = self._ctx.submissions
        if not subs:
            return None
        scores = [s.public_score for s in subs.values() if s.public_score is not None]
        if not scores:
            return None
        return max(scores) if self._higher_is_better else min(scores)

    # -- rendering ----------------------------------------------------------

    def render(self) -> Panel:
        """Build and return the HUD as a ``rich.Panel``."""
        direction = "↑" if self._higher_is_better else "↓"

        # Header line: problem · metric (↑/↓) · elapsed · tokens · best score
        header = Text()
        header.append(f"  {self._problem_id}", style="bold cyan")
        if self._metric:
            header.append(f"  ·  {self._metric} ({direction})", style="dim")
        header.append(f"  ·  {self._format_elapsed()}", style="bold white")

        if self._ctx and self._ctx.token_budget:
            tb = self._ctx.token_budget
            in_tok = tb.total_input_tokens
            out_tok = tb.total_output_tokens
            cached_tok = getattr(tb, "total_cached_input_tokens", 0)
            last_in = getattr(tb, "last_input_tokens", 0)
            llm_calls = getattr(tb, "llm_calls", 0)
            total_tok = in_tok + out_tok
            if cached_tok > 0:
                header.append(f"  ·  {total_tok:,} tok (ctx: {last_in:,} | {in_tok:,} in [{cached_tok:,} cached] / {out_tok:,} out | {llm_calls} calls)", style="bold yellow")
            else:
                header.append(f"  ·  {total_tok:,} tok (ctx: {last_in:,} | {in_tok:,} in / {out_tok:,} out | {llm_calls} calls)", style="bold yellow")

        best = self._best_score()
        if best is not None:
            header.append(f"  ·  Best: {best:.4f}", style="bold green")

        rows: list[Any] = [header]

        if self._ctx:
            rows.append(Text())  # spacer
            rows.append(self._render_budget_gauges())

            # Score history
            subs = self._ctx.submissions
            if subs:
                rows.append(Text())
                rows.append(self._render_score_history(subs))

        return Panel(
            Group(*rows),
            title="[bold]Kaggle-in-Kaggle[/bold]",
            border_style="blue",
            padding=(0, 1),
        )

    def _render_budget_gauges(self) -> Table:
        """Render the tool-call / submission / cost budget gauges."""
        ctx = self._ctx
        assert ctx is not None  # caller guarantees

        gauge = Table.grid(padding=(0, 1))
        gauge.add_column("label", width=14, justify="right")
        gauge.add_column("bar", width=22)
        gauge.add_column("numbers")

        # Tool calls
        tc = ctx.tool_calls
        tc_max = ctx.max_tool_calls
        tc_frac = tc / tc_max if tc_max > 0 else 0
        pb_tc_total = tc_max if tc_max > 0 else None
        tc_label = f"  {tc} / {tc_max}  ({tc_max - tc} left)" if tc_max > 0 else f"  {tc} (Unlimited)"
        gauge.add_row(
            Text("Tools", style="bold"),
            ProgressBar(
                total=pb_tc_total,
                completed=tc,
                complete_style=_gauge_color(tc_frac),
                finished_style="red",
            ),
            Text(tc_label, style="dim"),
        )

        # Submissions
        n_sub = len(ctx.submissions)
        sub_max = ctx.max_submissions
        sub_frac = n_sub / sub_max if sub_max > 0 else 0
        pb_sub_total = sub_max if sub_max > 0 else None
        sub_label = f"  {n_sub} / {sub_max}  ({sub_max - n_sub} left)" if sub_max > 0 else f"  {n_sub} (Unlimited)"
        gauge.add_row(
            Text("Submissions", style="bold"),
            ProgressBar(
                total=pb_sub_total,
                completed=n_sub,
                complete_style=_gauge_color(sub_frac),
                finished_style="red",
            ),
            Text(sub_label, style="dim"),
        )

        # Token cost
        tb = ctx.token_budget
        if tb:
            cost = tb.total_cost_usd
            cap = tb.max_budget_usd
            frac = cost / cap if cap > 0 else 0
            pb_cap_total = cap if cap > 0 else None
            remaining = max(0.0, cap - cost)
            cost_label = f"  ${cost:.2f} / ${cap:.2f}  (${remaining:.2f} left)" if cap > 0 else f"  ${cost:.2f} (Unlimited)"
            gauge.add_row(
                Text("Cost", style="bold"),
                ProgressBar(
                    total=pb_cap_total,
                    completed=min(cost, cap) if cap > 0 else cost,
                    complete_style=_gauge_color(frac),
                    finished_style="red",
                ),
                Text(cost_label, style="dim"),
            )

        time_max = ctx.max_time_minutes
        elapsed_mins = (time.time() - self._start_time) / 60.0
        time_frac = elapsed_mins / time_max if time_max > 0 else 0
        pb_time_total = time_max if time_max > 0 else None
        rem_mins = max(0.0, time_max - elapsed_mins)
        time_label = f"  {elapsed_mins:.1f}m / {time_max}m  ({rem_mins:.1f}m left)" if time_max > 0 else f"  {elapsed_mins:.1f}m (Unlimited)"
        gauge.add_row(
            Text("Time", style="bold"),
            ProgressBar(
                total=pb_time_total,
                completed=min(elapsed_mins, time_max) if time_max > 0 else elapsed_mins,
                complete_style=_gauge_color(time_frac),
                finished_style="red",
            ),
            Text(time_label, style="dim"),
        )

        return gauge

    def _render_score_history(self, subs: dict) -> Text:
        """Render the inline score history line."""
        best_val = self._best_score()
        selected_ids = set(getattr(self._ctx, "selected_ids", [])) if self._ctx else set()
        get_final_fn = getattr(self._ctx, "get_final_submissions", None) if self._ctx else None
        final_subs = get_final_fn() if get_final_fn else []
        final_ids = {s.id for s in final_subs}
        auto_selected_ids = final_ids - selected_ids

        line = Text("  Scores: ", style="bold")
        for sub in subs.values():
            s = sub.public_score
            is_best = best_val is not None and math.isclose(s, best_val)
            is_selected = sub.id in selected_ids
            is_auto = sub.id in auto_selected_ids

            marker = ""
            if is_selected:
                marker = "✓"
            elif is_auto:
                marker = "*"

            if is_best:
                line.append(f"[{s:.4f}]{marker}", style="bold green")
            elif is_selected:
                line.append(f" {s:.4f}{marker} ", style="bold cyan")
            elif is_auto:
                line.append(f" {s:.4f}{marker} ", style="bold yellow")
            else:
                line.append(f" {s:.4f} ", style="dim")
            line.append("  ")
        return line


# ---------------------------------------------------------------------------
# Event display
# ---------------------------------------------------------------------------


class EventDisplay:
    """Live display with a persistent status HUD and scrolling event log.

    Uses ``rich.live.Live`` to keep the HUD fixed at the bottom of the
    terminal while event log lines scroll above it.

    Usage::

        display = EventDisplay(ctx=ctx, problem_id="toy", metric="roc_auc")
        with display:
            result = await run_problem(..., on_event=display.on_event)

    Args:
        ctx: Optional :class:`KaggleKaggleContext` for live budget/score data.
            If ``None``, the HUD shows only elapsed time and problem info.
        problem_id: Problem identifier to show in the HUD.
        metric: Metric name to show in the HUD.
        higher_is_better: Whether higher metric values are better.
        root_agent_name: Name of the root agent. Used to distinguish
            sub-agent events. If empty, the first event's author is used.
    """

    def __init__(
        self,
        *,
        evaluation: "Evaluation | None" = None,
        ctx: "KaggleKaggleContext | None" = None,
        problem_id: str = "",
        metric: str = "",
        higher_is_better: bool = True,
        root_agent_name: str = "",
    ) -> None:
        if evaluation is not None:
            self._eval = evaluation
            self._ctx = evaluation.ctx
            evaluation.add_observer(self.on_event)
        else:
            self._eval = None
            self._ctx = ctx

        self._console = Console()
        self._panel = StatusPanel(
            ctx=self._ctx,
            problem_id=problem_id,
            metric=metric,
            higher_is_better=higher_is_better,
        )
        self._live: Live | None = None
        self._disp_id: str | None = None
        self._start: float | None = None
        self._detail: _DetailEntry | None = None
        self._root_author: str | None = root_agent_name or None
        self._log_buffer: list[str] = []
        self._persistent_logs: list[str] = []
        self._lock = threading.RLock()
        self._queue: asyncio.Queue | None = None
        self._worker_task: asyncio.Task | None = None

    # -- lifecycle ----------------------------------------------------------

    def reset(self) -> None:
        """Reset the elapsed timer."""
        self._start = time.time()
        self._panel._start_time = self._start
        self._detail = None

    def start(self) -> None:
        """Start the live display."""
        self._start = time.time()
        self._panel._start_time = self._start
        if self._console.is_jupyter:
            import uuid
            from IPython.display import display as ipy_display

            self._disp_id = f"event_display_{uuid.uuid4().hex}"
            self._persistent_logs = []
            ipy_display(
                self._get_jupyter_renderable(self._build_live_renderable()),
                display_id=self._disp_id,
            )
        else:
            self._live = Live(
                self._build_live_renderable(),
                console=self._console,
                refresh_per_second=4,
            )
            self._live.start()

        try:
            loop = asyncio.get_running_loop()
            self._queue = asyncio.Queue()
            self._worker_task = loop.create_task(self._worker_loop())
        except RuntimeError:
            self._queue = None
            self._worker_task = None

    async def _worker_loop(self) -> None:
        """Background worker task that pulls events sequentially from the queue."""
        assert self._queue is not None
        while True:
            try:
                event = await self._queue.get()
                self._process_event(event)
                self._queue.task_done()
            except asyncio.CancelledError:
                break
            except Exception:
                pass

    def stop(self) -> None:
        """Stop the live display and print the final HUD state."""
        if self._worker_task is not None:
            if self._queue is not None:
                while not self._queue.empty():
                    try:
                        event = self._queue.get_nowait()
                        self._process_event(event)
                        self._queue.task_done()
                    except Exception:
                        break
            self._worker_task.cancel()
            self._worker_task = None
            self._queue = None

        if self._live:
            # One last refresh so the HUD reflects final state
            self._live.update(self._build_live_renderable())
            self._live.stop()
            self._live = None
        elif self._console.is_jupyter and self._disp_id:
            from IPython.display import update_display

            update_display(
                self._get_jupyter_renderable(self._build_live_renderable()),
                display_id=self._disp_id,
            )
            self._disp_id = None

    def __enter__(self) -> "EventDisplay":
        self.start()
        return self

    def __exit__(self, *args: Any) -> None:
        self.stop()

    # -- output helpers -----------------------------------------------------

    def _ts(self) -> str:
        """Return a ``rich``-formatted elapsed timestamp."""
        if self._start is None:
            self._start = time.time()
        elapsed = time.time() - self._start
        return f"[dim]\\[{elapsed:6.1f}s][/dim]"

    def _print(self, markup: str) -> None:
        """Buffer a log line to be printed later.

        Buffered lines are flushed together by ``_flush_logs`` to avoid
        excessive HUD teardown/redraw cycles.
        """
        self._log_buffer.append(markup)
        if self._console.is_jupyter:
            self._persistent_logs.append(markup)

    def _flush_logs(self) -> None:
        """Print all buffered log lines at once and clear the buffer."""
        with self._lock:
            if not self._log_buffer:
                return
            logs = self._log_buffer
            self._log_buffer = []

        if not self._console.is_jupyter:
            self._console.print(*logs, sep="\n", highlight=False)

    def _get_jupyter_renderable(self, renderable: Any) -> Any:
        from rich.jupyter import _render_segments, JupyterRenderable

        segments = list(self._console.render(renderable))
        html = _render_segments(segments)
        text = self._console._render_buffer(segments)
        return JupyterRenderable(html, text)

    def _refresh_hud(self) -> None:
        """Repaint the HUD panel."""
        if self._live:
            self._live.update(self._build_live_renderable(), refresh=False)
        elif self._console.is_jupyter and self._disp_id:
            from IPython.display import update_display

            update_display(
                self._get_jupyter_renderable(self._build_live_renderable()),
                display_id=self._disp_id,
            )

    def _build_live_renderable(self) -> Group:
        """Build the full Live renderable: detail panel + HUD."""
        with self._lock:
            parts = []
            if self._console.is_jupyter and self._persistent_logs:
                log_text = Text()
                for line in self._persistent_logs:
                    log_text.append_text(Text.from_markup(line))
                    log_text.append("\n")
                parts.append(log_text)

            if self._detail:
                parts.append(self._render_detail())
            parts.append(self._panel.render())
            return Group(*parts)

    def _render_detail(self) -> Panel:
        """Render the detail panel for the most recent substantial event.

        Enforces a total line budget across all sections so the panel
        never grows large enough to push the HUD off-screen.  When the
        budget is exceeded, only the most recent lines are shown.
        """
        d = self._detail
        assert d is not None
        header = Text(f"  {d.icon} {d.title}", style="bold")

        # Collect all content lines across every section.
        all_lines: list[Text] = []
        for label, content in d.sections:
            all_lines.append(Text(f"\n  {label}:", style="bold dim"))
            content_str = str(content) if content is not None else ""
            for line in content_str.strip().splitlines():
                all_lines.append(Text(f"    {line}"))

        # Keep only the tail so the panel stays within budget.
        if len(all_lines) > _DETAIL_MAX_LINES:
            skipped = len(all_lines) - _DETAIL_MAX_LINES
            all_lines = [
                Text(f"    ... ({skipped} earlier lines)", style="dim")
            ] + all_lines[-_DETAIL_MAX_LINES:]

        return Panel(
            Group(header, *all_lines),
            title="[dim]Latest Detail[/dim]",
            border_style="dim",
            padding=(0, 1),
        )

    def _set_detail(
        self, icon: str, title: str, sections: list[tuple[str, str]]
    ) -> None:
        """Set the detail panel content."""
        self._detail = _DetailEntry(icon=icon, title=title, sections=sections)

    def _append_or_set_detail(
        self, icon: str, title: str, sections: list[tuple[str, str]]
    ) -> None:
        """Append sections to existing detail if title matches, else create new."""
        if self._detail and self._detail.title == title:
            self._detail.sections.extend(sections)
        else:
            self._detail = _DetailEntry(icon=icon, title=title, sections=sections)

    def _append_subagent_detail(self, author: str, action: str, content: str) -> None:
        """Append sub-agent activity to the current detail panel.

        Sections are labelled as ``author → action`` so the viewer can
        trace which sub-agent performed each step.
        """
        label = f"{author} → {action}"
        if self._detail:
            self._detail.sections.append((label, content))
        else:
            self._detail = _DetailEntry(
                icon="🤖", title=author, sections=[(label, content)]
            )

    def _update_detail(
        self,
        icon: str,
        title: str,
        sections: list[tuple[str, str]],
        *,
        is_sub: bool = False,
        author: str = "",
        append: bool = False,
    ) -> None:
        """Route detail updates: append for sub-agents, set/replace for root."""
        if is_sub:
            for label, content in sections:
                self._append_subagent_detail(author, label, content)
        elif append:
            self._append_or_set_detail(icon, title, sections)
        else:
            self._set_detail(icon, title, sections)

    # -- event callback -----------------------------------------------------

    def _is_subagent_event(self, event: Any) -> tuple[bool, str]:
        """Check if this event comes from a sub-agent.

        Returns ``(is_subagent, author_name)``.  The first event seen
        sets ``_root_author``; subsequent events with a different author
        are treated as sub-agent events.
        """
        author = getattr(event, "author", None) or ""
        if self._root_author is None and author:
            self._root_author = author
        is_sub = bool(author and self._root_author and author != self._root_author)
        return is_sub, author

    def on_event(self, event: Any) -> None:
        """Callback to pass as ``on_event`` to :func:`run_problem`.

        If running in an async context with a background worker, queues the
        event. Otherwise processes it synchronously.
        """
        if self._queue is not None:
            self._queue.put_nowait(event)
        else:
            self._process_event(event)

    def _process_event(self, event: Any) -> None:
        """Actual event processing logic."""
        with self._lock:
            if self._start is None:
                self._start = time.time()

            is_sub, author = self._is_subagent_event(event)
            ectx = _EventContext(
                ts=self._ts(),
                indent="  [dim]\u2502[/dim] " if is_sub else "",
                author_tag=f"[dim]({author})[/dim] " if is_sub else "",
                is_sub=is_sub,
                author=author,
            )

            # Check for compaction event
            if hasattr(event, "actions") and event.actions and type(event.actions).__name__ != "MagicMock" and hasattr(event.actions, "compaction") and event.actions.compaction:
                comp = event.actions.compaction
                summary_text = ""
                if hasattr(comp, "compacted_content") and comp.compacted_content and hasattr(comp.compacted_content, "parts"):
                    for part in comp.compacted_content.parts:
                        if hasattr(part, "text") and part.text:
                            summary_text += part.text
                self._print(
                    f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[bold yellow]🗜️ Compaction[/bold yellow] [dim](range: {comp.start_timestamp} - {comp.end_timestamp})[/dim]"
                )
                self._update_detail(
                    "🗜️",
                    "Compaction",
                    [("Range", f"{comp.start_timestamp} - {comp.end_timestamp}"), ("Summary", summary_text.strip())],
                    is_sub=ectx.is_sub,
                    author=ectx.author,
                )
                self._flush_logs()
                self._refresh_hud()
                return

            content = getattr(event, "content", None)
            if not content or not hasattr(content, "parts") or not content.parts:
                return

            for part in content.parts:
                if hasattr(part, "function_call") and part.function_call:
                    self._handle_tool_call(part.function_call, ectx)

                elif hasattr(part, "function_response") and part.function_response:
                    self._handle_tool_response(part.function_response, content, ectx)

                elif (
                    hasattr(part, "thought")
                    and part.thought
                    and getattr(part, "text", None)
                ):
                    text = part.text.strip()
                    n = len(text)
                    preview = text[:120] + "..." if n > 120 else text
                    self._print(
                        f'  {ectx.ts} {ectx.indent}{ectx.author_tag}[dim]💭 ({n} chars) "{escape(preview)}"[/dim]'
                    )
                    self._update_detail(
                        "💭",
                        "Thinking",
                        [("Thought", text)],
                        is_sub=ectx.is_sub,
                        author=ectx.author,
                    )

                elif hasattr(part, "text") and part.text and part.text.strip():
                    self._handle_text(part, event, content, ectx)

        # Flush and refresh outside the lock: _build_live_renderable also
        # acquires self._lock, so calling these inside would deadlock.
        self._flush_logs()
        self._refresh_hud()

    # -- per-event-type formatters ------------------------------------------

    def _handle_tool_call(self, fc: Any, ectx: _EventContext) -> None:
        """Format and print a tool call event."""
        args = dict(fc.args) if fc.args else {}

        if fc.name == "run_command":
            cmd = args.get("command", "")
            lines = cmd.splitlines()
            n = len(lines)
            preview = lines[0][:80] if lines else ""
            count = f" ({n} lines)" if n > 1 else ""
            self._print(
                f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[bold cyan]🔧 run_command[/bold cyan]"
                f"[dim]{count}[/dim] [grey50]{escape(preview)}[/grey50]"
            )
            self._update_detail(
                "🔧",
                "run_command",
                [("Command", cmd)],
                is_sub=ectx.is_sub,
                author=ectx.author,
            )
        elif fc.name == "write_file":
            fp = args.get("filepath", "?")
            content = args.get("content", "")
            n = len(content.splitlines())
            self._print(
                f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[cyan]📝 write_file[/cyan] [dim]({escape(fp)}, {n} lines)[/dim]"
            )
            truncated_content = "\n".join(content.splitlines()[:50])
            if n > 50:
                truncated_content += f"\n... ({n - 50} more lines omitted)"
            self._update_detail(
                "📝",
                "write_file",
                [("Path", fp), ("Content", truncated_content)],
                is_sub=ectx.is_sub,
                author=ectx.author,
            )
        elif fc.name == "submit_predictions":
            fp = args.get("filepath", "?")
            self._print(
                f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[bold magenta]📊 submit_predictions[/bold magenta]"
                f" [dim]({escape(fp)})[/dim]"
            )
            self._update_detail(
                "📊",
                "submit_predictions",
                [("File", fp)],
                is_sub=ectx.is_sub,
                author=ectx.author,
            )
        elif fc.name == "select_submission":
            ids = args.get("submission_ids", [])
            self._print(
                f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[bold green]✅ select_submission[/bold green]"
                f" [dim]{escape(str(ids))}[/dim]"
            )
            self._update_detail(
                "✅",
                "select_submission",
                [("IDs", str(ids))],
                is_sub=ectx.is_sub,
                author=ectx.author,
            )
        elif fc.name == "get_status":
            self._print(
                f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[blue]📋 get_status[/blue]"
            )
        else:
            # AgentTool and other tools — show a preview of the args
            preview = ""
            if "request" in args:
                # AgentTool: show the delegated prompt
                req = str(args["request"])
                preview = req[:100] + "..." if len(req) > 100 else req
                self._set_detail("🤖", fc.name, [("Request", req)])
            elif args:
                flat = json.dumps(args, default=str)
                preview = flat[:100] + "..." if len(flat) > 100 else flat
                self._set_detail(
                    "🤖", fc.name, [("Args", json.dumps(args, indent=2, default=str))]
                )
            else:
                self._set_detail("🤖", fc.name, [("Args", "{}")])
            suffix = f" [dim]{escape(preview)}[/dim]" if preview else ""
            self._print(
                f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[cyan]🤖 {escape(fc.name)}[/cyan]{suffix}"
            )

    def _handle_tool_response(self, fr: Any, content: Any, ectx: _EventContext) -> None:
        """Format and print a tool response event."""
        name = getattr(fr, "name", "") or ""
        parsed = _unwrap_tool_response(fr)
        if parsed is None:
            return

        if name == "submit_predictions":
            if parsed.get("status") == "ok":
                self._print(
                    f"  {ectx.ts}   {ectx.indent}{ectx.author_tag}[bold yellow]→ {escape(str(parsed['submission_id']))}: "
                    f"score={escape(str(parsed.get('score', '?')))} "
                    f"(best={escape(str(parsed.get('best_score', '?')))}, "
                    f"{escape(str(parsed.get('remaining_submissions', '?')))} remaining)"
                    f"[/bold yellow]"
                )
                result_text = f"ID: {parsed['submission_id']}, Score: {parsed.get('score', '?')}, Best: {parsed.get('best_score', '?')}, Remaining: {parsed.get('remaining_submissions', '?')}"
                self._update_detail(
                    "📊",
                    "submit_predictions",
                    [("Result", result_text)],
                    is_sub=ectx.is_sub,
                    author=ectx.author,
                    append=True,
                )
            else:
                self._print(
                    f"  {ectx.ts}   {ectx.indent}{ectx.author_tag}[bold red]→ submit error: "
                    f"{escape(str(parsed.get('error_message', 'error')))}[/bold red]"
                )
                err = parsed.get("error_message", "error")
                self._update_detail(
                    "📊",
                    "submit_predictions",
                    [("Error", err)],
                    is_sub=ectx.is_sub,
                    author=ectx.author,
                    append=True,
                )

        elif name == "run_command":
            if parsed.get("status") == "error":
                stderr = parsed.get("stderr", "")
                self._print(
                    f"  {ectx.ts}   {ectx.indent}{ectx.author_tag}[bold red]→ error "
                    f"(exit {escape(str(parsed.get('exit_code', '?')))}): "
                    f"{escape(str(stderr)[:120])}[/bold red]"
                )
                err_text = f"Exit {parsed.get('exit_code', '?')}\n{stderr}"
                self._update_detail(
                    "🔧",
                    "run_command",
                    [("Error", err_text)],
                    is_sub=ectx.is_sub,
                    author=ectx.author,
                    append=True,
                )
            elif parsed.get("status") == "ok":
                stdout = parsed.get("stdout", "")
                if stdout:
                    preview = stdout.strip().splitlines()[0][:120]
                    self._print(
                        f"  {ectx.ts}   {ectx.indent}{ectx.author_tag}[green]→ {escape(preview)}[/green]"
                    )
                self._update_detail(
                    "🔧",
                    "run_command",
                    [("Output", stdout)],
                    is_sub=ectx.is_sub,
                    author=ectx.author,
                    append=True,
                )

        elif name == "get_status":
            tb_dict = parsed.get("token_budget", {})
            cached_tok = tb_dict.get("total_cached_input_tokens", 0)
            if cached_tok > 0:
                tokens_str = (
                    f", tokens={tb_dict.get('total_tokens', '?'):,} "
                    f"({tb_dict.get('total_input_tokens', '?'):,} in [{cached_tok:,} cached] / {tb_dict.get('total_output_tokens', '?'):,} out)"
                    if "total_tokens" in tb_dict and isinstance(tb_dict.get("total_tokens"), int)
                    else ""
                )
            else:
                tokens_str = (
                    f", tokens={tb_dict.get('total_tokens', '?'):,} "
                    f"({tb_dict.get('total_input_tokens', '?'):,} in / {tb_dict.get('total_output_tokens', '?'):,} out)"
                    if "total_tokens" in tb_dict and isinstance(tb_dict.get("total_tokens"), int)
                    else ""
                )
            cost_val = tb_dict.get("total_cost_usd")
            cost_str = f", cost=${cost_val:.2f}" if isinstance(cost_val, (int, float)) else ""
            self._print(
                f"  {ectx.ts}   {ectx.indent}{ectx.author_tag}[dim]→ {escape(str(parsed.get('tool_calls_used', '?')))} tool calls, "
                f"{escape(str(parsed.get('submissions_used', '?')))} submissions, "
                f"time={escape(str(parsed.get('time_minutes_used', '?')))}m / {escape(str(parsed.get('time_minutes_remaining', '?')))}m left, "
                f"best={escape(str(parsed.get('best_score', '?')))}{tokens_str}{cost_str}[/dim]"
            )

        elif name == "select_submission":
            if parsed.get("status") == "ok":
                self._print(
                    f"  {ectx.ts}   {ectx.indent}{ectx.author_tag}[green]→ selected: "
                    f"{escape(str(parsed.get('selected', [])))}[/green]"
                )
                self._update_detail(
                    "✅",
                    "select_submission",
                    [("Result", str(parsed))],
                    is_sub=ectx.is_sub,
                    author=ectx.author,
                    append=True,
                )
            else:
                self._print(
                    f"  {ectx.ts}   {ectx.indent}{ectx.author_tag}[bold red]→ select error: "
                    f"{escape(str(parsed.get('error_message', 'error')))}[/bold red]"
                )
                self._update_detail(
                    "✅",
                    "select_submission",
                    [("Result", str(parsed))],
                    is_sub=ectx.is_sub,
                    author=ectx.author,
                    append=True,
                )

        else:
            # AgentTool and other tools — show a truncated preview
            flat = json.dumps(parsed, default=str)
            preview = flat[:150] + "..." if len(flat) > 150 else flat
            self._print(
                f"  {ectx.ts}   {ectx.indent}{ectx.author_tag}[dim]→ {escape(name)}: {escape(preview)}[/dim]"
            )
            self._update_detail(
                "🤖",
                name,
                [("Response", json.dumps(parsed, indent=2, default=str))],
                is_sub=ectx.is_sub,
                author=ectx.author,
                append=True,
            )

    def _handle_text(
        self, part: Any, event: Any, content: Any, ectx: _EventContext
    ) -> None:
        """Format and print a text or final-response event."""
        is_final_raw = hasattr(event, "is_final_response") and event.is_final_response()
        # Exclude events with function parts — these are tool deliveries,
        # not genuine final responses.
        has_fn_parts = any(
            getattr(p, "function_call", None) or getattr(p, "function_response", None)
            for p in content.parts
        )
        is_final = is_final_raw and not has_fn_parts

        limit = 200 if is_final else 150
        text = part.text.strip()
        preview = text[:limit] + "..." if len(text) > limit else text

        if is_final:
            self._print(
                f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[bold green]✅ Agent finished:[/bold green]"
                f" [dim]{escape(preview)}[/dim]"
            )
            self._update_detail(
                "✅",
                "Agent Finished",
                [("Message", text)],
                is_sub=ectx.is_sub,
                author=ectx.author,
            )
        else:
            self._print(
                f"  {ectx.ts} {ectx.indent}{ectx.author_tag}[yellow]💬 {escape(preview)}[/yellow]"
            )
            self._update_detail(
                "💬",
                "Agent Message",
                [("Message", text)],
                is_sub=ectx.is_sub,
                author=ectx.author,
            )


# ---------------------------------------------------------------------------
# Results summary
# ---------------------------------------------------------------------------


def print_results(result: Any, *, use_color: bool | None = None) -> None:
    """Print a formatted evaluation results summary for a :class:`ProblemResult`.

    Displays resource usage, token costs, and public/private leaderboard scores.
    Selected submissions are annotated.

    Args:
        result: A :class:`~kaggle_kaggle.loop.ProblemResult` instance.
        use_color: If ``None`` (default), auto-detect from ``sys.stdout.isatty()``.
    """
    import sys

    force = sys.stdout.isatty() if use_color is None else use_color
    console = Console(force_jupyter=False, force_terminal=force, highlight=False)

    console.rule("[bold]EVALUATION RESULTS[/bold]")
    console.print(f"  Problem:          {escape(str(result.problem_id))}")
    console.print(f"  Metric:           {escape(str(result.metric))}")
    status_icon = {
        "completed": "[bold green]✓[/bold green]",
        "interrupted": "[bold yellow]⚠[/bold yellow]",
        "budget_exceeded": "[bold red]💸[/bold red]",
        "agent_error": "[bold red]✗[/bold red]",
        "no_submissions": "[dim]—[/dim]",
    }.get(result.end_status, "[dim]?[/dim]")
    console.print(f"  Status:           {status_icon} {escape(str(result.end_status).replace('_', ' '))}")
    console.print(f"  Tool calls used:  {result.tool_calls_used}")
    console.print(f"  Submissions used: {result.submissions_used}")
    console.print(f"  Wall time:        {result.wall_time_seconds:.1f}s")

    if result.trace:
        total_tokens = result.total_input_tokens + result.total_output_tokens
        console.print(f"  Total tokens:     {total_tokens:,}")
        console.print(f"    Input tokens:   {result.total_input_tokens:,}")
        if getattr(result, 'total_cached_input_tokens', 0) > 0:
            console.print(f"    Cached tokens:  {result.total_cached_input_tokens:,}")
        console.print(f"    Output tokens:  {result.total_output_tokens:,}")
        console.print(f"  LLM calls:        {result.llm_calls}")
        console.print(f"  Total cost:       ${result.total_cost_usd:.4f}")
        if result.max_budget_usd > 0:
            remaining = max(0.0, result.max_budget_usd - result.total_cost_usd)
            console.print(
                f"  Token budget:     ${result.total_cost_usd:.4f} / "
                f"${result.max_budget_usd:.2f} (${remaining:.4f} remaining)"
            )

        breakdown = result.trace.tool_call_breakdown
        if breakdown:
            console.print("  Tool breakdown:")
            for name, count in sorted(breakdown.items()):
                console.print(f"    {name}: {count}")

    console.print()

    if not result.public_scores:
        console.print("  No submissions were made.")
        console.rule()
        return

    def _marker(sub_id: str) -> str:
        if sub_id in result.selected_ids:
            return " [bold green]← selected[/bold green]"
        if sub_id in result.auto_selected_ids:
            return " [bold yellow]← auto-selected[/bold yellow]"
        return ""

    console.print("  [bold]Public Leaderboard (shown to agent):[/bold]")
    for sub_id, score in result.public_scores.items():
        console.print(f"    {escape(str(sub_id))}: {score:.6f}{_marker(sub_id)}")
    console.print(f"  Best public score:  {result.best_public_score:.6f}")
    console.print()

    console.print("  [bold]Private Leaderboard (hidden from agent):[/bold]")
    for sub_id, score in result.private_scores.items():
        console.print(f"    {escape(str(sub_id))}: {score:.6f}{_marker(sub_id)}")
    console.print(f"  Best private score: {result.best_private_score:.6f}")
    console.print()
    console.print(f"  [bold]★ FINAL SCORE  (private):  {result.final_score:.6f}[/bold]")
    console.rule()
