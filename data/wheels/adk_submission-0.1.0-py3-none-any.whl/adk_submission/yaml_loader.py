"""Sandboxed YAML loader with ``!include`` support.

The ``!include`` tag resolves file paths **relative to the including
file's directory**, but strictly within the submission root directory.
Path traversal outside the root (via ``..`` or symlinks) is blocked.

Public entry points:
    - :func:`load_yaml`: Load a YAML file with sandboxed include support.
    - :func:`make_sandboxed_loader`: Create a bound loader class for custom loading.
"""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml

from .errors import PathTraversalError, SubmissionValidationError

# File extensions that !include may resolve to.
_INCLUDABLE_TEXT_EXTENSIONS: frozenset[str] = frozenset({".md", ".txt"})
_INCLUDABLE_YAML_EXTENSIONS: frozenset[str] = frozenset({".yaml", ".yml"})
_INCLUDABLE_EXTENSIONS: frozenset[str] = (
    _INCLUDABLE_TEXT_EXTENSIONS | _INCLUDABLE_YAML_EXTENSIONS
)
_MAX_INCLUDE_DEPTH = 10


def _resolve_include_path(
    rel_path: str,
    current_dir: Path,
    root_dir: Path,
) -> Path:
    """Resolve a relative include path safely within the sandbox boundary.

    The path is resolved relative to ``current_dir`` (the directory of the
    file containing the ``!include`` tag), then sandboxed against ``root_dir``.

    Args:
        rel_path: The relative path specified in the ``!include`` tag.
        current_dir: The directory of the file containing the ``!include`` tag.
        root_dir: The submission root directory (sandbox boundary).

    Returns:
        The resolved absolute Path object.

    Raises:
        PathTraversalError: If the resolved path escapes root_dir, or if the target or any parent component is a symlink.
        SubmissionValidationError: If the file does not exist or has a disallowed extension.
    """
    raw_path = current_dir / rel_path
    if raw_path.is_symlink():
        raise PathTraversalError(
            f"!include target is a symlink: {rel_path}"
        )

    for parent in raw_path.parents:
        if parent == current_dir or parent == root_dir:
            break
        if parent.is_symlink():
            raise PathTraversalError(
                f"!include path contains a symlink component: {parent.name}"
            )

    abs_path = raw_path.resolve()

    # Security: must stay inside root_dir
    if not abs_path.is_relative_to(root_dir.resolve()):
        raise PathTraversalError(
            f"!include path escapes submission directory: {rel_path}"
        )

    if not abs_path.exists():
        raise SubmissionValidationError(
            f"!include file not found: {rel_path}"
        )

    if abs_path.suffix not in _INCLUDABLE_EXTENSIONS:
        raise SubmissionValidationError(
            f"!include does not support '{abs_path.suffix}' files "
            f"(allowed: {', '.join(sorted(_INCLUDABLE_EXTENSIONS))}): "
            f"{rel_path}"
        )

    return abs_path


class SandboxedYamlLoader(yaml.SafeLoader):
    """``yaml.SafeLoader`` subclass with sandboxed ``!include`` support.

    ``!include`` paths are resolved **relative to the file containing
    the tag**, not relative to the submission root. The resolved path
    is then checked to ensure it stays within the submission root.

    **Do not instantiate directly** — use :func:`make_sandboxed_loader`
    or :func:`load_yaml` instead.

    Attributes:
        _root_dir: The submission root directory (sandbox boundary), set dynamically by make_sandboxed_loader.
        _current_dir: The directory of the file being loaded, set dynamically by make_sandboxed_loader.
        _depth: Current include nesting depth, used to enforce _MAX_INCLUDE_DEPTH.
    """

    _root_dir: Path  # set by make_sandboxed_loader
    _current_dir: Path  # set by make_sandboxed_loader
    _depth: int = 0

    def include(self, node: yaml.Node) -> Any:
        """Handle ``!include path/to/file`` tags during YAML parsing.

        Args:
            node: The YAML scalar node containing the relative file path.

        Returns:
            The parsed YAML content (if a .yaml or .yml file) or the raw text string (if a .md or .txt file).

        Raises:
            SubmissionValidationError: If include nesting depth exceeds ``_MAX_INCLUDE_DEPTH``, if the included file is not found, or if the file extension is disallowed.
            PathTraversalError: If the include path attempts to escape the submission root directory.
            yaml.YAMLError: If an included YAML file is malformed.
        """
        rel_path: str = self.construct_scalar(node)  # type: ignore[arg-type]
        abs_path = _resolve_include_path(rel_path, self._current_dir, self._root_dir)

        content = abs_path.read_text(encoding="utf-8")

        if abs_path.suffix in _INCLUDABLE_YAML_EXTENSIONS:
            if self._depth >= _MAX_INCLUDE_DEPTH:
                raise SubmissionValidationError(
                    f"!include nesting too deep (max {_MAX_INCLUDE_DEPTH}): {rel_path}"
                )
            # Nested YAML: resolve relative to the *included* file's dir
            loader_cls = make_sandboxed_loader(
                self._root_dir, current_dir=abs_path.parent
            )
            loader_cls._depth = self._depth + 1
            return yaml.load(content, Loader=loader_cls)  # noqa: S506

        # .md, .txt → raw string
        return content


def make_sandboxed_loader(
    root_dir: Path,
    current_dir: Path | None = None,
) -> type[SandboxedYamlLoader]:
    """Create a loader class bound to a root and current directory.

    Args:
        root_dir: The submission root directory (sandbox boundary).
        current_dir: The directory of the file being loaded. ``!include``
            paths are resolved relative to this. Defaults to ``root_dir``.

    Returns:
        A dynamically created subclass of :class:`SandboxedYamlLoader` bound to the specified root and current directories.
        Each call returns a **new subclass** so that different directories don't interfere with each other.
    """

    class BoundLoader(SandboxedYamlLoader):
        pass

    BoundLoader._root_dir = root_dir.resolve()
    BoundLoader._current_dir = (current_dir or root_dir).resolve()
    BoundLoader.add_constructor("!include", BoundLoader.include)
    return BoundLoader


def load_yaml(path: Path, root_dir: Path) -> dict[str, Any]:
    """Load a YAML file with sandboxed ``!include`` support.

    ``!include`` paths are resolved relative to the directory of ``path``,
    but sandboxed within ``root_dir``.

    Args:
        path: The YAML file to load.
        root_dir: The root directory (sandbox boundary).

    Returns:
        Parsed YAML content as a dictionary mapping.

    Raises:
        SubmissionValidationError: If the loaded YAML is not a top-level mapping, if an included file is not found, or if include nesting is too deep.
        PathTraversalError: If ``path`` or any included file path escapes ``root_dir``.
        yaml.YAMLError: If the YAML file or any included YAML file is malformed.
    """
    loader_cls = make_sandboxed_loader(root_dir, current_dir=path.parent)
    with open(path, "r", encoding="utf-8") as f:
        data = yaml.load(f, Loader=loader_cls)  # noqa: S506
    if not isinstance(data, dict):
        raise SubmissionValidationError(
            f"Expected YAML mapping at top level, got {type(data).__name__}: "
            f"{path}"
        )
    return data
