"""Submission directory validation, adapter discovery, and skill discovery.

Provides utilities to validate submission directory structures against configured limits
(file counts, sizes, allowed extensions), and discover model adapters (LoRA weights)
and ADK skills (directories containing SKILL.md). Discovered assets are catalogued into
manifests that can be bulk-registered directly into closed registries.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from .errors import LimitExceededError, SubmissionValidationError
from .limits import SubmissionLimits
from .registry import ModelRegistry, SkillRegistry

# Conventional root config filenames (checked in priority order).
_ROOT_CONFIG_NAMES: list[str] = ["agent.yaml", "root_agent.yaml"]


# ---------------------------------------------------------------------------
# Validated directory view
# ---------------------------------------------------------------------------


@dataclass
class SubmissionDirectory:
    """Validated, immutable view of a submission directory complying with submission limits.

    Instances of this class are produced by :func:`validate_directory` after successfully
    enforcing competition limits and verifying directory structure. All paths stored in this
    dataclass are resolved absolute :class:`pathlib.Path` objects.
    """

    root_dir: Path
    """The absolute path to the root of the unpacked submission directory."""

    config_path: Path
    """The absolute path to the primary root YAML configuration file (e.g., agent.yaml)."""

    prompt_files: list[Path] = field(default_factory=list)
    """List of absolute paths to all discovered markdown (.md) and text (.txt) prompt files."""

    adapter_files: list[Path] = field(default_factory=list)
    """List of absolute paths to all discovered model weight and adapter files (e.g., .safetensors)."""

    yaml_files: list[Path] = field(default_factory=list)
    """List of absolute paths to all discovered YAML configuration files (.yaml, .yml)."""

    all_files: list[Path] = field(default_factory=list)
    """List of absolute paths to every regular file discovered within the entire directory tree."""


def validate_directory(
    submission_dir: str | Path,
    limits: SubmissionLimits | None = None,
) -> SubmissionDirectory:
    """Validate and catalogue a submission directory against configured limits.

    Performs a recursive scan of the submission directory to ensure compliance with
    competition constraints and structural rules. Specifically, it:
    1. Resolves the root directory and rejects any symlinks to prevent path traversal.
    2. Enforces maximum file count and cumulative file size limits.
    3. Verifies that all file extensions match allowed whitelists.
    4. Categorizes files into YAML configs, prompts, and model adapters.
    5. Locates and validates the unambiguous root agent configuration file.

    Args:
        submission_dir: Absolute or relative path to the unpacked submission directory.
        limits: Optional limits to enforce on file counts, sizes, and extensions.
            If ``None``, default :class:`SubmissionLimits` are applied.

    Returns:
        A :class:`SubmissionDirectory` instance containing catalogued absolute file paths.

    Raises:
        SubmissionValidationError: If the path is not a directory, contains symlinks,
            has files with disallowed extensions, or lacks an unambiguous root config.
        LimitExceededError: If total file count, cumulative byte size, or YAML file count
            exceeds configured limits.
    """
    limits = limits or SubmissionLimits()
    root = Path(submission_dir).resolve()

    if not root.is_dir():
        raise SubmissionValidationError(
            f"Submission path is not a directory: {submission_dir}"
        )

    # Collect all files (recursive) — reject symlinks
    all_files: list[Path] = []
    total_size = 0
    for p in sorted(root.rglob("*")):
        if p.is_symlink():
            raise SubmissionValidationError(
                f"Symlinks are not permitted: {p.relative_to(root)}"
            )
        if p.is_file():
            all_files.append(p)
            total_size += p.stat().st_size

    # --- File-level limits ---
    if len(all_files) > limits.max_file_count:
        raise LimitExceededError(
            f"Too many files: {len(all_files)} (max {limits.max_file_count})"
        )
    if total_size > limits.max_total_size_bytes:
        raise LimitExceededError(
            f"Total submission size {total_size:,} bytes exceeds "
            f"limit of {limits.max_total_size_bytes:,} bytes"
        )

    # --- Extension check ---
    for p in all_files:
        if p.suffix.lower() not in limits.allowed_file_extensions:
            raise SubmissionValidationError(
                f"File has disallowed extension '{p.suffix}': "
                f"{p.relative_to(root)}"
            )

    # --- Categorise files ---
    yaml_files = [p for p in all_files if p.suffix.lower() in {".yaml", ".yml"}]
    prompt_files = [p for p in all_files if p.suffix.lower() in {".md", ".txt"}]
    adapter_files = [
        p for p in all_files if p.suffix.lower() in limits.adapter_extensions
    ]

    if len(yaml_files) > limits.max_yaml_files:
        raise LimitExceededError(
            f"Too many YAML files: {len(yaml_files)} "
            f"(max {limits.max_yaml_files})"
        )

    # --- Find root config ---
    config_path = _find_root_config(root, yaml_files)

    return SubmissionDirectory(
        root_dir=root,
        config_path=config_path,
        prompt_files=prompt_files,
        adapter_files=adapter_files,
        yaml_files=yaml_files,
        all_files=all_files,
    )


def _find_root_config(root: Path, yaml_files: list[Path]) -> Path:
    """Locate the primary root agent configuration file within the submission.

    Scans the root level of the submission directory in the following priority order:
    1. ``agent.yaml`` at the root level of the submission directory.
    2. ``root_agent.yaml`` at the root level of the submission directory.
    3. If exactly one YAML file (``.yaml`` or ``.yml``) exists at the root level, use it.

    Args:
        root: Absolute path to the submission root directory.
        yaml_files: List of absolute paths to all discovered YAML files in the submission.

    Returns:
        Absolute :class:`pathlib.Path` to the resolved root configuration file.

    Raises:
        SubmissionValidationError: If no root YAML config is found, or if multiple
            ambiguous YAML files exist at the root level without a conventional name.
    """
    for name in _ROOT_CONFIG_NAMES:
        candidate = root / name
        if candidate.exists() and candidate.is_file():
            return candidate

    # Fall back: single yaml file at root level
    root_level_yamls = [
        p for p in yaml_files if p.parent == root
    ]
    if len(root_level_yamls) == 1:
        return root_level_yamls[0]

    if len(root_level_yamls) == 0:
        raise SubmissionValidationError(
            "No root YAML config found. Expected 'agent.yaml' or "
            "'root_agent.yaml' at the top level of the submission directory."
        )

    names = [p.name for p in root_level_yamls]
    raise SubmissionValidationError(
        f"Ambiguous root config: found {len(root_level_yamls)} YAML files "
        f"at the root level ({', '.join(names)}). Please name the root "
        f"config 'agent.yaml' or 'root_agent.yaml'."
    )


# ---------------------------------------------------------------------------
# Adapter discovery
# ---------------------------------------------------------------------------


@dataclass
class AdapterInfo:
    """Metadata describing a discovered model weight or adapter file.

    Generated during adapter discovery by :func:`discover_adapters`. If adapter files
    in subdirectories share the same filename stem as other adapters, their ``name``
    attribute is disambiguated using their relative directory path.
    """

    name: str
    """Identifier name for the adapter. Typically the filename stem (e.g., ``'my_lora'``), 
    or a disambiguated relative path (e.g., ``'subfolder_my_lora'``) if collisions occur."""

    path: Path
    """Absolute path to the adapter file on disk."""

    format: str
    """File extension without the leading dot (e.g., ``'safetensors'``, ``'gguf'``)."""

    size_bytes: int
    """Size of the adapter file in bytes."""


@dataclass
class AdapterManifest:
    """Manifest of all model adapter files discovered within a submission directory.

    Contains a mapping of disambiguated adapter names to :class:`AdapterInfo` objects,
    providing a helper method to bulk-register discovered adapters into a :class:`ModelRegistry`.
    """

    adapters: dict[str, AdapterInfo]
    """Dictionary mapping disambiguated adapter names to their metadata."""

    def register_all(
        self,
        model_registry: ModelRegistry,
        model_id_fn: Callable[[AdapterInfo], str],
    ) -> None:
        """Register all discovered adapters into a :class:`ModelRegistry`.

        Iterates through all discovered adapters and registers them in the provided
        model registry under the key ``"adapter:<adapter_name>"``. This allows agent
        configurations to reference the adapter using the ``adapter:`` prefix. If an adapter
        name already exists in the registry, it will be silently overwritten.

        Args:
            model_registry: The :class:`ModelRegistry` instance to populate.
            model_id_fn: A callable that maps an :class:`AdapterInfo` instance to a
                fully qualified model identifier string (e.g., ``"hosted_vllm/llama3:my_lora"``)
                compatible with the competition's serving infrastructure.

        Returns:
            None

        Example::

            manifest.register_all(
                models,
                lambda info: f"hosted_vllm/llama3:{info.name}",
            )
        """
        for name, info in self.adapters.items():
            model_id = model_id_fn(info)
            model_registry.register(f"adapter:{name}", model_id)


def discover_adapters(
    submission_dir: str | Path,
    adapter_extensions: frozenset[str] | None = None,
) -> AdapterManifest:
    """Discover and catalogue adapter and model weight files within a submission directory.

    Performs a two-pass scan of the submission directory to identify adapter files and prevent
    naming collisions:
    1. Root-level adapter files are processed first and retain their original filename stem
       as their adapter name.
    2. Adapters in subdirectories are processed second; if their stem collides with an existing
       name, they are disambiguated by prefixing their relative directory path (e.g., ``subfolder_model``).

    Args:
        submission_dir: Absolute or relative path to the unpacked submission directory.
        adapter_extensions: Optional set of file extensions (including dot) to identify
            adapter files. If ``None``, defaults to ``SubmissionLimits().adapter_extensions``.

    Returns:
        An :class:`AdapterManifest` containing metadata for all discovered and disambiguated adapters.

    Raises:
        SubmissionValidationError: If an adapter name collision occurs at the root level,
            or if a collision persists even after relative path disambiguation.
    """
    if adapter_extensions is None:
        adapter_extensions = SubmissionLimits().adapter_extensions

    root = Path(submission_dir).resolve()
    adapters: dict[str, AdapterInfo] = {}

    # Two-pass scan: process root level adapters first to claim stem names
    all_adapter_files = [
        p for p in sorted(root.rglob("*"))
        if p.is_file() and p.suffix.lower() in adapter_extensions
    ]
    root_adapters = [p for p in all_adapter_files if p.parent == root]
    sub_adapters = [p for p in all_adapter_files if p.parent != root]

    for p in root_adapters:
        info = AdapterInfo(
            name=p.stem,
            path=p,
            format=p.suffix.lstrip(".").lower(),
            size_bytes=p.stat().st_size,
        )
        if info.name in adapters:
            raise SubmissionValidationError(
                f"Adapter name collision at root level: {info.name!r}"
            )
        adapters[info.name] = info

    for p in sub_adapters:
        info = AdapterInfo(
            name=p.stem,
            path=p,
            format=p.suffix.lstrip(".").lower(),
            size_bytes=p.stat().st_size,
        )
        if info.name in adapters:
            # Disambiguate using relative path
            rel = p.relative_to(root)
            info.name = str(rel.with_suffix("")).replace("/", "_")
        if info.name in adapters:
            raise SubmissionValidationError(
                f"Adapter name collision after disambiguation: "
                f"{info.name!r} (from {p.relative_to(root)})"
            )
        adapters[info.name] = info

    return AdapterManifest(adapters=adapters)


# ---------------------------------------------------------------------------
# Skill discovery
# ---------------------------------------------------------------------------


@dataclass
class SkillInfo:
    """Metadata describing a discovered ADK skill directory.

    Produced by :func:`discover_skills`. A skill directory is identified by the presence
    of a ``SKILL.md`` file. If multiple skill directories share the same folder name, their
    ``name`` attribute is disambiguated using their relative path from the submission root.
    """

    name: str
    """Identifier name for the skill. Typically the directory name (e.g., ``'sql_analyst'``),
    or a disambiguated relative path (e.g., ``'subfolder_sql_analyst'``) if collisions occur."""

    path: Path
    """Absolute path to the skill directory containing the ``SKILL.md`` file."""


@dataclass
class SkillManifest:
    """Manifest of all ADK skill directories discovered within a submission directory.

    Contains a mapping of disambiguated skill names to :class:`SkillInfo` objects,
    providing a helper method to bulk-register discovered skills into a :class:`SkillRegistry`.
    """

    skills: dict[str, SkillInfo]
    """Dictionary mapping disambiguated skill names to their metadata."""

    def register_all(
        self,
        skill_registry: SkillRegistry,
        skill_loader_fn: Callable[[SkillInfo], Any],
    ) -> None:
        """Register all discovered skills into a :class:`SkillRegistry`.

        Iterates through all discovered skills, invokes the loader function to instantiate
        the ADK Skill object, and registers it in the provided skill registry. If a skill
        name already exists in the registry, it will be silently overwritten.

        Args:
            skill_registry: The :class:`SkillRegistry` instance to populate.
            skill_loader_fn: A callable that takes a :class:`SkillInfo` instance and
                returns a loaded ADK Skill object (e.g., ``lambda info: load_skill_from_dir(info.path)``).

        Returns:
            None

        Example::

            skill_manifest.register_all(
                skills,
                lambda info: load_skill_from_dir(info.path),
            )
        """
        for name, info in self.skills.items():
            skill = skill_loader_fn(info)
            skill_registry.register(name, skill)


def discover_skills(
    submission_dir: str | Path,
    limits: SubmissionLimits | None = None,
) -> SkillManifest:
    """Discover and catalogue ADK skill directories within a submission directory.

    Scans the submission directory tree for any directory containing a ``SKILL.md`` file.
    Skill names are derived from their directory names; if multiple skill directories share
    the same folder name, they are disambiguated by prefixing their relative path from the
    submission root (e.g., ``subfolder_skillname``).

    Args:
        submission_dir: Absolute or relative path to the unpacked submission directory.
        limits: Optional limits to enforce on maximum skill counts.
            If ``None``, default :class:`SubmissionLimits` are applied.

    Returns:
        A :class:`SkillManifest` containing metadata for all discovered and disambiguated skills.

    Raises:
        LimitExceededError: If the total number of discovered skills exceeds ``limits.max_skills``.
        SubmissionValidationError: If a skill name collision persists even after relative path disambiguation.
    """
    limits = limits or SubmissionLimits()
    root = Path(submission_dir).resolve()
    skills: dict[str, SkillInfo] = {}

    # Find all SKILL.md files
    for p in sorted(root.rglob("SKILL.md")):
        if p.is_file():
            skill_dir = p.parent
            name = skill_dir.name
            if name in skills:
                rel = skill_dir.relative_to(root)
                name = str(rel).replace("/", "_")
            if name in skills:
                raise SubmissionValidationError(
                    f"Skill name collision after disambiguation: "
                    f"{name!r} (from {skill_dir.relative_to(root)})"
                )
            skills[name] = SkillInfo(name=name, path=skill_dir)

    if len(skills) > limits.max_skills:
        raise LimitExceededError(
            f"Too many skills discovered: {len(skills)} (max {limits.max_skills})"
        )

    return SkillManifest(skills=skills)


