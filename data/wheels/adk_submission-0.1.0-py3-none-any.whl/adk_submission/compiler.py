"""Compile a submission directory into a live ADK agent tree.

This module is the core of ``adk_submission``. It provides a safe, sandboxed
reimplementation of the ADK ``config_agent_utils.from_config()`` pipeline that
never performs arbitrary dynamic imports or calls ``importlib``. All tools, models,
callbacks, and skills are resolved through closed registries provided by the
competition organizer, or loaded from sandboxed submission directories under
strict path traversal protection. Support is also provided for sandboxed code
execution and organizer-defined LLM generation constraints.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable

from google.adk.agents import Agent, LoopAgent, ParallelAgent, SequentialAgent
from google.adk.agents.base_agent import BaseAgent
from google.adk.code_executors.base_code_executor import BaseCodeExecutor
from google.adk.tools.agent_tool import AgentTool
from google.adk.tools.skill_toolset import SkillToolset
from google.genai import types as genai_types

from .discovery import SubmissionDirectory, validate_directory
from .errors import (
    LimitExceededError,
    PathTraversalError,
    SubmissionValidationError,
)
from .limits import GenerationConstraints, SubmissionLimits
from .registry import CallbackRegistry, CallbackType, ModelRegistry, ToolRegistry, SkillRegistry
from .schema import (
    AgentToolEntry,
    SandboxedAgentConfig,
    SandboxedLlmAgentConfig,
    SandboxedLoopAgentConfig,
    SandboxedParallelAgentConfig,
    SandboxedSequentialAgentConfig,
)
from .yaml_loader import load_yaml


# ---------------------------------------------------------------------------
# Compilation context — threaded through recursive calls
# ---------------------------------------------------------------------------


@dataclass
class CompilationContext:
    """Mutable state carried through the recursive compilation process.

    Tracks cumulative limits (agent count, nesting depth, instruction characters,
    and skill counts) and provides access to organizer-defined registries, limits,
    and sandboxed code execution environments.

    Attributes:
        root_dir: Absolute path to the submission root directory (sandbox boundary).
        tool_registry: Registry of pre-approved tools available to agents.
        model_registry: Registry mapping model aliases to LLM configurations.
        callback_registry: Optional registry of pre-approved agent, model, or tool callbacks.
        limits: Configurable structural limits and constraints for submission validation.
        generation_constraints: Optional organizer constraints on LLM generation parameters.
        code_executor: Optional sandboxed code executor for running skill scripts.
        script_timeout: Maximum execution time (in seconds) allowed for skill scripts.
        skill_registry: Optional registry of pre-approved skills.
        agent_count: Current cumulative count of compiled agents (enforces max_agents).
        depth: Current recursive nesting depth of sub-agents (enforces max_sub_agent_depth).
        total_instruction_chars: Current cumulative character count across all agent instructions (enforces max_total_instruction_chars).
        total_skills_count: Current cumulative count of loaded skills across all agents (enforces max_skills).
    """

    root_dir: Path
    tool_registry: ToolRegistry
    model_registry: ModelRegistry
    callback_registry: CallbackRegistry | None
    limits: SubmissionLimits
    generation_constraints: GenerationConstraints | None
    code_executor: BaseCodeExecutor | None = None
    script_timeout: int = 300
    skill_registry: SkillRegistry | None = None

    agent_count: int = 0
    depth: int = 0
    total_instruction_chars: int = 0
    total_skills_count: int = 0


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def compile_submission(
    submission_dir: str | Path,
    tool_registry: ToolRegistry | dict[str, Callable[..., Any]],
    model_registry: ModelRegistry,
    callback_registry: CallbackRegistry | None = None,
    limits: SubmissionLimits | None = None,
    generation_constraints: GenerationConstraints | None = None,
    code_executor: BaseCodeExecutor | None = None,
    script_timeout: int = 300,
    skill_registry: SkillRegistry | None = None,
) -> BaseAgent:
    """Compile a submission directory into a live ADK agent tree.

    Args:
        submission_dir: Path to the unpacked submission directory.
        tool_registry: Registry of available tools, or a plain
            ``dict[str, Callable]`` mapping tool names to callables.
            A dict is automatically wrapped in a :class:`ToolRegistry`.
        model_registry: Registry mapping model aliases to LLM configs.
        callback_registry: Optional registry of pre-approved callbacks.
        limits: Optional submission limits (uses defaults if not provided).
        generation_constraints: Optional organizer-defined constraints on
            which generation parameters submissions can set and their valid
            ranges. If ``None``, no restrictions on generation params.
        code_executor: Optional sandboxed code executor for running agent skills.
        script_timeout: Timeout for skill script execution in seconds.
        skill_registry: Optional registry of pre-approved skills.

    Returns:
        The compiled root ADK agent, ready to run.

    Raises:
        SubmissionValidationError: If the submission fails validation, including
            generation parameter constraint violations, missing skill directories,
            or invalid skill loading.
        SubmissionSchemaError: If the agent configuration or any referenced
            sub-agent/tool configuration fails schema validation.
        PathTraversalError: If any configuration file, skill path, or sub-agent
            reference attempts to escape the submission root directory.
        ToolNotFoundError: If a referenced tool is not found in the registry.
        ModelNotFoundError: If a referenced model alias is not found in the registry.
        CallbackNotFoundError: If a referenced callback is not found in the registry.
        LimitExceededError: If the submission exceeds configured structural limits
            (e.g., agent count, sub-agent depth, instruction length, skill count).
        yaml.YAMLError: If any YAML configuration file is malformed.
    """
    # Coerce dict → ToolRegistry
    if isinstance(tool_registry, dict):
        reg = ToolRegistry()
        for name, fn in tool_registry.items():
            reg.register(name, fn)
        tool_registry = reg

    limits = limits or SubmissionLimits()

    # 1. Validate directory structure
    submission = validate_directory(submission_dir, limits)

    # 2. Load root YAML with sandboxed !include
    raw_config = load_yaml(submission.config_path, submission.root_dir)

    # 3. Parse & validate against restricted schema
    try:
        config = SandboxedAgentConfig.model_validate(raw_config)
    except Exception as e:
        if "Path traversal" in str(e):
            raise PathTraversalError(f"Path traversal attempted in config: {e}") from e
        from .errors import SubmissionSchemaError
        raise SubmissionSchemaError(f"Submission schema validation failed: {e}") from e

    # 4. Compile agent tree (recursive)
    ctx = CompilationContext(
        root_dir=submission.root_dir,
        tool_registry=tool_registry,
        model_registry=model_registry,
        callback_registry=callback_registry,
        limits=limits,
        generation_constraints=generation_constraints,
        code_executor=code_executor,
        script_timeout=script_timeout,
        skill_registry=skill_registry,
    )
    return _compile_agent(config.root, ctx)


# ---------------------------------------------------------------------------
# Recursive agent compilation
# ---------------------------------------------------------------------------


def _compile_agent(
    config: Any,
    ctx: CompilationContext,
) -> BaseAgent:
    """Dispatch to the correct builder for each agent configuration type.

    Args:
        config: The validated sandboxed agent configuration object to compile.
        ctx: The compilation context tracking mutable state and limits.

    Returns:
        An instantiated ADK BaseAgent matching the configuration.

    Raises:
        LimitExceededError: If the total number of compiled agents exceeds ``ctx.limits.max_agents``.
        SubmissionValidationError: If the agent configuration type is unsupported.
    """
    ctx.agent_count += 1
    if ctx.agent_count > ctx.limits.max_agents:
        raise LimitExceededError(
            f"Too many agents: {ctx.agent_count} (max {ctx.limits.max_agents})"
        )

    if isinstance(config, SandboxedLlmAgentConfig):
        return _compile_llm_agent(config, ctx)
    elif isinstance(config, SandboxedSequentialAgentConfig):
        return _compile_sequential_agent(config, ctx)
    elif isinstance(config, SandboxedParallelAgentConfig):
        return _compile_parallel_agent(config, ctx)
    elif isinstance(config, SandboxedLoopAgentConfig):
        return _compile_loop_agent(config, ctx)
    else:
        raise SubmissionValidationError(
            f"Unsupported agent config type: {type(config).__name__}"
        )


# ---------------------------------------------------------------------------
# LlmAgent
# ---------------------------------------------------------------------------


def _compile_llm_agent(
    config: SandboxedLlmAgentConfig,
    ctx: CompilationContext,
) -> Agent:
    """Compile a sandboxed LLM agent configuration into an ADK Agent.

    Resolves tools, skills (via SkillToolset), models, callbacks, sub-agents,
    and generation configurations while enforcing instruction, description, and skill limits.

    Args:
        config: The sandboxed LLM agent configuration object.
        ctx: The compilation context tracking mutable state and limits.

    Returns:
        A fully configured ADK Agent instance.

    Raises:
        LimitExceededError: If instruction length, description length, or cumulative skill count limits are exceeded.
        PathTraversalError: If a referenced skill path escapes the submission root directory.
        SubmissionValidationError: If a skill directory is missing or fails to load.
        ToolNotFoundError: If a referenced tool is not found in the tool registry.
        ModelNotFoundError: If a referenced model alias is not found in the model registry.
        CallbackNotFoundError: If a referenced callback is not found in the callback registry.
    """
    # Instruction length limits
    _check_instruction_length(config.instruction, config.name, ctx)
    _check_description_length(config.description, config.name, ctx)

    # Resolve tools (plain strings → registry, AgentToolEntry → compile & wrap)
    tools = [_resolve_tool_item(item, ctx) for item in (config.tools or [])]

    # Resolve skills
    if config.skills:
        ctx.total_skills_count += len(config.skills)
        if ctx.total_skills_count > ctx.limits.max_skills:
            raise LimitExceededError(
                f"Agent '{config.name}': cumulative skills count ({ctx.total_skills_count}) "
                f"exceeds submission limit of {ctx.limits.max_skills}"
            )

        loaded_skills = []
        for skill_ref in config.skills:
            if ctx.skill_registry is not None and skill_ref in ctx.skill_registry:
                loaded_skills.append(ctx.skill_registry.get(skill_ref))
            else:
                skill_path = (ctx.root_dir / skill_ref).resolve()
                if not skill_path.is_relative_to(ctx.root_dir.resolve()):
                    raise PathTraversalError(
                        f"Skill path escapes submission directory: {skill_ref}"
                    )
                if not skill_path.exists():
                    raise SubmissionValidationError(
                        f"Skill directory not found: {skill_ref}"
                    )
                try:
                    from google.adk.skills import load_skill_from_dir

                    skill = load_skill_from_dir(skill_path)
                    loaded_skills.append(skill)
                except Exception as e:
                    raise SubmissionValidationError(
                        f"Failed to load skill '{skill_ref}': {e}"
                    ) from e

        skill_toolset = SkillToolset(
            skills=loaded_skills,
            code_executor=ctx.code_executor,
            script_timeout=ctx.script_timeout,
            additional_tools=ctx.tool_registry.get_all(),
        )
        tools.append(skill_toolset)

    # Resolve model
    model = ctx.model_registry.get(config.model) if config.model else None

    # Resolve callbacks
    callback_kwargs = _resolve_callbacks(config, ctx)

    # Resolve sub-agents
    sub_agents = _compile_sub_agents(config.sub_agents, ctx)

    # Resolve generate_content_config with organizer constraints
    gen_config = _resolve_generation_config(config, ctx)

    kwargs: dict[str, Any] = dict(
        name=config.name,
        description=config.description or "",
        model=model,
        instruction=config.instruction,
        tools=tools,
        sub_agents=sub_agents,
        output_key=config.output_key,
        include_contents=config.include_contents,
        generate_content_config=gen_config,
        **callback_kwargs,
    )

    # Only pass these when explicitly set — ADK rejects None
    if config.disallow_transfer_to_parent is not None:
        kwargs["disallow_transfer_to_parent"] = config.disallow_transfer_to_parent
    if config.disallow_transfer_to_peers is not None:
        kwargs["disallow_transfer_to_peers"] = config.disallow_transfer_to_peers

    return Agent(**kwargs)


# ---------------------------------------------------------------------------
# Workflow agents
# ---------------------------------------------------------------------------


def _compile_sequential_agent(
    config: SandboxedSequentialAgentConfig,
    ctx: CompilationContext,
) -> SequentialAgent:
    """Compile a sandboxed sequential agent configuration into an ADK SequentialAgent.

    Args:
        config: The sandboxed sequential workflow agent configuration object.
        ctx: The compilation context tracking mutable state and limits.

    Returns:
        A fully configured ADK SequentialAgent instance.

    Raises:
        LimitExceededError: If the description length limit is exceeded.
        CallbackNotFoundError: If a referenced callback is not found in the callback registry.
    """
    _check_description_length(config.description, config.name, ctx)
    sub_agents = _compile_sub_agents(config.sub_agents, ctx)
    callback_kwargs = _resolve_base_callbacks(config, ctx)
    return SequentialAgent(
        name=config.name,
        description=config.description or "",
        sub_agents=sub_agents,
        **callback_kwargs,
    )


def _compile_parallel_agent(
    config: SandboxedParallelAgentConfig,
    ctx: CompilationContext,
) -> ParallelAgent:
    """Compile a sandboxed parallel agent configuration into an ADK ParallelAgent.

    Args:
        config: The sandboxed parallel workflow agent configuration object.
        ctx: The compilation context tracking mutable state and limits.

    Returns:
        A fully configured ADK ParallelAgent instance.

    Raises:
        LimitExceededError: If the description length limit is exceeded.
        CallbackNotFoundError: If a referenced callback is not found in the callback registry.
    """
    _check_description_length(config.description, config.name, ctx)
    sub_agents = _compile_sub_agents(config.sub_agents, ctx)
    callback_kwargs = _resolve_base_callbacks(config, ctx)
    return ParallelAgent(
        name=config.name,
        description=config.description or "",
        sub_agents=sub_agents,
        **callback_kwargs,
    )


def _compile_loop_agent(
    config: SandboxedLoopAgentConfig,
    ctx: CompilationContext,
) -> LoopAgent:
    """Compile a sandboxed loop agent configuration into an ADK LoopAgent.

    Validates and caps the maximum loop iterations against configured submission limits.

    Args:
        config: The sandboxed loop workflow agent configuration object.
        ctx: The compilation context tracking mutable state and limits.

    Returns:
        A fully configured ADK LoopAgent instance.

    Raises:
        LimitExceededError: If description length or max_iterations limits are exceeded.
        CallbackNotFoundError: If a referenced callback is not found in the callback registry.
    """
    _check_description_length(config.description, config.name, ctx)
    # Cap max_iterations — treat None (omitted) as the maximum allowed.
    max_iter = config.max_iterations
    if max_iter is None:
        max_iter = ctx.limits.max_loop_iterations
    elif max_iter > ctx.limits.max_loop_iterations:
        raise LimitExceededError(
            f"Agent '{config.name}': max_iterations={max_iter} exceeds "
            f"limit of {ctx.limits.max_loop_iterations}"
        )

    sub_agents = _compile_sub_agents(config.sub_agents, ctx)
    callback_kwargs = _resolve_base_callbacks(config, ctx)
    return LoopAgent(
        name=config.name,
        description=config.description or "",
        sub_agents=sub_agents,
        max_iterations=max_iter,
        **callback_kwargs,
    )


# ---------------------------------------------------------------------------
# Sub-agent resolution
# ---------------------------------------------------------------------------


def _compile_sub_agents(
    refs: list[Any] | None,
    ctx: CompilationContext,
) -> list[BaseAgent]:
    """Recursively compile a list of sub-agent configuration references.

    Args:
        refs: A list of sub-agent reference objects containing config_path attributes, or None.
        ctx: The compilation context tracking mutable state, recursion depth, and limits.

    Returns:
        A list of compiled ADK BaseAgent instances.

    Raises:
        LimitExceededError: If the sub-agent nesting depth exceeds ``ctx.limits.max_sub_agent_depth``.
        PathTraversalError: If a sub-agent config_path escapes the submission root directory.
        SubmissionValidationError: If a sub-agent configuration file is not found.
        SubmissionSchemaError: If a sub-agent configuration fails schema validation.
        yaml.YAMLError: If a sub-agent YAML configuration file is malformed.
    """
    if not refs:
        return []

    ctx.depth += 1
    try:
        if ctx.depth > ctx.limits.max_sub_agent_depth:
            raise LimitExceededError(
                f"Sub-agent nesting too deep: {ctx.depth} "
                f"(max {ctx.limits.max_sub_agent_depth})"
            )

        agents: list[BaseAgent] = []
        for ref in refs:
            sub_path = (ctx.root_dir / ref.config_path).resolve()
            if not sub_path.is_relative_to(ctx.root_dir.resolve()):
                raise PathTraversalError(
                    f"Sub-agent config_path escapes submission directory: "
                    f"{ref.config_path}"
                )
            if not sub_path.exists():
                raise SubmissionValidationError(
                    f"Sub-agent config not found: {ref.config_path}"
                )

            raw = load_yaml(sub_path, ctx.root_dir)
            try:
                sub_config = SandboxedAgentConfig.model_validate(raw)
            except Exception as e:
                if "Path traversal" in str(e):
                    raise PathTraversalError(f"Path traversal attempted in sub-agent config ({ref.config_path}): {e}") from e
                from .errors import SubmissionSchemaError
                raise SubmissionSchemaError(f"Sub-agent schema validation failed ({ref.config_path}): {e}") from e
            agents.append(_compile_agent(sub_config.root, ctx))

        return agents
    finally:
        ctx.depth -= 1


# ---------------------------------------------------------------------------
# Agent-tool resolution
# ---------------------------------------------------------------------------


def _resolve_tool_item(
    item: str | AgentToolEntry,
    ctx: CompilationContext,
) -> Any:
    """Resolve a single entry in the agent's tools list.

    - Plain ``str`` → look up in the tool registry.
    - :class:`AgentToolEntry` → compile the referenced agent and wrap it in an ADK ``AgentTool``.

    Args:
        item: Either a plain string representing a tool name in the registry, or an AgentToolEntry object referencing a sub-agent.
        ctx: The compilation context tracking mutable state and limits.

    Returns:
        The resolved tool callable or an ADK AgentTool instance wrapping a compiled sub-agent.

    Raises:
        ToolNotFoundError: If a plain string tool name is not found in the tool registry.
        PathTraversalError: If an AgentTool config_path escapes the submission root directory.
        SubmissionValidationError: If an AgentTool configuration file is not found.
        LimitExceededError: If sub-agent nesting depth via AgentTool exceeds ``ctx.limits.max_sub_agent_depth``.
        SubmissionSchemaError: If an AgentTool configuration fails schema validation.
        yaml.YAMLError: If an AgentTool YAML configuration file is malformed.
    """
    if isinstance(item, str):
        return ctx.tool_registry.get(item)

    # --- AgentToolEntry -------------------------------------------------
    ref = item.agent_tool
    sub_path = (ctx.root_dir / ref.config_path).resolve()

    if not sub_path.is_relative_to(ctx.root_dir.resolve()):
        raise PathTraversalError(
            f"AgentTool config_path escapes submission directory: "
            f"{ref.config_path}"
        )
    if not sub_path.exists():
        raise SubmissionValidationError(
            f"AgentTool config not found: {ref.config_path}"
        )

    # Track nesting depth
    ctx.depth += 1
    try:
        if ctx.depth > ctx.limits.max_sub_agent_depth:
            raise LimitExceededError(
                f"Sub-agent nesting too deep (via agent_tool): {ctx.depth} "
                f"(max {ctx.limits.max_sub_agent_depth})"
            )

        raw = load_yaml(sub_path, ctx.root_dir)
        try:
            agent_config = SandboxedAgentConfig.model_validate(raw)
        except Exception as e:
            if "Path traversal" in str(e):
                raise PathTraversalError(f"Path traversal attempted in AgentTool config ({ref.config_path}): {e}") from e
            from .errors import SubmissionSchemaError
            raise SubmissionSchemaError(f"AgentTool schema validation failed ({ref.config_path}): {e}") from e
        agent = _compile_agent(agent_config.root, ctx)

        return AgentTool(agent=agent, skip_summarization=ref.skip_summarization)
    finally:
        ctx.depth -= 1


# ---------------------------------------------------------------------------
# Callback resolution
# ---------------------------------------------------------------------------

# Maps YAML field name → (ADK kwarg name, CallbackType)
_LLM_CALLBACK_FIELDS: list[tuple[str, str, CallbackType]] = [
    ("before_agent_callbacks", "before_agent_callback", CallbackType.BEFORE_AGENT),
    ("after_agent_callbacks", "after_agent_callback", CallbackType.AFTER_AGENT),
    ("before_model_callbacks", "before_model_callback", CallbackType.BEFORE_MODEL),
    ("after_model_callbacks", "after_model_callback", CallbackType.AFTER_MODEL),
    ("before_tool_callbacks", "before_tool_callback", CallbackType.BEFORE_TOOL),
    ("after_tool_callbacks", "after_tool_callback", CallbackType.AFTER_TOOL),
]

_BASE_CALLBACK_FIELDS: list[tuple[str, str, CallbackType]] = [
    ("before_agent_callbacks", "before_agent_callback", CallbackType.BEFORE_AGENT),
    ("after_agent_callbacks", "after_agent_callback", CallbackType.AFTER_AGENT),
]


def _resolve_callbacks(
    config: SandboxedLlmAgentConfig,
    ctx: CompilationContext,
) -> dict[str, Any]:
    """Resolve all LLM-specific callback fields for an LlmAgent configuration.

    Args:
        config: The sandboxed LLM agent configuration object.
        ctx: The compilation context containing the callback registry.

    Returns:
        A dictionary mapping ADK callback keyword arguments to lists of resolved callback callables.

    Raises:
        CallbackNotFoundError: If a referenced callback name is not found in the callback registry.
    """
    return _resolve_callback_fields(config, ctx, _LLM_CALLBACK_FIELDS)


def _resolve_base_callbacks(
    config: Any,
    ctx: CompilationContext,
) -> dict[str, Any]:
    """Resolve before/after agent callbacks for workflow agent configurations.

    Args:
        config: The sandboxed workflow agent configuration object (Sequential, Parallel, or Loop).
        ctx: The compilation context containing the callback registry.

    Returns:
        A dictionary mapping ADK callback keyword arguments to lists of resolved callback callables.

    Raises:
        CallbackNotFoundError: If a referenced callback name is not found in the callback registry.
    """
    return _resolve_callback_fields(config, ctx, _BASE_CALLBACK_FIELDS)


def _resolve_callback_fields(
    config: Any,
    ctx: CompilationContext,
    fields: list[tuple[str, str, CallbackType]],
) -> dict[str, Any]:
    """Resolve a specified list of YAML callback fields into ADK constructor keyword arguments.

    Args:
        config: The sandboxed agent configuration object.
        ctx: The compilation context containing the callback registry.
        fields: A list of tuples containing (yaml_field_name, adk_kwarg_name, CallbackType).

    Returns:
        A dictionary mapping ADK callback keyword arguments to lists of resolved callback callables.

    Raises:
        CallbackNotFoundError: If a referenced callback name is not found in the callback registry.
    """
    kwargs: dict[str, Any] = {}
    if ctx.callback_registry is None:
        return kwargs

    for yaml_field, adk_kwarg, cb_type in fields:
        names: list[str] | None = getattr(config, yaml_field, None)
        if names:
            resolved = [
                ctx.callback_registry.get(name, cb_type) for name in names
            ]
            kwargs[adk_kwarg] = resolved

    return kwargs


# ---------------------------------------------------------------------------
# Generation config resolution
# ---------------------------------------------------------------------------


def _resolve_generation_config(
    config: SandboxedLlmAgentConfig,
    ctx: CompilationContext,
) -> genai_types.GenerateContentConfig | None:
    """Resolve and validate the LLM generation configuration against organizer constraints.

    Args:
        config: The sandboxed LLM agent configuration object.
        ctx: The compilation context containing organizer-defined generation constraints.

    Returns:
        A GenerateContentConfig instance if configuration or defaults exist, otherwise None.

    Raises:
        SubmissionValidationError: If the generation configuration violates organizer-defined constraints.
    """
    if config.generate_content_config is not None:
        config_dict = config.generate_content_config.model_dump(exclude_none=True)

        if ctx.generation_constraints is not None:
            config_dict = ctx.generation_constraints.validate_config(
                config_dict, config.name
            )

        if config_dict:
            return genai_types.GenerateContentConfig(**config_dict)
        return None

    # No user config — apply organizer defaults if any
    if (
        ctx.generation_constraints is not None
        and ctx.generation_constraints.defaults
    ):
        return genai_types.GenerateContentConfig(
            **ctx.generation_constraints.defaults
        )

    return None


# ---------------------------------------------------------------------------
# Instruction limits
# ---------------------------------------------------------------------------


def _check_instruction_length(
    instruction: str,
    agent_name: str,
    ctx: CompilationContext,
) -> None:
    """Enforce per-agent and cumulative total instruction character limits.

    Args:
        instruction: The instruction string for the agent.
        agent_name: The name of the agent being compiled.
        ctx: The compilation context tracking cumulative instruction length and limits.

    Raises:
        LimitExceededError: If the individual instruction length or cumulative total instruction length exceeds configured limits.
    """
    n = len(instruction)
    if n > ctx.limits.max_instruction_chars:
        raise LimitExceededError(
            f"Agent '{agent_name}': instruction length {n:,} chars "
            f"exceeds limit of {ctx.limits.max_instruction_chars:,}"
        )
    ctx.total_instruction_chars += n
    if ctx.total_instruction_chars > ctx.limits.max_total_instruction_chars:
        raise LimitExceededError(
            f"Total instruction length {ctx.total_instruction_chars:,} chars "
            f"exceeds limit of {ctx.limits.max_total_instruction_chars:,}"
        )


def _check_description_length(
    description: str | None,
    agent_name: str,
    ctx: CompilationContext,
) -> None:
    """Enforce per-agent description character limits.

    Note: Capped against ``ctx.limits.max_instruction_chars`` as a shared upper bound.

    Args:
        description: The description string for the agent, or None.
        agent_name: The name of the agent being compiled.
        ctx: The compilation context containing the submission limits.

    Raises:
        LimitExceededError: If the description length exceeds the configured limit.
    """
    if description:
        n = len(description)
        if n > ctx.limits.max_instruction_chars:
            raise LimitExceededError(
                f"Agent '{agent_name}': description length {n:,} chars "
                f"exceeds limit of {ctx.limits.max_instruction_chars:,}"
            )
